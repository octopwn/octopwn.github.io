
__version__ = "0.4.2"
__banner__ = \
"""
# aiosmb %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__