

__version__ = "0.1.6"
__banner__ = \
"""
# winacl %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__