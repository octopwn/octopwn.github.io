from winacl.functions.highlevel import get_logon_info

def main():
    print(get_logon_info())

if __name__ == '__main__':
    main()