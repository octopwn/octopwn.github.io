
__version__ = "0.4.1"
__banner__ = \
"""
# msldap %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__