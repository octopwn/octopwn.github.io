
__version__ = "0.4.4"
__banner__ = \
"""
# aiosmb %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__