


class SMBLocalGroup:
	def __init__(self, name = None, sid = None, members = {}):
		self.name = name
		self.sid = sid
		self.members = members