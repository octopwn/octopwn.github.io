


class SMBDomain:
	def __init__(self):
		self.name = None
		self.sid = None