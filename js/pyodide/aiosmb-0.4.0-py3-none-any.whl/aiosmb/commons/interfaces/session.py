

class SMBUserSession:
	def __init__(self, username = None, ip_addr = None):
		self.username = username
		self.ip_addr = ip_addr