
__version__ = "0.2.2"
__banner__ = \
"""
# asysocks %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__