

class SSHAlgo:
    def __init__(self, name):
        self.name = name