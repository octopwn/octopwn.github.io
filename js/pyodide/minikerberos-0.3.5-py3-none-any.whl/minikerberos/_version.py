
__version__ = "0.3.5"
__banner__ = \
"""
# minikerberos %s 
# Author: Tamas Jos @skelsec (skelsecprojects@gmail.com)
""" % __version__