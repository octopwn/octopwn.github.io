import random

default_crypto_random = random.SystemRandom()
default_pseudo_random = random.Random()
