
__version__ = "0.2.0"
__banner__ = \
"""
# aardwolf %s 
# Author: Tamas Jos @skelsec (info@skelsecprojects.com)
""" % __version__