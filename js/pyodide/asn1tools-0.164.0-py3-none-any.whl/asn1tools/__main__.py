from . import _main as main

main()
