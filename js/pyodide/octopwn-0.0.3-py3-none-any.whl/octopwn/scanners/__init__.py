from octopwn.scanners.smbos import SMBFingerScanner
from octopwn.scanners.smbfile import SMBFileScanner
from octopwn.scanners.smbadmin import SMBAdminScanner
from octopwn.scanners.smbsession import SMBSessionScanner
from octopwn.scanners.smbiface import SMBIfaceScanner
from octopwn.scanners.smbprotocol import SMBProtocolScanner
from octopwn.scanners.smbprintnightmare import SMBPrintnightmareScanner
from octopwn.scanners.smbregdump import SMBRegdumpScanner
from octopwn.scanners.rdpscreen import RDPScreenshotScanner
from octopwn.scanners.rdplogin import RDPLoginScanner
from octopwn.scanners.rdpcap import RDPCapScanner
from octopwn.scanners.jackdaw import JackdawScanner
from octopwn.scanners.krb5userenum import KRB5UserEnum
from octopwn.scanners.tcpportscanner import TCPPortScanner

OCTOPWN_SCANNER_TABLE = {
	'SMBSESSION': (SMBSessionScanner,  'Enumerates SMB sessions on the target'),
	'SMBPROTO'  : (SMBProtocolScanner, 'SMB dialect and NTLM signing flags enum'),
	'SMBPRINTNIGHTMARE'  : (SMBPrintnightmareScanner, 'Checks if target is vulnerable to printnightmare'),
	'SMBFINGER': (SMBFingerScanner, 'Scans targets for OS type and version'),
	'SMBIFACE': (SMBIfaceScanner, 'Enumerates all network interfaces on target'),
	'SMBADMIN': (SMBAdminScanner, 'Tries to guess wether the user is admin on the targets'),
	'SMBREGDUMP': (SMBRegdumpScanner, 'SMB remote registry secrets dumper'),
	'SMBFILE': (SMBFileScanner, 'Enumerates all shares/folders/files on targets'),
	'RDPSCREEN': (RDPScreenshotScanner, 'RDP screenshot scanner'),
	'RDPLOGIN': (RDPLoginScanner, 'RDP login scanner'),
	'RDPCAP': (RDPCapScanner, 'RDP capabilities scanner'),
	'KRB5USER': (KRB5UserEnum, 'Kerberos user enumerator'),
	'PORTSCAN': (TCPPortScanner, 'Basic prot scanner'),
	'JACKDAW': (JackdawScanner, 'Domain enumeration and stuff'),
}

from octopwn.common.utils import get_table_help

OCTOPWN_SCANNER_TABLE_HELP = get_table_help(OCTOPWN_SCANNER_TABLE)