import traceback
import asyncio
import os
import platform
import copy

from aardwolf import logger as rdplogger
from aardwolf.examples.scanners.rdplogin import RDPLoginScanner as RDPLoginExecutor
from octopwn.remote.protocol.python import messages_pb2, rdp_pb2
from octopwn.clients.scannerbase import ScannerConsoleBase
from aardwolf.commons.iosettings import RDPIOSettings
from asyauth.common.constants import asyauthProtocol
from asysocks.unicomm.common.scanner.targetgen import UniTargetGen
from asysocks.unicomm.common.scanner.scanner import UniScanner
from asysocks.unicomm.common.scanner.common import ScannerResultType


class RDPLoginScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'credential': (int, None),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'authtype': (str, 'NTLM'),
			'screentime' : (int, 5),
			'workercount' : (int,100),
			'output_type' : (str, 'png'),
			'proxy': (int, None),
			'resultsfile': (str, 'rdp_scan_login_%s.tsv' % os.urandom(4).hex())
		}
		self.ext_result_q = None

		self.enumerator_task = None
		self.monitor_task = None
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self, h_token = None, h_clientid = None):
		try:
			current_percent = 0.0
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				outfile = open(self.params['resultsfile'][1], 'a', newline = '')
			async for result in self.enumerator.scan():
				if result.type == ScannerResultType.STARTED:
					await self.print("Scan running!")
				elif result.type == ScannerResultType.FINISHED:
					await self.print("Scan finished!")
				elif result.type == ScannerResultType.PROGRESS:
					if h_token is not None:
						msg = messages_pb2.ScannerProgressEvt()
						msg.totalStages = 1
						msg.currentStage = 1
						msg.totalTargets = result.total
						msg.finishedTargets = result.current
						await self.remotemsg(msg)

					if result.total is not None and result.total > 0:
						percent = round((result.current / result.total)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (result.current, result.total, percent))
							current_percent = percent
				elif result.type == ScannerResultType.ERROR:
					await self.print(str(result.to_line()))
				
				elif result.type == ScannerResultType.DATA:
					x = result.to_line()
					if outfile is not None:
						outfile.write(x + '\r\n')
					else:
						await self.print(x.replace('\t', '|'))

					tid, err = await self.add_target(result.resid, source=str(type(self).__name__))
					if err is not None:
						await self.print('Failed to add new target!')
					else:
						if h_token is not None:
							msg = rdp_pb2.RDPLogin()
							msg.success = result.data.success
							await self.remoteres(tid, msg, remote_clientid = h_clientid)
					
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)

			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if outfile is not None:
				outfile.close()

	async def do_scan(self, h_token = None, h_clientid = None):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			iosettings = RDPIOSettings()
			iosettings.channels = []
			iosettings.video_out_format = 'pil'
			
			connection_factory, err = self.octopwnobj.get_rdp_factory_dummy(
				self.params['credential'][1],
				iosettings,
				authtype = asyauthProtocol(self.params['authtype'][1].upper()),
				pid = self.params['proxy'][1], 
				timeout = 5
			)
			if err is not None:
				raise err

			target_gens = UniTargetGen()
			
			for target in self.params['targetfiles'][1]:
				target_gens.add_file(target)
			
			target_gens.add_list(self.params['targets'][1])
			executors = [RDPLoginExecutor(connection_factory)]

			self.enumerator = UniScanner(
				str(type(self).__name__),
				executors,
				target_gens,
				worker_count = self.params['workercount'][1],
				host_timeout = 5
			)
			self.enumerator_task = asyncio.create_task(self.__monitor_queue(h_token, h_clientid))
			self.scan_running = True
			await self.print('[+] Scan started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])
			
			msg = messages_pb2.ScannerStartedEvt()
			await self.remotemsg(msg)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	