import platform
import traceback
import asyncio
import os
import pathlib
import copy
from datetime import datetime


from octopwn.clients.scannerbase import ScannerConsoleBase

from asysocks.unicomm.common.target import UniProto
from asyauth.common.constants import asyauthProtocol

from jackdaw.dbmodel import create_db, get_session
from jackdaw.gatherer.gatherer import Gatherer
from jackdaw.gatherer.rdns.rdns import DNSTarget


class JackdawScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')


		#sqlfile = 'sqlite:///%s/octopwn_%s.db' % (pathlib.Path().resolve(), os.urandom(4).hex())
		sqlfile = 'octopwn_%s.db' % os.urandom(4).hex()

		self.params = {
			'sqlfile' : (str, sqlfile),
			'credential': (int, None),
			'target' : (int, None),
			'dnstarget': (int, None),
			'proxy': (int, None),
			'use_ldaps' : (bool, False),
			'ldap_worker_cnt' : (int, 4),
			'ldap_timeout' : (int, 5),
			'ldap_authtype': (str, 'NTLM'),
			'smb_authtype': (str, 'NTLM'),
			'smb_worker_cnt' : (int, 100),
			'smb_gather_types' : (list, ['all']),
			'smb_enum_shares' : (bool, False),
			'smb_host_timeout' : (int, 5),
			'calc_edges': (bool, True),
		}

		self.ext_result_q = None
		self.graph_id = None

		self.enumerator_task = None
		self.monitor_task = None
		self.db_session = None
		self.db_dumped = False
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		
		await self.print('Target must be set to one of the DCs of the domain!')
		return True, None

	async def dumpdb(self):
		if self.db_dumped is True:
			await self.print('DB already dumped!')

		self.db_dumped = True
		if platform.system().lower() == 'emscripten':
			# we need to move, but in a way that doesn't block the entire browser
			await self.print('Moving DB to /volatile...')
			dbpath = '/volatile/%s' % self.params['sqlfile'][1]
			#shutil.move('/'+self.params['sqlfile'][1], dbpath)
			fpath = '/'+self.params['sqlfile'][1]
			fsize = os.path.getsize(fpath)
			lastprint = datetime.utcnow()
			total_written = 0
			with open(fpath, 'rb') as f:
				with open(dbpath, 'wb') as o:
					while True:
						data = f.read(1048576)
						if data == b'':
							break
						o.write(data)
						total_written += len(data)
						now = datetime.utcnow()
						if (now - lastprint).total_seconds() > 2:
							lastprint = now
							status = round( (total_written / fsize) * 100 ,2)
							await self.print('Moving file... %s%%' % status)
							await asyncio.sleep(0)
			os.remove(fpath)
			await self.print('Moving done! DB is here: %s' % dbpath)
		
		
	
	async def do_stop(self):
		try:
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if self.monitor_task is not None:
				self.monitor_task.cancel()
			await self.dumpdb()
			await self.print('Scan stopped!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self, finished_evt):
		try:
			while not finished_evt.is_set():
				data = await self.ext_result_q.get()
				await self.print(data)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def __enumerator_executor(self, finished_evt):
		try:
			_, err = await self.enumerator.run()
			if err is not None:
				raise err
			self.graph_id = self.enumerator.graph_id
			if self.db_session is not None:
				self.db_session.close()
			await self.print('Scan finished! Database file is here: %s' % self.params['sqlfile'][1])
			await self.print('AD ID %s created!' % self.graph_id)
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			finished_evt.set()
			self.scan_running = False
			if self.monitor_task is not None:
				self.monitor_task.cancel()
			await self.dumpdb()
			
			
			

	async def do_scan(self):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			if self.params['credential'][1] is None:
				await self.print("No credential set! Not starting scan")
				return False, None
			
			if self.params['target'][1] is None:
				await self.print("No target set! Please set target to on of the DCs in the doamin. Not starting scan")
				return False, None
			
			if platform.system().lower() != 'emscripten':
				sqlurl = 'sqlite:///%s/%s' % (pathlib.Path().resolve(), self.params['sqlfile'][1])
				create_db(sqlurl)
				self.db_session = get_session(sqlurl)
				os.environ['JACKDAW_SQLITE'] = '0'
				if self.params['sqlfile'][1].lower().startswith('sqlite'):
					os.environ['JACKDAW_SQLITE'] = '1'
			else:
				sqlurl = 'sqlite:////%s' % self.params['sqlfile'][1]
				create_db(sqlurl)
				self.db_session = get_session(sqlurl)
			
			smb_url, err = self.octopwnobj.get_smb_factory_dummy(
				int(self.params['credential'][1]), 
				authtype = asyauthProtocol(self.params['smb_authtype'][1]),
				pid = self.params['proxy'][1],
				timeout =  self.params['smb_host_timeout'][1],
			)
			if err is not None:
				raise err

			# LDAP URL
			ldap_url, err = self.octopwnobj.get_ldap_factory(
				int(self.params['credential'][1]),
				int(self.params['target'][1]),
				proto = UniProto.CLIENT_SSL_TCP if self.params['use_ldaps'][1] is True else UniProto.CLIENT_TCP,
				authtype = asyauthProtocol(self.params['ldap_authtype'][1]),
				pid = self.params['proxy'][1],
				timeout = self.params['ldap_timeout'][1], 
			)
			if err is not None:
				raise err

			# KERBEROS URL
			kerberos_url, err = self.octopwnobj.get_kerberos_url(
				int(self.params['credential'][1]),
				int(self.params['target'][1]),
				pid = self.params['proxy'][1],
				timeout= 5
			)
			if err is not None:
				raise err

			# DNS
			tdns = self.params['dnstarget'][1]
			if self.params['dnstarget'][1] is None:
				tdns = self.params['target'][1]
			dnstarget = self.octopwnobj.targets[tdns]
			dnsport = 53

			dnsproxy = None
			if self.params['proxy'][1] is not None:
				dnsproxy = copy.deepcopy(self.octopwnobj.proxies[self.params['proxy'][1]])
				dnsproxy = dnsproxy.get_proxy(dnstarget.get_hostname_or_ip(), dnsport,)
			
			dns = DNSTarget(
				dnstarget.get_hostname_or_ip(), 
				port = dnsport, 
				protocol = 'TCP', 
				timeout = self.params['ldap_timeout'][1], 
				proxy = dnsproxy
			)

			finished_evt = asyncio.Event()
			self.ext_result_q = asyncio.Queue()
			self.monitor_task = asyncio.create_task(self.__monitor_queue(finished_evt))

			mp_pool = None
			work_dir = '/volatile/jdgather_%s' % self.client_id
			if platform.system() != 'Emscripten':
				import multiprocessing
				mp_pool = multiprocessing.Pool()
				work_dir = './jdgather_%s' % self.client_id
			
			self.enumerator = Gatherer(
				self.db_session,
				work_dir,
				ldap_url,
				smb_url,
				kerb_url=kerberos_url,
				ldap_worker_cnt=self.params['ldap_worker_cnt'][1], 
				smb_worker_cnt=self.params['smb_worker_cnt'][1], 
				mp_pool=mp_pool, 
				smb_gather_types=['all'], 
				show_progress=False,
				calc_edges=self.params['calc_edges'][1],
				dns=dns,
				no_work_dir=False,
				progress_queue = self.ext_result_q,
				keep_sd_file = True
			)
			
			self.scan_running = True

			self.enumerator_task = asyncio.create_task(self.__enumerator_executor(finished_evt))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	