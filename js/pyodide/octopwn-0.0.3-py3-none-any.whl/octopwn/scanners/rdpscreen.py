import traceback
import asyncio
import os
import copy
import platform

from octopwn.clients.scannerbase import ScannerConsoleBase

from aardwolf import logger as rdplogger
from aardwolf.examples.scanners.rdpscreen import RDPScreenshotScanner as RDPScreenExecutor
from octopwn.remote.protocol.python import messages_pb2, rdp_pb2
from octopwn.clients.scannerbase import ScannerConsoleBase
from asyauth.common.constants import asyauthProtocol
from asysocks.unicomm.common.scanner.targetgen import UniTargetGen
from asysocks.unicomm.common.scanner.scanner import UniScanner
from asysocks.unicomm.common.scanner.common import ScannerResultType
from aardwolf.protocol.x224.constants import SUPP_PROTOCOLS
from aardwolf.commons.iosettings import RDPIOSettings


class RDPScreenshotScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'credential': (int, None, 'CID of credential to use. Use -1 for uncredentialed scanning'),
			'targets' : (list, [], 'List of targets to scan. IP/CDIR/file/hostname'),
			'targetfiles' : (list, []),
			'authtype': (str, 'NTLM', 'Authenticaton protocol'),
			'screentime' : (int, 5, 'Wait for N seconds for frame data'),
			'workercount' : (int,100, 'Parallelization'),
			'proxy': (int, None, 'PID of proxy to use'),
			'resultsfolder': (str, './', 'Folder path to write results to. Set it to empty string to print results to screen')
		}
		self.enumerator_task = None
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self, h_token = None, h_clientid = None):
		try:
			current_percent = 0.0
			outfolder = None
			if self.params['resultsfolder'][1] is not None and len(self.params['resultsfolder'][1]) != 0:
				outfolder = self.octopwnobj.sanitize_path(self.params['resultsfolder'][1])
			async for result in self.enumerator.scan():
				if result.type == ScannerResultType.STARTED:
					await self.print("Scan running!")
				elif result.type == ScannerResultType.FINISHED:
					await self.print("Scan finished!")
				elif result.type == ScannerResultType.PROGRESS:
					if h_token is not None:
						msg = messages_pb2.ScannerProgressEvt()
						msg.totalStages = 1
						msg.currentStage = 1
						msg.totalTargets = result.total
						msg.finishedTargets = result.current
						await self.remotemsg(msg)

					if result.total is not None and result.total > 0:
						percent = round((result.current / result.total)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (result.current, result.total, percent))
							current_percent = percent
				elif result.type == ScannerResultType.ERROR:
					await self.print(str(result.to_line()))
					#await self.print(str(result.to_traceback()))
				
				elif result.type == ScannerResultType.DATA:
					x = result.to_line()
					if outfolder is not None:
						with open(os.path.join(outfolder, result.get_fname()), 'wb') as f:
							f.write(result.get_fdata())
					else:
						await self.print(x.replace('\t', '|'))

					tid, err = await self.add_target(result.resid, source=str(type(self).__name__))
					if err is not None:
						continue
					else:
						if h_token is not None:
							msg = rdp_pb2.RDPScreenshot()
							msg.format = 'PNG'
							msg.data = result.data.screendata
							await self.remoteres(tid, msg, remote_clientid = h_clientid)
					
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)

			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()

	async def do_scan(self, h_token = None, h_clientid = None):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return

			iosettings = RDPIOSettings()
			iosettings.channels = []
			iosettings.video_out_format = 'pil'
			
			connection_factory, err = self.octopwnobj.get_rdp_factory_dummy(
				self.params['credential'][1],
				iosettings,
				authtype = asyauthProtocol(self.params['authtype'][1].upper()),
				pid = self.params['proxy'][1], 
				timeout = 5
			)
			if err is not None:
				raise err

			target_gens = UniTargetGen()
			
			for target in self.params['targetfiles'][1]:
				target_gens.add_file(target)
			
			target_gens.add_list(self.params['targets'][1])
			

			executors = [RDPScreenExecutor(connection_factory)]

			self.enumerator = UniScanner(
				str(type(self).__name__),
				executors,
				target_gens,
				worker_count = self.params['workercount'][1],
				host_timeout = 5
			)
			self.enumerator_task = asyncio.create_task(self.__monitor_queue(h_token, h_clientid))
			self.scan_running = True
			await self.print('[+] Scan started!')
			if self.params['resultsfolder'][1] is not None and len(self.params['resultsfolder'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfolder'][1])
			
			msg = messages_pb2.ScannerStartedEvt()
			await self.remotemsg(msg)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	