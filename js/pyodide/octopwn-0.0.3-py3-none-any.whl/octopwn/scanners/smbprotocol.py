import asyncio
import copy
import os
import platform

from octopwn.remote.protocol.python import messages_pb2, smb_pb2
from octopwn.clients.scannerbase import ScannerConsoleBase
from asyauth.common.constants import asyauthProtocol
from asysocks.unicomm.common.scanner.targetgen import UniTargetGen
from asysocks.unicomm.common.scanner.scanner import UniScanner
from asysocks.unicomm.common.scanner.common import ScannerResultType
from aiosmb.examples.scanners.smbproto import SMBProtocolScanner as SMBProtocolExecutor


class SMBProtocolScanner(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.params = {
			'workercount' : (int,100, 'CID of credential to use'),
			'targets' : (list, [], 'List of targets to scan. IP/CDIR/file/hostname'),
			'targetfiles' : (list, []),
			'timeout' : (int,5, 'Timeout'),
			'proxy': (int, None, 'PID of proxy to use'),
			'maxruntime' : (int, 600, 'Maximum runtime per host'),
			'showerrors': (bool, False, 'Show errors from targets'),
			'resultsfile': (str, 'smb_scan_protocol_%s.tsv' % os.urandom(4).hex(), 'File path to write results to. Set it to empty string to print results to screen')
		}
		self.enumerator_task = None
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self, h_token = None, h_clientid = None):
		try:
			current_percent = 0.0
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				resfile = self.octopwnobj.sanitize_path(self.params['resultsfile'][1])
				outfile = open(resfile, 'a', newline = '')
			async for result in self.enumerator.scan():
				if result.type == ScannerResultType.STARTED:
					await self.print("Scan running!")
				elif result.type == ScannerResultType.FINISHED:
					await self.print("Scan finished!")
				elif result.type == ScannerResultType.PROGRESS:
					if h_token is not None:
						msg = messages_pb2.ScannerProgressEvt()
						msg.totalStages = 1
						msg.currentStage = 1
						msg.totalTargets = result.total
						msg.finishedTargets = result.current
						await self.remotemsg(msg)

					if result.total is not None and result.total > 0:
						percent = round((result.current / result.total)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (result.current, result.total, percent))
							current_percent = percent
				elif result.type == ScannerResultType.ERROR:
					if self.params['showerrors'][1] is True:
						await self.print(str(result.to_line('|')))
				
				elif result.type == ScannerResultType.DATA:
					x = result.to_line()
					if outfile is not None:
						outfile.write(x + '\r\n')
					else:
						await self.print(x.replace('\t', '|'))

					tid, err = await self.add_target(result.resid, source=str(type(self).__name__))
					if err is not None:
						continue
					else:
						if h_token is not None:
							msg = smb_pb2.SMBProto()
							msg.dialect = str(result.data.session.protores)
							msg.signingenabled = bool(result.data.signing_enabled)
							msg.signingrequired = bool(result.data.signing_required)
							await self.remoteres(tid, msg, remote_clientid = h_clientid)
					
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)

			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if outfile is not None:
				outfile.close()

	async def do_scan(self, h_token = None, h_clientid = None):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			connection_factory, err = self.octopwnobj.get_smb_factory_dummy(
				-1,
				authtype = asyauthProtocol.NTLM,
				pid = self.params['proxy'][1], 
				timeout = self.params['timeout'][1],
			)
			
			target_gens = UniTargetGen()
			
			for target in self.params['targetfiles'][1]:
				target_gens.add_file(target)
			
			target_gens.add_list(self.params['targets'][1])
			executors = [SMBProtocolExecutor(connection_factory)]

			self.enumerator = UniScanner(
				str(type(self).__name__),
				executors,
				target_gens,
				worker_count = self.params['workercount'][1],
				host_timeout = self.params['maxruntime'][1],
			)
		
			self.enumerator_task = asyncio.create_task(self.__monitor_queue(h_token, h_clientid))
			self.scan_running = True
			await self.print('[+] Scan started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])
			
			msg = messages_pb2.ScannerStartedEvt()
			await self.remotemsg(msg)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	