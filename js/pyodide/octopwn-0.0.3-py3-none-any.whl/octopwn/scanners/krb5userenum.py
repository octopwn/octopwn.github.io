import traceback
import asyncio
import os
import copy
import platform

from octopwn.remote.protocol.python import messages_pb2, scanner_pb2
from octopwn.clients.scannerbase import ScannerConsoleBase
from asysocks.unicomm.common.scanner.targetgen import UniTargetGen
from asysocks.unicomm.common.scanner.scanner import UniScanner
from asysocks.unicomm.common.scanner.common import ScannerResultType, ScannerData, ScannerInfo, ScannerError
from asysocks.unicomm.client import UniClient
from asysocks.unicomm.common.target import UniTarget, UniProto

from minikerberos.common.spn import KerberosSPN
from minikerberos.security import KerberosUserEnum
from octopwn.clients.scannerbase import ScannerConsoleBase

class KRB5UserResult:
	def __init__(self,username):
		self.username = username

	def to_line(self, separator = '\t'):
		return self.username

class KRB5UserEnumExecutor:
	def __init__(self, ktarget, realm):
		self.ktarget = ktarget
		self.realm = realm
	
	async def run(self, targetid, target, out_queue):
		username = target
		spn = KerberosSPN()
		spn.domain = self.realm
		spn.username = username

		test = KerberosUserEnum(self.ktarget, spn)
		res = await test.run()
		if res is True:
			await out_queue.put(ScannerData(targetid, KRB5UserResult(str(spn))))
		

class KRB5UserEnum(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'target' : (str, None, 'TID of Kerberos server'),
			'usernames' : (list, [], 'List of usernames to try. Separate them with comma ","'),
			'usernamefiles' : (list, [], 'Files containing usernames. One per line'),
			'realm' : (str, None, 'Realm (domain name). This must be set!'),
			'workercount' : (int, 10, 'Parallelization'),
			'proxy': (int, None, 'PID of proxy to use'),
			'resultsfile': (str, 'krb5userenum_%s.tsv' % os.urandom(4).hex(), 'File path to write results to. Set it to empty string to print results to screen')
		}

		self.enumerator_task = None
	
	async def start(self):
		if platform.system().lower() == 'emscripten' and self.params['proxy'][1] is None:
			
			await self.do_setparam('proxy', 0)
		return True, None
	
	async def do_stop(self):
		try:
			self.enumerator_task.cancel()
			await self.print('[!] Scan stopped!')
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			self.scan_running = False
	
	async def __monitor_queue(self, h_token = None, h_clientid = None):
		try:
			current_percent = 0.0
			outfile = None
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				resfile = self.octopwnobj.sanitize_path(self.params['resultsfile'][1])
				outfile = open(resfile, 'a', newline = '')
			async for result in self.enumerator.scan():
				if result.type == ScannerResultType.STARTED:
					await self.print("Scan running!")
				elif result.type == ScannerResultType.FINISHED:
					await self.print("Scan finished!")
				elif result.type == ScannerResultType.PROGRESS:
					if h_token is not None:
						msg = messages_pb2.ScannerProgressEvt()
						msg.totalStages = 1
						msg.currentStage = 1
						msg.totalTargets = result.total
						msg.finishedTargets = result.current
						await self.remotemsg(msg)

					if result.total is not None and result.total > 0:
						percent = round((result.current / result.total)*100, 2)
						if abs(current_percent - percent) > 0.5:
							await self.print('[+] Scan progress: %s/%s (%s %%)' % (result.current, result.total, percent))
							current_percent = percent
				elif result.type == ScannerResultType.ERROR:
					await self.print(str(result.to_line()))
				
				elif result.type == ScannerResultType.DATA:
					x = result.to_line()
					if outfile is not None:
						outfile.write(x + '\r\n')
					else:
						await self.print(x.replace('\t', '|'))					
			
			await self.print('[+] Scan finished!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		finally:
			msg = messages_pb2.ScannerStoppedEvt()
			await self.remotemsg(msg)

			self.scan_running = False
			if self.enumerator_task is not None:
				self.enumerator_task.cancel()
			if outfile is not None:
				outfile.close()


	async def do_scan(self, h_token = None, h_clientid = None):
		"""Start enumeration"""
		try:
			if self.scan_running is True:
				await self.print("Scan is still running. Can\'t start new scan here")
				return
			
			if self.params['realm'][1] is None:
				await self.print("Realm must be set!")
				return
			
			
			if self.params['target'][1] is None:
				await self.print("Target must be set! (eg. the DC)")
				return

			target_gens = UniTargetGen()
			target = copy.deepcopy(self.octopwnobj.targets[int(self.params['target'][1])])
			proxy = None
			if self.params['proxy'][1] is not None:
				proxy = copy.deepcopy(self.octopwnobj.proxies[self.params['proxy'][1]])
				proxy = proxy.get_proxy('', 0)
				
			
			kerberostarget = target.get_kerberos_target(proxy, timeout=10)
			
			for target in self.params['usernamefiles'][1]:
				target_gens.add_file(target)
			
			target_gens.add_list(self.params['usernames'][1])
			executors = [KRB5UserEnumExecutor(kerberostarget, self.params['realm'][1])]

			self.enumerator = UniScanner(
				str(type(self).__name__),
				executors,
				target_gens,
				worker_count = self.params['workercount'][1],
				host_timeout = 5
			)
			self.enumerator_task = asyncio.create_task(self.__monitor_queue(h_token, h_clientid))
			self.scan_running = True
			await self.print('[+] Scan started!')
			if self.params['resultsfile'][1] is not None and len(self.params['resultsfile'][1]) != 0:
				await self.print('[+] Results will be written to: %s' % self.params['resultsfile'][1])
			
			msg = messages_pb2.ScannerStartedEvt()
			await self.remotemsg(msg)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e