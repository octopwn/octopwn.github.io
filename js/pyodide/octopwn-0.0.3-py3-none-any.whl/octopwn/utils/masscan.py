import xml.etree.ElementTree as ET

from octopwn.common.utils import don
from octopwn.clients.scannerbase import ScannerConsoleBase
from octopwn.common.target import Target

class MasscanUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.xmlfile = None
		self.tree = None
		self.root = None
		self.hosts = {}

	async def do_load(self, filepath):
		try:
			self.xmlfile = filepath
			self.tree = ET.parse(self.xmlfile)
			self.root = self.tree.getroot()
			for data in self.root.iter('host'):
				addr = None
				ports = []
				for child in list(data):
					if child.tag == 'address':
						addr = child.attrib.get('addr')
					elif child.tag == 'ports':
						for port in list(child):
							protocol = port.attrib.get('protocol', 'tcp')
							portid = port.attrib.get('portid')
							ports.append((portid, protocol))
				
				if addr not in self.hosts:
					self.hosts[addr] = {}
				for pt in ports:
					self.hosts[addr][pt[0]] = 1
			
			await self.print('File loaded!')
		
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def do_addtargets(self):
		"""Populates the target list in octopwn with the IP addresses found in this scan file"""
		try:
			for host in self.hosts:				
				target = Target(
					host, 
					hostname = None,
					ports = self.hosts[host],
					source = 'MASSCAN:%s' % (self.xmlfile)
				)
				await self.octopwnobj.addtarget_obj(target)
			
		except Exception as e:
			await self.print_exc(e)
			return None, e
		
