from octopwn.clients.scannerbase import ScannerConsoleBase

class ChatUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj, command_modifier=':')
		self.nologon_commands.append('any')
	

	async def console_command_handler(self, cmd:str, h_username:str = None):
		await self.print(cmd, h_username)