from octopwn.clients.scannerbase import ScannerConsoleBase

class ChatUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('say')
	
	async def do_say(self, data:str):
		try:
			await self.print(data)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e