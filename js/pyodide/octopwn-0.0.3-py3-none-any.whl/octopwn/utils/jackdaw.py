import asyncio
import json
import pathlib
import string
import ipaddress
import platform
import os
from typing import cast
from datetime import datetime

from octopwn.common.utils import hexdump, create_random_filepath
from octopwn.clients.scannerbase import ScannerConsoleBase
from jackdaw import logger as jdlogger

from jackdaw.dbmodel import create_db, get_session
from jackdaw.dbmodel.graphinfo import GraphInfo, GraphInfoAD
from jackdaw.dbmodel.adgroup import Group
from jackdaw.dbmodel.edgelookup import EdgeLookup
from jackdaw.dbmodel.edge import Edge
from jackdaw.dbmodel.aduser import ADUser
from jackdaw.dbmodel.adinfo import ADInfo
from jackdaw.dbmodel.adcomp import Machine
from jackdaw.dbmodel.adou import ADOU
from jackdaw.dbmodel.adobjprops import ADObjProps
from jackdaw.dbmodel.adtrust import ADTrust
from jackdaw.dbmodel.kerberoast import Kerberoast
from jackdaw.dbmodel.netshare import NetShare
from jackdaw.dbmodel.dnslookup import DNSLookup
from jackdaw.dbmodel.credential import Credential
from jackdaw.dbmodel.hashentry import HashEntry
from jackdaw.dbmodel.netsession import NetSession
from jackdaw.credentials.credentials import JackDawCredentials
from jackdaw.utils.bhimportasync import BHImport
from jackdaw.nest.graph.graphdata import GraphData
from jackdaw.nest.graph.construct import GraphConstruct
from jackdaw.nest.graph.domaindiff import DomainDiff
from jackdaw.nest.graph.backends.networkx.domaingraph import JackDawDomainGraphNetworkx
from sqlalchemy.exc import IntegrityError
from sqlalchemy import func




def exclude_parse(exclude):
	#sadly connexion is not capable to do this by itself
	res = []
	if exclude is None:
		return res
	for p in exclude.split(','):
		res.append(p.strip())
	
	return res

class JackdawUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.graph_cache_dir = pathlib.Path().resolve()
		self.db_session = None
		self.graph = None
		self.graphid = None
		self.sqlitefile = None
		self.current_adid = None
		jdlogger.setLevel(100)

	async def __pyodide_create_graph(self):
		try:
			from pyodide import create_proxy
			from pyodide.ffi import to_js
			#path_calc_cb = create_proxy(self.mouse_evt)
			#node_set_cb = create_proxy(self.keyboard_evt)
			#node_info_cb = create_proxy(self.paste_evt)
			path_calc_cb = create_proxy(self.pyodide_path_calc)
			node_set_cb  = None
			node_search_cb = create_proxy(self.search)
			
			_, err = await self.octopwnobj.screen_handler.create_graph_canvas(self.client_id, self.graphid, path_calc_cb, node_set_cb, node_search_cb)
			if err is not None:
				raise err
			return True, None
		except Exception as e:
			return None, e

	async def __pyodide_update_graph(self, data:GraphData):
		try:
			#from pyodide import to_js
			from pyodide.ffi import to_js
			# graphdata_json -> {nodes: [], edges: []}
			graphdata_json = json.dumps(data.to_dict(format='vis'))
			_, err = await self.octopwnobj.screen_handler.update_graph_canvas(self.client_id, self.graphid, to_js(graphdata_json))
			if err is not None:
				raise err
		except Exception as e:
			return None, e
	
	async def pyodide_path_calc(self, pathtype:str, src:str = None, dst:str = None, exclude:str = None):
		try:
			if pathtype == 'TODA':
				await self.do_pathtoda(excludededges=exclude, to_print=False)
			elif pathtype == 'KERBEROASTTODA':
				await self.do_pathkerberoastda(excludededges=exclude,to_print=False)
			elif pathtype == 'ASREPROASTTODA':
				await self.do_pathasrepda(excludededges=exclude,to_print=False)
			elif pathtype == 'DCSYNC':
				await self.do_pathdcsync(excludededges=exclude,to_print=False)
			elif pathtype == 'HVTTODA':
				await self.do_pathhvtda(excludededges=exclude,to_print=False)
			elif pathtype == 'OWNEDTODA':
				await self.do_pathownedda(excludededges=exclude,to_print=False)
			elif pathtype == 'OWNEDTOHVT':
				await self.do_pathownedhvt(excludededges=exclude,to_print=False)
			elif pathtype == 'OWNEDTOANY':
				await self.do_pathfromowned(excludededges=exclude,to_print=False)
			elif pathtype == 'PATH':
				await self.do_path(src, dst, excludededges=exclude, to_print=False, pathonly=False)
		except Exception as e:
			await self.print_exc(e)

			
	async def do_chgraphdir(self, graph_cache_dir):
		"""Changes graphcache directory"""
		self.graph_cache_dir = pathlib.Path(graph_cache_dir)

	async def do_bhimport(self, bhfile):
		"""Import data gathered via BloodHound. Creates a new DB"""
		try:
			dbname = 'bhimport_%s.db' % os.urandom(4).hex()
			if platform.system() == 'Emscripten':
				dbname = '/%s' % dbname
			db_conn = 'sqlite:///%s' % dbname
			await self.print('Creating DB at: %s' % db_conn)
			create_db(db_conn)
			bh = BHImport.from_zipfile(bhfile)
			bh.db_conn = db_conn
			bh.set_debug(False)
			bh.aprint = self.print
			await bh.run()
			await self.print('Conversion done!')
			if platform.system() == 'Emscripten':
				await self.print('Moving DB to /volatile...')
				dbpath = '/volatile/%s' % dbname
				fsize = os.path.getsize(dbname)
				lastprint = datetime.utcnow()
				total_written = 0
				with open(dbname, 'rb') as f:
					with open(dbpath, 'wb') as o:
						while True:
							data = f.read(1048576)
							if data == b'':
								break
							o.write(data)
							total_written += len(data)
							now = datetime.utcnow()
							if (now - lastprint).total_seconds() > 2:
								lastprint = now
								status = round( (total_written / fsize) * 100 ,2)
								await self.print('Moving file... %s%%' % status)
								await asyncio.sleep(0)
				os.remove(dbname)
				await self.print('Moving done! DB is here: %s' % dbpath)


		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_dbload(self, sqlitefile, force_load = False):
		"""Loads SQLITE database"""
		try:
			if self.db_session is not None and force_load is False:
				await self.print('DB is already loaded! Use "force_load" param to close prev session and load a new one!')
				return None, Exception('DB is already loaded! Use "force_load" param to close prev session and load a new one!')

			self.sqlitefile = sqlitefile
			sqlurl = 'sqlite:///%s' % sqlitefile
			self.db_session = get_session(sqlurl)
			await self.print('DB loaded!')
			adid = self.db_session.query(ADInfo.id).first()
			await self.do_changead(adid[0])			
			return self.db_session, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_graphload(self, graphid, cachefile = None):
		"""Loads SQLITE database, generates graph cache file"""
		try:
			if self.db_session is None:
				await self.print('DB is not loaded! Use "dbload" before running this command!')
				return None, None		

			self.graphid = int(graphid)
			if cachefile is None or len(cachefile) == 0:
				await self.print('Generating graph cache!')
				await asyncio.sleep(0.1)
				cachefile = JackDawDomainGraphNetworkx.create(self.db_session, self.graphid, self.graph_cache_dir, show_progress=False)
				await self.print('Graph cache file generated!')
			
			await self.print('Loading graph data...')
			await asyncio.sleep(0.1)
			self.graph = JackDawDomainGraphNetworkx.load(self.db_session, self.graphid, self.graph_cache_dir, use_cache = True, graph_file = cachefile)
			await self.print('Graph data loaded!')
			
			if platform.system() == 'Emscripten':
				await self.__pyodide_create_graph()
			
			return True, None

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def pathprint(self, paths):
		"""Takes a list of paths and prints them in a user-friendly command"""
		if isinstance(paths, list):
			for path in paths:
				if len(path) == 1:
					continue
				res = ''
				for i, item in enumerate(path):
					if i % 2 == 0:
						res += '[%s]' % item[0]
					else:
						res += ' => %s => ' % item
				await self.print(res)
		else:
			await self.print('To be implemented...')
			return

	def curdomains(self):
		for domain_id in self.db_session.query(GraphInfoAD.ad_id).filter_by(graph_id = self.graphid).all():
			yield domain_id[0]


	async def do_pathdcsync(self, excludededges = None, pathonly = None, to_print=True):
		"""Nodes with dcsync access"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
				
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)

			res = GraphData()
			res += self.graph.get_dcsync()

			if to_print is True:
				await self.pathprint(res)
			
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)

			return res, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def do_pathkerberoastda(self, excludededges = None, pathonly = None, to_print=True):
		"""Paths from kerberoastable users to DA"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
				
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)

			target_sids = {}
			da_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(Group).filter_by(ad_id = domain_id).filter(Group.objectSid.like('%-512')).all():
					da_sids[res.objectSid] = 0

				for res in self.db_session.query(ADUser.objectSid)\
					.filter_by(ad_id = domain_id)\
					.filter(ADUser.servicePrincipalName != None).all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for dst_sid in da_sids:
				for src_sid in target_sids:
					res += self.graph.shortest_paths(src_sid, dst_sid, exclude = exclude_edgetypes)
			
			if to_print is True:
				await self.pathprint(res)
			
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)

			return res, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathasrepda(self, excludededges = None, pathonly = None, to_print=True):
		"""Path from asreproastable users to DA"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
					
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)
		
			target_sids = {}
			da_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(Group).filter_by(ad_id = domain_id).filter(Group.objectSid.like('%-512')).all():
					da_sids[res.objectSid] = 0

				for res in self.db_session.query(ADUser.objectSid)\
					.filter_by(ad_id = domain_id)\
					.filter(ADUser.UAC_DONT_REQUIRE_PREAUTH == True).all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for dst_sid in da_sids:
				for src_sid in target_sids:
					res += self.graph.shortest_paths(src_sid, dst_sid, exclude = exclude_edgetypes)

			if to_print is True:
				await self.pathprint(res)
			
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)

			return res, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathhvtda(self, excludededges = None, pathonly = None, to_print=True):
		"""Path to HVT from anywhere"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
						
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)

			target_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(EdgeLookup.oid)\
					.filter_by(ad_id = domain_id)\
					.filter(EdgeLookup.oid == ADObjProps.oid)\
					.filter(ADObjProps.graph_id == self.graphid)\
					.filter(ADObjProps.prop == 'HVT')\
					.all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for dst_sid in target_sids:
				res += self.graph.shortest_paths(dst_sid=dst_sid, ignore_notfound = True, exclude = exclude_edgetypes)
				
			if to_print is True:
					await self.pathprint(res)
				
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)

			return res, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathownedda(self, excludededges = None, pathonly = None, to_print=True):
		"""Path from owned users to DA"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
						
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)

			target_sids = {}
			da_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(Group).filter_by(ad_id = domain_id).filter(Group.objectSid.like('%-512')).all():
					da_sids[res.objectSid] = 0


				for res in self.db_session.query(EdgeLookup.oid)\
					.filter_by(ad_id = domain_id)\
					.filter(EdgeLookup.oid == ADObjProps.oid)\
					.filter(ADObjProps.graph_id == self.graphid)\
					.filter(ADObjProps.prop == 'OWNED')\
					.all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for dst_sid in da_sids:
				for src_sid in target_sids:
					res += self.graph.shortest_paths(src_sid, dst_sid, exclude = exclude_edgetypes, ignore_notfound = True)

			if to_print is True:
				await self.pathprint(res)
				
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)
			
			
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathfromowned(self, excludededges = None, pathonly = None, to_print=True):
		"""Path from owned users to anywhere"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
						
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)
			target_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(EdgeLookup.oid)\
					.filter_by(ad_id = domain_id)\
					.filter(EdgeLookup.oid == ADObjProps.oid)\
					.filter(ADObjProps.graph_id == self.graphid)\
					.filter(ADObjProps.prop == 'OWNED')\
					.all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for src_sid in target_sids:
				res += self.graph.shortest_paths(src_sid=src_sid, exclude = exclude_edgetypes, ignore_notfound = True)
			
			if to_print is True:
				await self.pathprint(res)
				
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)

			return res, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathgettaggednodes(self, tag:str, to_print:bool = True):
		"""Returns a list of tagged nodes"""
		try:
			tag = tag.upper()
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(EdgeLookup.oid)\
					.filter_by(ad_id = domain_id)\
					.filter(EdgeLookup.oid == ADObjProps.oid)\
					.filter(ADObjProps.graph_id == self.graphid)\
					.filter(ADObjProps.prop == tag)\
					.all():
					
					sids[res[0]] = 0
					if to_print is True:
						await self.print(res[0])
			
			return list(sids.keys()), None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathownedhvt(self, excludededges = None, pathonly = None, to_print=True):
		"""Path from owned users to HVT"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
						
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)

			source_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(EdgeLookup.oid)\
					.filter_by(ad_id = domain_id)\
					.filter(EdgeLookup.oid == ADObjProps.oid)\
					.filter(ADObjProps.graph_id == self.graphid)\
					.filter(ADObjProps.prop == 'OWNED')\
					.all():
					
					source_sids[res[0]] = 0

			target_sids = {}

			for domain_id in self.curdomains():
				for res in self.db_session.query(EdgeLookup.oid)\
					.filter_by(ad_id = domain_id)\
					.filter(EdgeLookup.oid == ADObjProps.oid)\
					.filter(ADObjProps.graph_id == self.graphid)\
					.filter(ADObjProps.prop == 'HVT')\
					.all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for src_sid in source_sids:
				for dst_sid in target_sids:
					res += self.graph.shortest_paths(src_sid=src_sid, dst_sid=dst_sid, exclude = exclude_edgetypes, ignore_notfound = True)

			if to_print is True:
				await self.pathprint(res)
				
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)

			return res, None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pathkerberoastany(self, excludededges = None, pathonly = None, to_print=True):
		"""Path from kerberoastable users to anywhere"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
					
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)

			target_sids = {}
			domain_sids = {}
			path_to_da = []

			for domain_id in self.curdomains():
				res = self.db_session.query(ADInfo).get(domain_id)
				domain_sids[res.objectSid] = 1

				for res in self.db_session.query(ADUser.objectSid)\
					.filter_by(ad_id = domain_id)\
					.filter(ADUser.servicePrincipalName != None).all():
					
					target_sids[res[0]] = 0

			res = GraphData()
			for src_sid in target_sids:
				for domain_sid in domain_sids:
					if self.graph.has_path(src_sid, domain_sid) is False:
						res += self.graph.shortest_paths(src_sid=src_sid, dst_sid = None, exclude = exclude_edgetypes)
					else:
						path_to_da.append(src_sid)

			if to_print is True:
				await self.pathprint(res)
			
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)
			
			return res, None
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	def parse_excludededges(self, excludededges):
		exclude_edgetypes = []
		if excludededges is not None:
			if isinstance(excludededges, list) is True:
				exclude_edgetypes = excludededges
			elif isinstance(excludededges, str) is True:
				for x in excludededges.split(','):
					if len(x) == 0:
						continue
					exclude_edgetypes.append(x)
			else:
				raise Exception('Unknown excludededges type! %s' % type(excludededges))
		return exclude_edgetypes

	async def do_pathtoda(self, excludededges:str = None, pathonly = None, to_print=True):
		"""Calculates shortest path to DA"""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
				
			else:
				pathonly = bool(int(pathonly))
			
			exclude_edgetypes = self.parse_excludededges(excludededges)
			
			#getting domains
			da_sids = {}
			for domain_id in self.curdomains():
				for res in self.db_session.query(Group).filter_by(ad_id = domain_id).filter(Group.objectSid.like('%-512')).all():
					da_sids[res.objectSid] = 0
			
			if len(da_sids) == 0:
				await self.print('No domain admin group found?!')
				return None, None

			#calculating path
			if pathonly is True:
				res = []
				for sid in da_sids:
					res += self.graph.shortest_paths(None, sid, exclude = exclude_edgetypes, pathonly=True)

				if to_print is True:
					await self.pathprint(res)
			else:
				res = GraphData()
				for sid in da_sids:
					res += self.graph.shortest_paths(None, sid, exclude = exclude_edgetypes, pathonly=False)
			
			if platform.system() == 'Emscripten' and pathonly is False:
				await self.__pyodide_update_graph(res)
			
			return res, None

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_path(self, src:str = None, dst:str = None, excludededges = None, maxhops = None, pathonly = True, to_print=True):
		"""Calculates shortest path between src and dst SIDs."""
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None
			
			if pathonly is None or pathonly == '':
				pathonly = True
				if platform.system() == 'Emscripten':
					pathonly = False
			else:
				pathonly = bool(int(pathonly))

			exclude_edgetypes = self.parse_excludededges(excludededges)
			if src == '':
				src = None
			if dst == '':
				dst = None
			if to_print is True:
				await self.print('Calculating path between %s => %s' % (src, dst))

			if maxhops is None or maxhops == '':
				maxhops = None
			else:
				maxhops = int(maxhops)
				if maxhops < 2:
					maxhops = 2
			if src is None and dst is None:
				# this is not accepted
				if to_print is True:
					await self.print('No paths found!')
				return ([], None) if pathonly is True else ({}, None)
			
			multipath_src = False
			multipath_dst = False
			if src is not None and src.upper() in ['HVT', 'OWNED']:
				src, err = await self.do_pathgettaggednodes(src.upper(), False)
				if err is not None:
					raise err
				multipath_src = True
			if dst is not None and dst.upper() in ['HVT', 'OWNED']:
				dst, err = await self.do_pathgettaggednodes(dst.upper(), False)
				if err is not None:
					raise err
				multipath_dst = True
			
			res = []
			if multipath_dst is True and multipath_src is True:
				for ns in src:
					for ds in dst:
						res += self.graph.shortest_paths(ns, ds, exclude = exclude_edgetypes, pathonly = pathonly, maxhops = maxhops, all_shortest = False, ignore_notfound = True)

			elif multipath_dst is True and multipath_src is False:
				for ds in dst:
					res += self.graph.shortest_paths(src, ds, exclude = exclude_edgetypes, pathonly = pathonly, maxhops = maxhops, all_shortest = False, ignore_notfound = True)
			
			elif multipath_dst is False and multipath_src is True:
				for ns in src:
					res += self.graph.shortest_paths(ns, dst, exclude = exclude_edgetypes, pathonly = pathonly, maxhops = maxhops, all_shortest = False, ignore_notfound = True)

			else:
				res = self.graph.shortest_paths(src, dst, exclude = exclude_edgetypes, pathonly = pathonly, maxhops = maxhops, all_shortest = False)
			
			if pathonly is True:
				if to_print is True:
					await self.pathprint(res)
				return res, None
			
			if platform.system() == 'Emscripten':
				await self.__pyodide_update_graph(res)
			
			if to_print is True:
				await self.pathprint(res)
			
			if multipath_dst is True or multipath_src is True:
				return res, None

			return res.to_dict(), None

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_oid(self, oid, otype = None, to_print = True):
		"""Resolves OID (SID) to the actual object"""
		try:
			res = None
			if otype is None:
				ele = self.db_session.query(EdgeLookup).filter_by(oid = oid).first()
				if ele is None or ele.otype is None or ele.otype == 'unknown':
					raise Exception('OID not found!')
				otype = ele.otype.lower()

			if otype == 'user':
				res = self.db_session.query(ADUser).filter_by(objectSid = oid).first()
			
			elif otype == 'group':
				res = self.db_session.query(Group).filter_by(objectSid = oid).first()

			elif otype == 'machine':
				res = self.db_session.query(Machine).filter_by(objectSid = oid).first()

			elif otype == 'trust':
				res = self.db_session.query(ADTrust).filter_by(securityIdentifier = oid).first()
			else:
				raise Exception('Unknown object type "%s"' % otype)
			
			if to_print is True:
				await self.print(res)
			
			return res, otype, None
				

		except Exception as e:
			await self.print_exc(e)
			return None, None, e

	async def do_graphids(self, to_print = True):
		"""Lists available Graph IDs"""
		try:
			res = [['GraphID', 'AD ID', 'AD NAME', 'AD DN', 'AD SID']]
			for graphid in self.db_session.query(GraphInfo.id).all():
				for adid in self.db_session.query(GraphInfoAD.ad_id).filter_by(graph_id = graphid[0]).all():
					adinfo = self.db_session.query(ADInfo).get(adid[0])
					res.append([str(graphid[0]), str(adid[0]), str(adinfo.name), str(adinfo.distinguishedName), str(adinfo.objectSid)])
			
			if to_print is True:
				await self.print_table(res)
			
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_adids(self, to_print = True):
		"""Lists available domain IDs"""
		try:
			res = [['AD ID', 'AD NAME', 'AD DN', 'AD SID']]
			for adinfo in self.db_session.query(ADInfo).all():
				res.append([str(adinfo.id), str(adinfo.name), str(adinfo.distinguishedName), str(adinfo.objectSid)])
			
			if to_print is True:
				await self.print_table(res)
			
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_currentad(self, to_print = True):
		"""Returns the current AD ID"""
		try:
			if to_print is True:
				await self.print('Current ADID is set to: %s' % self.current_adid)
			
			return self.current_adid, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_changead(self, adid, to_print = True):
		"""Changes the current AD ID"""
		try:
			self.current_adid = int(adid)
			if to_print is True:
				await self.do_currentad(True)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_trusts(self, to_print = True):
		"""Lists AD trusts for current ADID"""
		try:
			trusts = []
			pl = [['name', 'trustDirection', 'trustType', 'SID']]
			for trust in self.db_session.query(ADTrust).filter_by(ad_id = self.current_adid).all():
				trusts.append(trust)
				if to_print is True:
					pl.append([trust.name, trust.trustDirection, trust.trustType, trust.securityIdentifier])
			
			if to_print is True:
				if len(trusts) == 0:
					await self.print('No trusts found for current AD ID')
				else:
					await self.print_table(pl)

			return trusts, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_kerberoast(self, to_print = True):
		"""Lists spn/asreproast tickets"""
		try:
			tickets = []
			for ticket in self.db_session.query(Kerberoast.ticket).filter_by(ad_id = self.current_adid).all():
				tickets.append(ticket[0])
				if to_print is True:
					await self.print(ticket)
			
			if len(tickets) == 0 and to_print is True:
				await self.print('No tickets for current AD ID')

			return tickets, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_graphsetowned(self, oid, to_print = True):
		"""Sets given OID as owned"""
		try:
			p = ADObjProps(self.graphid, oid, 'OWNED')
			self.db_session.add(p)
			self.db_session.commit()
			
			if to_print is True:
				await self.print('Owned set for %s' % oid)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_graphclearowned(self, oid, to_print = True):
		"""Clears owned status for OID"""
		try:
			for res in self.db_session.query(ADObjProps).filter_by(oid = oid).filter(ADObjProps.prop == 'OWNED').filter(ADObjProps.graph_id == self.graphid).all():
				self.db_session.delete(res)
				self.db_session.commit()
			
			if to_print is True:
				await self.print('Owned cleared for %s' % oid)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_grapthsethvt(self, oid, to_print = True):
		"""Sets HVT status for OID"""
		try:
			p = ADObjProps(self.graphid, oid, 'HVT')
			self.db_session.add(p)
			self.db_session.commit()
			
			if to_print is True:
				await self.print('HVT set for %s' % oid)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_graphclearhvt(self, oid, to_print = True):
		"""Clears HVT status for OID"""
		try:
			for res in self.db_session.query(ADObjProps).filter_by(oid = oid).filter(ADObjProps.prop == 'HVT').filter(ADObjProps.graph_id == self.graphid).all():
				self.db_session.delete(res)
				self.db_session.commit()
			
			if to_print is True:
				await self.print('HVT cleared for %s' % oid)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_shares(self, to_print=True):
		"""Lists non-default shares"""
		try:
			default_shares = ['print$','IPC$','ADMIN$', 'SYSVOL', 'NETLOGON']
			for x in string.ascii_uppercase:
				default_shares.append('%s$' % x)
			shares = []
			q = self.db_session.query(NetShare)\
				.filter_by(ad_id = self.current_adid)\
				.filter(NetShare.netname.notin_(default_shares))
			for share in q.all():
				shares.append(share.to_dict())
				if to_print is True:
					await self.print('\\\\%s\\%s' % (str(share.ip), str(share.netname)))
			return shares, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_dns(self, ip_or_hostname:str, to_print=True):
		"""Looks up IP or hostname"""
		try:
			results = [['ip', 'hostname']]
			is_ip = False
			try:
				ipaddress.ip_address(ip_or_hostname)
				is_ip = True
			except:
				is_ip = False
			
			if is_ip is True:
				q = self.db_session.query(DNSLookup)\
					.filter_by(ip = ip_or_hostname)\
					.filter(DNSLookup.ad_id == self.current_adid)
				for res in q.all():
					results.append([ip_or_hostname, res.domainname])
			else:
				q = self.db_session.query(DNSLookup)\
					.filter_by(ad_id = self.current_adid)\
					.filter(func.lower(DNSLookup.domainname) == ip_or_hostname.lower())
				for res in q.all():
					results.append([res.ip, ip_or_hostname])

			if to_print is True:
				if len(results) > 1:
					await self.print_table(results)
				else:
					await self.print('No results found!')

			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_dcsyncaiosmb(self, dumpfile, to_print = True):
		"""Uploads a dcsync file to the DB (aiosmb format) """
		try:
			ctr = 0
			fail = 0
			ctr_plain = 0
			fail_plain = 0
			with open(dumpfile, 'rb') as f:
				for cred, plaintext in Credential.from_aiosmb_stream(f, self.current_adid):
					await asyncio.sleep(0)
					if cred is None:
						continue
					try:
						self.db_session.add(cred)
						self.db_session.commit()
						ctr += 1
					except IntegrityError:
						self.db_session.rollback()
						fail += 1

					if plaintext is not None and len(plaintext) > 0:
						he = HashEntry(plaintext, nt_hash = cred.nt_hash)
						try:
							self.db_session.add(he)
							self.db_session.commit()
							ctr_plain += 1
						except IntegrityError:
							self.db_session.rollback()
							fail_plain += 1

			if to_print is True:
				await self.print('New hashes added: %s' % ctr)
				await self.print('Duplicate hashes: %s' % fail)
				await self.print('New cleartext passwords: %s' % ctr_plain)
				await self.print('Duplicate cleartext pws: %s' % fail_plain)

			return {'new' : ctr, 'duplicates' : fail, 'pwnew' : ctr_plain, 'pwduplicates' :  fail_plain }, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_dcsyncimpacket(self, dumpfile, to_print = True):
		"""Uploads a dcsync file to the DB (impacket format) """
		try:
			ctr = 0
			fail = 0

			with open(dumpfile, 'rb') as f:
				for cred in Credential.from_impacket_stream(f, self.current_adid):
					await asyncio.sleep(0)
					try:
						self.db_session.add(cred)
						self.db_session.commit()
						ctr += 1
					except IntegrityError:
						self.db_session.rollback()
						fail += 1
			
			if to_print is True:
				await self.print('New hashes added: %s' % ctr)
				await self.print('Duplicate hashes: %s' % fail)

			return {'new' : ctr, 'duplicates' : fail }, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_potfile(self, potfile, to_print = True):
		"""Uploads hashcat potfile to the DB"""
		try:
			if to_print is True:
				await self.print('This is a blocking action, expect hangs')
				await asyncio.sleep(0)
			disable_usercheck = False
			disable_passwordcheck = False

			creds = JackDawCredentials(None, db_session = self.db_session)
			with open(potfile, 'rb') as f:
				gen = HashEntry.from_potfile_stream(f)
				creds.add_cracked_passwords_gen(gen, disable_usercheck, disable_passwordcheck)

			if to_print is True:
				await self.print('Potfile upload done!')
			
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_pwuncracked(self, hashtype = 'nt', to_print = False):
		"""Uploads hashcat potfile to the DB"""
		try:
			hashtype = hashtype.upper()
			creds = JackDawCredentials(None, domain_id = self.current_adid, db_session = self.db_session)
			hashes = []
			filepath = create_random_filepath(basename='pwuncracked')
			await self.print('Hashes will be written to %s' % filepath)
			ctr = 0
			with open(filepath, 'w', newline = '') as f:
				for data in creds.get_uncracked_hashes(hashtype, True):
					hashes.append(data)
					if to_print is True:
						await self.print(data)
					f.write(data + '\r\n')
					ctr += 1
			await self.print('Hashes written to file! Amount: %s' % ctr)
			return hashes, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_pwcracked(self, to_print = False):
		"""Lists all cracked user (with extra info)"""
		try:
			creds = JackDawCredentials(None, domain_id = self.current_adid, db_session = self.db_session)
			rows = creds.get_cracked_users()
			if to_print is True:
				await self.print_table(rows)
			
			filepath = create_random_filepath(basename='pwcracked')
			await self.print('Results will be written to %s' % filepath)
			with open(filepath, 'w', newline = '') as f:
				for row in rows:
					f.write('\t'.join(row) + '\r\n')
			
			return rows, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_pwsharing(self, to_print = True):
		"""Lists all users having the same password"""
		try:
			creds = JackDawCredentials(None, domain_id = self.current_adid, db_session = self.db_session)
			pw_sharing_total, pw_sharing_cracked, pw_sharing_notcracked, new_pwshare = creds.get_pwsharing()
			if to_print is True:
				await self.print('Users sharing passwords : %s' % pw_sharing_total)
				await self.print('Cracked shared passwords: %s' % pw_sharing_cracked)
				await self.print('Uncracked shared passwords: %s' % pw_sharing_notcracked)
				await self.print('Users sharing passwords, same pw per line:')
				for x in new_pwshare:
					await self.print('%s' % ','.join(new_pwshare[x]))
				
			return {
				'pw_sharing_total' : pw_sharing_total, 
				'pw_sharing_cracked' : pw_sharing_cracked,
				'pw_sharing_notcracked' : pw_sharing_notcracked,
				'pwsharing_users' : new_pwshare
			}, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_pwstats(self, to_print = True):
		"""Generates all pw stats"""
		try:
			creds = JackDawCredentials(None, domain_id = self.current_adid, db_session = self.db_session)
			res = creds.cracked_stats()
			if to_print is True:
				await self.print(res)
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def search(self, text):
		try:
			if self.graph is None:
				await self.print('No graph loaded!')
				return None, None

			if len(text) < 1:
				return None, Exception('Search term too short!')
			
			results = []

			def create_element(sid, name, otype, adid):
				return {
					'sid' : sid,
					'otype' : otype,
					'adid' : adid,
					'text' : name,
					'owned' : False,
					'highvalue' : False,
				}
			
			adids = []
			for adinfo in self.db_session.query(ADInfo).all():
				adids.append(adinfo.id)

			#search users
			for domain_id in adids:
				term = "%%%s%%" % text
				qry_user_name = self.db_session.query(ADUser.sAMAccountName, ADUser.objectSid).filter_by(ad_id = domain_id).filter(ADUser.sAMAccountName.ilike(term)).limit(5)
				for username, sid in qry_user_name.all():
					results.append(create_element(sid, username, 'user', domain_id))
				
				qry_user_sid = self.db_session.query(ADUser.sAMAccountName, ADUser.objectSid).filter_by(ad_id = domain_id).filter(ADUser.objectSid.ilike(term)).limit(5)
				for username, sid in qry_user_sid.all():
					results.append(create_element(sid, username, 'user', domain_id))


				qry_machine_name = self.db_session.query(Machine.sAMAccountName, Machine.objectSid).filter_by(ad_id = domain_id).filter(Machine.sAMAccountName.ilike(term)).limit(5)
				for username, sid in qry_machine_name.all():
					results.append(create_element(sid, username, 'machine', domain_id))

				qry_machine_sid = self.db_session.query(Machine.sAMAccountName, Machine.objectSid).filter_by(ad_id = domain_id).filter(Machine.objectSid.ilike(term)).limit(5)
				for username, sid in qry_machine_sid.all():
					results.append(create_element(sid, username, 'machine', domain_id))
				

				qry_group_name = self.db_session.query(Group.sAMAccountName, Group.objectSid).filter_by(ad_id = domain_id).filter(Group.sAMAccountName.ilike(term)).limit(5)
				for username, sid in qry_group_name.all():
					results.append(create_element(sid, username, 'group', domain_id))

				qry_group_sid = self.db_session.query(Group.sAMAccountName, Group.objectSid).filter_by(ad_id = domain_id).filter(Group.objectSid.ilike(term)).limit(5)
				for username, sid in qry_group_sid.all():
					results.append(create_element(sid, username, 'group', domain_id))


				qry_ou_name = self.db_session.query(ADOU.name, ADOU.objectGUID).filter_by(ad_id = domain_id).filter(ADOU.name.ilike(term)).limit(5)
				for username, sid in qry_ou_name.all():
					results.append(create_element(sid, username, 'ou', domain_id))

				qry_ou_sid = self.db_session.query(ADOU.name, ADOU.objectGUID).filter_by(ad_id = domain_id).filter(ADOU.objectGUID.ilike(term)).limit(5)
				for username, sid in qry_ou_sid.all():
					results.append(create_element(sid, username, 'ou', domain_id))
				
				for res in results:
					qry_props = self.db_session.query(ADObjProps).filter_by(oid = res['sid']).filter(ADObjProps.graph_id == self.graphid)
					for qr in qry_props.all():
						if qr.prop == 'HVT':
							res['highvalue'] = True
						if qr.prop == 'OWNED':
							res['owned'] = True

			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	