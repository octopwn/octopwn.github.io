
import ntpath
import traceback

from aiowinreg import logger
from aiowinreg.ahive import AIOWinRegHive
from aiowinreg.filestruct.vk import REGTYPE
from aiowinreg.utils.afile import AFile

class RegHelper:
	def __init__(self, filepath):
		self.filepath = filepath
		self.filename = ntpath.basename(filepath)
		self.filehandle = AFile(self.filepath)
		self.hive = AIOWinRegHive(self.filehandle)

	async def do_walk(self, path, depth = 2):
		try:
			results = []
			async for keypath in self.hive.walk(path, depth=depth):
				key = await self.hive.find_key(keypath)
				vals, err = await self.__lsval(keypath, key)
				if err is not None:
					raise err
				results.append([keypath, vals])
			return results, None
		except Exception as e:
			traceback.print_exc()
			print('WALK failed! Reason: %s' % str(e))
			return None, e

	async def __lsval(self, basepath, key):
		try:
			results = []
			for valuename in await self.hive.list_values(key):
				valuename = valuename.decode()
				valuepath = basepath + '\\' + valuename
				res = await self.hive.get_value(valuename, key = key)
				valuetype, value = res
				if valuetype == REGTYPE.REG_UNKNOWN:
					results.append([valuepath, valuetype.name, value.hex(), 0])
					#print('[%s][ROOT\\%s][%s] %s' % (self.filename, valuepath, valuetype, value.hex()))
				if valuetype == REGTYPE.REG_MULTI_SZ:
					for i, val in enumerate(value):
						results.append([valuepath, valuetype.name, val, i])
						#print('[%s][ROOT\\%s][%s][%s] %s' % (self.filename, valuepath, valuetype.name, i, val))
				else:
					t = value
					if isinstance(value, bytes):
						t = t.hex()
					results.append([valuepath, valuetype.name, str(t), 0])
					#print('[%s][ROOT\\%s][%s] %s' % (self.filename, valuepath, valuetype.name, t))
			
			return results, None
		except Exception as e:
			traceback.print_exc()
			print('LSVAL inner failed! Reason: %s' % str(e))
			return False, e