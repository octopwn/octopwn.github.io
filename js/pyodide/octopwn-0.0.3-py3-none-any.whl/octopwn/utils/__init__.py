
from octopwn.utils.pypykatz import PypykatzUtil
from octopwn.utils.dpapi import DPAPIUtil
from octopwn.utils.jackdaw import JackdawUtil
from octopwn.utils.nmap import NmapUtil
from octopwn.utils.notes import NotesUtil
from octopwn.utils.masscan import MasscanUtil
from octopwn.utils.chat import ChatUtil

OCTOPWN_UTIL_TABLE = {
	'PYPYKATZ': PypykatzUtil,
	'DPAPI'   : DPAPIUtil,
	'JACKDAW' : JackdawUtil,
	'NMAP'    : NmapUtil,
	'NOTES'   : NotesUtil,
	'MASSCAN' : MasscanUtil,
	'CHAT'    : ChatUtil,
}
