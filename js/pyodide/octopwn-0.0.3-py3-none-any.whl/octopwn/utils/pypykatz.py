

from datetime import datetime
import traceback
import asyncio
import base64
import os

from octopwn.common.utils import isint
from octopwn.clients.scannerbase import ScannerConsoleBase
from pypykatz.pypykatz import pypykatz
from pypykatz.commons.common import UniversalEncoder
from pypykatz.utils.crypto.winhash import NT, LM, MSDCC, MSDCCv2
from pypykatz.utils.crypto.gppassword import gppassword
from pypykatz.lsadecryptor.packages.msv.decryptor import LogonSession
from pypykatz.registry.offline_parser import OffineRegistry
from aesedb.examples.ntdsparse import NTDSParserConsole
from octopwn.common.parsers.ntds import store_ntds_secrets
from octopwn.common.parsers.registry import store_registry_creds
from octopwn.common.parsers.lsass import store_lsass_creds
from minikerberos.common.creds import KerberosCredential
from minikerberos.protocol.constants import EncryptionType
from octopwn.clients.kerberos.utils import format_kirbi
from octopwn.common.credential import Credential


class PypykatzUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.doc_header = 'LSASS/REGISTRY/NTDS.dit parser and other small utils'
		self.nologon_commands.append('any')
		self.ntds_process_task = None
		self.ntds_parser_task = None
	
	async def do_locallsass(self):
		"""Not yet implemented!"""
		try:
			raise NotImplementedError()
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def process_kerberos_session(self, ksessions):
		try:
			for kerbsess in ksessions:
				for ticket in kerbsess.tickets:
					try:
						ticket_type = ticket.type.name
						if ticket_type.lower() == 'client':
							ticket_type = 'TGS' #I have no ide if this is correct...
						for fname in ticket.kirbi_data:
							kirbiraw = ticket.kirbi_data[fname].dump()
							t = '--------------------\r\n'
							t += 'Username: %s\\%s\r\n' % (ticket.DomainName, ticket.EClientName)
							t += 'Target  : %s\\%s\r\n' % (ticket.TargetDomainName, ticket.ETargetName)
							t += 'Service : %s\\%s\r\n' % (ticket.DomainName, ticket.ServiceName)
							t += 'AltTargetDomainName\r\n: %s' % ticket.AltTargetDomainName
							t += 'Kirbi   : \r\n%s' % (format_kirbi(kirbiraw).replace(' ', ''))
							t += '--------------------\r\n'
							await self.print(t)
							cred = Credential(
								ticket.EClientName[0], 
								base64.b64encode(kirbiraw).decode(), 
								'kirbib64',
								domain=ticket.DomainName,
								source='%s-%s' % (ticket_type, self.client_id), 
								description='%s' % ticket_type
							)
							_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
					except:
						continue
		except Exception as e:
			await self.print_exc(e, extra_msg='Kerberos parsing')

	async def lsass_print(self, results):
		try:
			for result in results:
				await self.print('FILE: ======== %s =======' % result)	
				if isinstance(results[result], str):
					await self.print(results[result])
				else:
					for luid in results[result].logon_sessions:
						sess_creds = results[result].logon_sessions[luid]
						await self.process_kerberos_session(sess_creds.kerberos_creds)
						await self.print(str(sess_creds))
								
					if len(results[result].orphaned_creds) > 0:
						await self.print('== Orphaned credentials ==')
						for cred in results[result].orphaned_creds:
							await self.print(str(cred))
						
					if len(results[result].errors) > 0:
						await self.print('== Errors ==')
						for pkg, err in results[result].errors:
							err_str = str(err) +'\r\n' + '\r\n'.join(traceback.format_tb(err.__traceback__))
							err_str = base64.b64encode(err_str.encode()).decode()
							await self.print('%s %s' % (pkg+'_exception_please_report',err_str))

			await self.print('==== GREP ===')
			await self.print(':'.join(LogonSession.grep_header))
			for result in results:
				for luid in results[result].logon_sessions:
					for row in results[result].logon_sessions[luid].to_grep_rows():
						await self.print(':'.join(row))
				for cred in results[result].orphaned_creds:
					t = cred.to_dict()
					if t['credtype'] != 'dpapi':
						if t['password'] is not None:
							x =  [str(t['credtype']), str(t['domainname']), str(t['username']), '', '', '', '', '', str(t['password'])]
							await self.print(':'.join(x))
					else:
						t = cred.to_dict()
						x = [str(t['credtype']), '', '', '', '', '', str(t['masterkey']), str(t['sha1_masterkey']), str(t['key_guid']), '']
						await self.print(':'.join(x))
				
				for pkg, err in results[result].errors:
					err_str = str(err) +'\r\n' + '\r\n'.join(traceback.format_tb(err.__traceback__))
					err_str = base64.b64encode(err_str.encode()).decode()
					x =  [pkg+'_exception_please_report', '', '', '', '', '', '', '', '', err_str]
					await self.print(':'.join(x) + '\r\n')
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_lsass(self, minidumpfile):
		"""Parses an LSASS dump file"""
		try:
			results = {}
			mimi = pypykatz.parse_minidump_file(minidumpfile, packages=['all'])
			results[minidumpfile] = mimi
			await self.lsass_print(results)
			await store_lsass_creds(self, results)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_registry(self, system, sam=None, security=None, software=None):
		"""Parses the resitry hive files, print secrets"""
		try:
			po = OffineRegistry.from_files(system, sam, security, software)
			await store_registry_creds(self, po, to_print=True, h_token=None)
			#await self.print(str(po))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def __ntdsparse(self, parser, outfile):
		fileh = None
		try:
			lasttime = datetime.utcnow()
			total_rows = await parser.get_total_rows()
			result_cnt = 0
			if outfile is not None and len(outfile) > 0:
				fileh = open(outfile, 'a+', newline = '')

			async for secret, err in parser.get_secrets():
				await asyncio.sleep(0)
				if err is not None:
					raise err
				
				if secret is not None:
					await store_ntds_secrets(self, secret, to_print = False, fileh = fileh)
				
				result_cnt += 1
				now = datetime.utcnow()
				dt = (now - lasttime).total_seconds()
				if dt < 2:
					continue
				lasttime = now
				if total_rows > 0:
					await self.print('Progress: %s / %s (%s%%)' % (total_rows, result_cnt, round((result_cnt/total_rows * 100), 2 )))
				else:
					await self.print('Progress: %s secrets found' % (result_cnt))

			
			await self.print("NTDS parsing Done!")
			return True, None
		except asyncio.CancelledError:
			return

		except Exception as e:
			return None, e
		finally:
			if fileh is not None:
				fileh.close()

	async def do_ntds(self, systemhive, ntdsfile, outfile = 'ntds_secrets_%s.txt' % os.urandom(4).hex()):
		"""Parses NTDS.DIT file"""
		try:		
			parser = NTDSParserConsole(systemhive, ntdsfile, ignore_errors = True, with_history = True)
			_, err = await self.__ntdsparse(parser, outfile)
			if err is not None:
				raise err
			await self.print('NTDS parsing started! Output will be written to: %s' % outfile)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_gppassword(self, pw_enc_b64):
		"""Decrypts GPPassword"""
		try:
			await self.print(gppassword(pw_enc_b64))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_nt(self, password, to_print=True):
		"""Calculates NT hash of password"""
		try:
			res = NT(password).hex()
			if to_print is True:
				await self.print(res)
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_lm(self, password, to_print=True):
		"""Calculates LM hash of password"""
		try:
			res = LM(password).hex()
			if to_print is True:
				await self.print(res)
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_msdcc(self, username, password, to_print=True):
		"""Calculates version 1 of MS Domain Cached Credentials hash from username and password"""
		try:
			res = MSDCC(username, password).hex()
			if to_print is True:
				await self.print(res)
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_msdcc2(self, username, password, iteration = 10240, to_print=True):
		"""Calculates version 2 of MS Domain Cached Credentials hash from username and password"""
		try:
			if iteration is None:
				iteration = 10240
			
			res = MSDCCv2(username, password, int(iteration)).hex()
			if to_print is True:
				await self.print(res)
			return res, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_kerberos(self, username, password, domain = None, to_print=True):
		"""Calculates kerberos keys from username and password and domain"""
		try:
			kc = KerberosCredential()
			kc.username = username
			kc.domain = domain
			kc.password = password

			if domain is not None:
				aes_128 = kc.get_key_for_enctype(EncryptionType.AES128_CTS_HMAC_SHA1_96)
				aes_256 = kc.get_key_for_enctype(EncryptionType.AES256_CTS_HMAC_SHA1_96)
			rc4_md5 = kc.get_key_for_enctype(EncryptionType.ARCFOUR_HMAC_MD5)
			tdes_sha1 = kc.get_key_for_enctype(EncryptionType.DES3_CBC_SHA1)

			if to_print is True:
				if domain is not None:
					await self.print('KERBEROS AES128: %s' % aes_128.hex())
					await self.print('KERBEROS AES256: %s' % aes_256.hex())
				await self.print('KERBEROS RC4   : %s' % rc4_md5.hex())
				await self.print('KERBEROS 3DES  : %s' % tdes_sha1.hex())

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_hashes(self, username, password, domain = None):
		"""Calculates common hashes from username,password and optionally domain"""
		try:
			nthash, err = await self.do_nt(password, False)
			lmhash, err = await self.do_lm(password, False)
			msdcc, err  = await self.do_msdcc(username, password, False)
			msdcc2, err = await self.do_msdcc2(username, password, 10240, False)


			await self.print('NT   : %s' % nthash)
			await self.print('LM   : %s' % lmhash)
			await self.print('DCC  : %s' % msdcc)
			await self.print('DCC2 : %s' % msdcc2)
			await self.do_kerberos(username, password, domain)


		except Exception as e:
			await self.print_exc(e)
			return None, e
