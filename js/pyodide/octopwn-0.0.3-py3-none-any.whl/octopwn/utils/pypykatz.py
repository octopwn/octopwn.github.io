

from datetime import datetime
import traceback
import asyncio
import base64
import os

from octopwn.common.utils import isint
from octopwn.clients.scannerbase import ScannerConsoleBase
from pypykatz.pypykatz import pypykatz
from pypykatz.commons.common import UniversalEncoder
from pypykatz.utils.crypto.winhash import NT, LM, MSDCC, MSDCCv2
from pypykatz.utils.crypto.gppassword import gppassword
from pypykatz.lsadecryptor.packages.msv.decryptor import LogonSession
from pypykatz.registry.offline_parser import OffineRegistry
from aesedb.examples.ntdsparse import NTDSParserConsole
from octopwn.common.parsers.ntds import store_ntds_secrets
from octopwn.common.parsers.registry import store_registry_creds
from octopwn.common.parsers.lsass import store_lsass_creds

class PypykatzUtil(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.ntds_process_task = None
		self.ntds_parser_task = None
	
	async def do_locallsass(self):
		"""Not yet implemented!"""
		try:
			raise NotImplementedError()
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def lsass_print(self, results):
		try:
			for result in results:
				await self.print('FILE: ======== %s =======' % result)	
				if isinstance(results[result], str):
					await self.print(results[result])
				else:
					for luid in results[result].logon_sessions:
						await self.print(str(results[result].logon_sessions[luid]))
								
					if len(results[result].orphaned_creds) > 0:
						await self.print('== Orphaned credentials ==')
						for cred in results[result].orphaned_creds:
							await self.print(str(cred))
						
					if len(results[result].errors) > 0:
						await self.print('== Errors ==')
						for pkg, err in results[result].errors:
							err_str = str(err) +'\r\n' + '\r\n'.join(traceback.format_tb(err.__traceback__))
							err_str = base64.b64encode(err_str.encode()).decode()
							await self.print('%s %s' % (pkg+'_exception_please_report',err_str))

			await self.print('==== GREP ===')
			await self.print(':'.join(LogonSession.grep_header))
			for result in results:
				for luid in results[result].logon_sessions:
					for row in results[result].logon_sessions[luid].to_grep_rows():
						await self.print(':'.join(row))
				for cred in results[result].orphaned_creds:
					t = cred.to_dict()
					if t['credtype'] != 'dpapi':
						if t['password'] is not None:
							x =  [str(t['credtype']), str(t['domainname']), str(t['username']), '', '', '', '', '', str(t['password'])]
							await self.print(':'.join(x))
					else:
						t = cred.to_dict()
						x = [str(t['credtype']), '', '', '', '', '', str(t['masterkey']), str(t['sha1_masterkey']), str(t['key_guid']), '']
						await self.print(':'.join(x))
				
				for pkg, err in results[result].errors:
					err_str = str(err) +'\r\n' + '\r\n'.join(traceback.format_tb(err.__traceback__))
					err_str = base64.b64encode(err_str.encode()).decode()
					x =  [pkg+'_exception_please_report', '', '', '', '', '', '', '', '', err_str]
					await self.print(':'.join(x) + '\r\n')
		
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_lsass(self, minidumpfile):
		"""Parses an LSASS dump file"""
		try:
			results = {}
			mimi = pypykatz.parse_minidump_file(minidumpfile, packages=['all'])
			results[minidumpfile] = mimi
			await self.lsass_print(results)
			await store_lsass_creds(self, results)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_registry(self, system, sam=None, security=None, software=None):
		"""Parses the resitry hive files, print secrets"""
		try:
			po = OffineRegistry.from_files(system, sam, security, software)
			await store_registry_creds(self, po, to_print=True, h_token=None)
			#await self.print(str(po))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def __ntdsparse(self, parser, outfile):
		fileh = None
		try:
			lasttime = datetime.utcnow()
			total_rows = await parser.get_total_rows()
			result_cnt = 0
			if outfile is not None and len(outfile) > 0:
				fileh = open(outfile, 'a+', newline = '')

			async for secret, err in parser.get_secrets():
				await asyncio.sleep(0)
				if err is not None:
					raise err
				
				if secret is not None:
					await store_ntds_secrets(self, secret, to_print = False, fileh = fileh)
				
				result_cnt += 1
				now = datetime.utcnow()
				dt = (now - lasttime).total_seconds()
				if dt < 2:
					continue
				lasttime = now
				if total_rows > 0:
					await self.print('Progress: %s / %s (%s%%)' % (total_rows, result_cnt, round((result_cnt/total_rows * 100), 2 )))
				else:
					await self.print('Progress: %s secrets found' % (result_cnt))

			
			await self.print("NTDS parsing Done!")
			return True, None
		except asyncio.CancelledError:
			return

		except Exception as e:
			return None, e
		finally:
			if fileh is not None:
				fileh.close()

	async def do_ntds(self, systemhive, ntdsfile, outfile = 'ntds_secrets_%s.txt' % os.urandom(4).hex()):
		"""Parses NTDS.DIT file"""
		try:		
			parser = NTDSParserConsole(systemhive, ntdsfile, ignore_errors = True, with_history = True)
			_, err = await self.__ntdsparse(parser, outfile)
			if err is not None:
				raise err
			await self.print('NTDS parsing started! Output will be written to: %s' % outfile)
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_gppassword(self, pw_enc_b64):
		"""Decrypts GPPassword"""
		try:
			await self.print(gppassword(pw_enc_b64))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_nt(self, password):
		"""Calculates NT hash of password"""
		try:
			await self.print(NT(password).hex())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_lm(self, password):
		"""Calculates LM hash of password"""
		try:
			await self.print(LM(password).hex())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_msdcc(self, username, password):
		"""Calculates version 1 of MS Domain Cached Credentials hash from username and password"""
		try:
			await self.print(MSDCC(username, password).hex())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_msdcc2(self, username, password, iteration = 10240):
		"""Calculates version 2 of MS Domain Cached Credentials hash from username and password"""
		try:
			if iteration is None:
				iteration = 10240
			
			await self.print(MSDCCv2(username, password, int(iteration)).hex())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	