import platform
import asyncio
import traceback
import os
import copy

from octopwn.servers.relay.common.authentication.ntlm.native import NTLMRelayHandler
from octopwn.servers.relay.smbrelay.protocol.netbios import NetBIOSTransport
from octopwn.servers.relay.smbrelay.protocol.tcpconnection import TCPClient
from octopwn.servers.relay.smbrelay.protocol.serverconnection import SMBServerConnection, SMBConnectionSettings
from octopwn.servers.relay.common.authentication.spnego.relay import SPNEGORelay

from octopwn.clients.scannerbase import ScannerConsoleBase

class SMBServer(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'ip': (str, '0.0.0.0'),
			'port': (int, 445),
			'targets' : (list, []),
			'targetfiles' : (list, []),
			'proxy': (int, None),
			'resultsfile': (str, 'smb_server_%s.tsv' % os.urandom(4).hex()),
		}

		self.serverproto = None
		self.servertransport = None
		self.in_queue = None
		self.server_task = None

	async def start(self):
		return True, None
	
	async def handle_client(self, reader:asyncio.StreamReader, writer: asyncio.StreamWriter):
		server = None
		nbtransport = None
		try:
			raddr, rport = writer.get_extra_info('peername')
			await self.print('[TCP] Client connected from %s:%s' % (raddr, rport))
			
			client = TCPClient(raddr, rport, reader, writer)
			#out_task = asyncio.create_task(self.handle_outgoing(client))
			#in_task = asyncio.create_task(self.handle_incoming(client))

			ntlm_ctx = NTLMRelayHandler()
			gssapi = SPNEGORelay()
			gssapi.add_auth_context('NTLMSSP - Microsoft NTLM Security Support Provider', ntlm_ctx)
			gssapi.setup(self.print)

			connsettings = SMBConnectionSettings(raddr, rport, gssapi, self.print)
			nbtransport = NetBIOSTransport(client)
			server = SMBServerConnection(connsettings, nbtransport)

			
			await nbtransport.run()
			await server.run()					
			await self.print('SMB server terminated, closing client! %s:%s' % (raddr, rport))
		except Exception as e:
			await self.print_exc(e, extra_msg='[TCP] handle_client')
		finally:
			await asyncio.sleep(100)
			if server is not None:
				await server.disconnect()
			if nbtransport is not None:
				await nbtransport.stop()
			writer.close()
			#if out_task is not None:
			#	out_task.cancel()
			#if in_task is not None:
			#	in_task.cancel()


	async def socketsetup(self):
		try:
			if platform.system() == 'Emscripten':
				from wsnet.pyodide.tcpserver import WSNetworkTCPServer
				temp = WSNetworkTCPServer(
					self.handle_client,
					self.params['ip'][1],
					self.params['port'][1],
					bindtype = 1,
					reuse_ws = False
				)
				server, err = await temp.run()
				if err is not None:
					raise err

			if self.params['proxy'][1] is None:
				server = await asyncio.start_server(self.handle_client, self.params['ip'][1], self.params['port'][1])

			else:
				raise Exception('Proxy not yet supported!')
			return server, None
		except Exception as e:
			return None, e

	async def __serve(self, server):
		try:
			await self.print('SMB Server in listening state')
			await server.serve_forever()
			return True, None
		except Exception as e:
			await self.print('SMB server terminated')
			await self.print_exc(e)
			return False, None

	async def do_serve(self):
		try:
			self.in_queue = asyncio.Queue()
			server, err = await self.socketsetup()
			if err is not None:
				raise err
			self.server_task = asyncio.create_task(self.__serve(server))
			await self.print('Server is running!')

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_stop(self):
		try:
			if self.server_task is not None:
				self.server_task.cancel()
			await self.print('Server stopped!')
		except Exception as e:
			await self.print_exc(e)
			return None, e
	