import io

from octopwn.servers.relay.common.authentication.ntlm.structures.fields import Fields
from octopwn.servers.relay.common.authentication.ntlm.structures.negotiate_flags import NegotiateFlags
from octopwn.servers.relay.common.authentication.ntlm.structures.version import Version
from octopwn.servers.relay.common.authentication.ntlm.structures.challenge_response import *
from octopwn.servers.relay.common.authentication.ntlm.structures.avpair import MsvAvFlags, AVPAIRType

# https://docs.microsoft.com/en-us/openspecs/windows_protocols/ms-nlmp/033d32cc-88f9-4483-9bf2-b273055038ce
class NTLMAuthenticate:
	def __init__(self, _use_NTLMv2 = True):
		self.Signature = b'NTLMSSP\x00'
		self.MessageType = 3
		self.LmChallengeResponseFields = None
		self.NtChallengeResponseFields = None
		self.DomainNameFields = None
		self.UserNameFields = None
		self.WorkstationFields = None
		self.EncryptedRandomSessionKeyFields = None
		self.NegotiateFlags = None
		self.Version = None
		self.MIC = None
		self.Payload = None

		# high level
		self.LMChallenge = None
		self.NTChallenge = None
		self.DomainName = None
		self.UserName = None
		self.Workstation = None
		self.EncryptedRandomSession = None

		# this is a global variable that needs to be indicated
		self._use_NTLMv2 = _use_NTLMv2
		
	@staticmethod
	def construct(flags, domainname= None, workstationname= None, username= None, encrypted_session= None, lm_response= None, nt_response= None, version = None, mic = b'\x00'*16):
		auth = NTLMAuthenticate()
		auth.Payload = b''
		
		payload_pos = 8+4+8+8+8+8+8+8+4
		if flags & NegotiateFlags.NEGOTIATE_VERSION:
			if not version:
				raise Exception('NEGOTIATE_VERSION set but no Version supplied!')
				
			auth.Version = version
			payload_pos += 8
			
		if mic is not None:
			auth.MIC = mic
			payload_pos += 16
			
		if lm_response:
			data = lm_response.to_bytes()
			auth.Payload += data
			auth.LmChallengeResponseFields  = Fields(len(data), payload_pos)
			payload_pos += len(data)
			auth.LMChallenge = lm_response
		else:
			auth.LmChallengeResponseFields  = Fields(0,0)
			
		if nt_response:
			data = nt_response.to_bytes()
			auth.Payload += data
			auth.NtChallengeResponseFields  = Fields(len(data), payload_pos)
			payload_pos += len(data)
			auth.NTChallenge = nt_response
		else:
			auth.NtChallengeResponseFields  = Fields(0,payload_pos)
		
		
		if domainname:
			data =  domainname.encode('utf-16le')
			auth.Payload += data
			auth.DomainNameFields  = Fields(len(data), payload_pos)
			payload_pos += len(data)
			auth.DomainName = domainname
		else:
			auth.DomainNameFields  = Fields(0,payload_pos)
		
		if username:
			data =  username.encode('utf-16le')
			auth.Payload += data
			auth.UserNameFields  = Fields(len(data), payload_pos)
			payload_pos += len(data)
			auth.UserName = username
		else:
			auth.UserNameFields  = Fields(0,payload_pos)
		
		if workstationname:
			data =  workstationname.encode('utf-16le')
			auth.Payload += data
			auth.WorkstationFields  = Fields(len(data), payload_pos)
			payload_pos += len(data)
			auth.Workstation = workstationname
		else:
			auth.WorkstationFields  = Fields(0,payload_pos)
			
		if encrypted_session:
			data =  encrypted_session
			auth.Payload += data
			auth.EncryptedRandomSessionKeyFields  = Fields(len(data), payload_pos)
			payload_pos += len(data)
			auth.EncryptedRandomSession = encrypted_session
		else:
			auth.EncryptedRandomSessionKeyFields  = Fields(0,payload_pos)
				
		auth.NegotiateFlags = flags
		return auth
		
	def to_bytes(self):
		t = b''
		t += self.Signature
		t += self.MessageType.to_bytes(4, byteorder = 'little', signed = False)
		
		t += self.LmChallengeResponseFields.to_bytes()
		t += self.NtChallengeResponseFields.to_bytes()
		t += self.DomainNameFields.to_bytes()
		t += self.UserNameFields.to_bytes()
		t += self.WorkstationFields.to_bytes()
		t += self.EncryptedRandomSessionKeyFields.to_bytes()
		t += self.NegotiateFlags.to_bytes(4, byteorder = 'little', signed = False)
		if self.Version is not None:
			if isinstance(self.Version, bytes):
				#parsing might have failed!
				t+= self.Version
			else:
				t += self.Version.to_bytes()
		
		if isinstance(self.NTChallenge, NTLMv2Response) and AVPAIRType.MsvAvFlags in self.NTChallenge.ChallengeFromClinet.Details:
			# checking also if mic is present, because we might have dropped it somewhere :)
			if self.MIC is not None and MsvAvFlags.MIC_PRESENT in self.NTChallenge.ChallengeFromClinet.Details[AVPAIRType.MsvAvFlags]:
				t += self.MIC

		#if self.MIC is not None:
		#	t += self.MIC
		
		t += self.Payload
		return t
	
	def to_bytes_full(self):
		t = b''
		payload = b''
		payload_pos = 8+4+8+8+8+8+8+8+4
		if self.Version is not None:
			payload_pos += 8
			
		if self.MIC is not None:
			payload_pos += 16

		if self.LMChallenge is not None:
			data = self.LMChallenge.to_bytes()
			self.LmChallengeResponseFields = Fields(len(data), payload_pos)
			payload += data
			payload_pos += len(data)
		else:
			self.LmChallengeResponseFields = Fields(0,0)
			
		if self.NTChallenge is not None:
			data = self.NTChallenge.to_bytes()
			self.NtChallengeResponseFields = Fields(len(data), payload_pos)
			payload += data
			payload_pos += len(data)
		else:
			self.NtChallengeResponseFields = Fields(0,0)
		
		if self.DomainName is not None or len(self.DomainName) > 0:
			data = self.DomainName.encode('utf-16le')
			self.DomainNameFields = Fields(len(data), payload_pos)
			payload += data
			payload_pos += len(data)
		else:
			self.DomainNameFields = Fields(0,0)
		
		if self.UserName is not None or len(self.UserName) > 0:
			data = self.UserName.encode('utf-16le')
			self.UserNameFields = Fields(len(data), payload_pos)
			payload += data
			payload_pos += len(data)
		else:
			self.UserNameFields = Fields(0,0)
		
		if self.Workstation is not None or len(self.Workstation) > 0:
			data =  self.Workstation.encode('utf-16le')
			self.WorkstationFields = Fields(len(data), payload_pos)
			payload += data
			payload_pos += len(data)
		else:
			self.WorkstationFields = Fields(0,0)
			
		if self.EncryptedRandomSession is not None:
			data = self.EncryptedRandomSession
			self.EncryptedRandomSessionKeyFields = Fields(len(data), payload_pos)
			payload += data
			payload_pos += len(data)
		else:
			self.EncryptedRandomSessionKeyFields = Fields(0,0)
		
		t = self.Signature
		t += self.MessageType.to_bytes(4, byteorder = 'little', signed = False)
		t += self.LmChallengeResponseFields.to_bytes()
		t += self.NtChallengeResponseFields.to_bytes()
		t += self.DomainNameFields.to_bytes()
		t += self.UserNameFields.to_bytes()
		t += self.WorkstationFields.to_bytes()
		t += self.EncryptedRandomSessionKeyFields.to_bytes()
		t += self.NegotiateFlags.to_bytes(4, byteorder = 'little', signed = False)
		if self.Version is not None:
			t += self.Version.to_bytes()
		if self.MIC is not None:
			t += self.MIC
		
		t += payload
		return t
		

	@staticmethod
	def from_bytes(bbuff,_use_NTLMv2 = True):
		return NTLMAuthenticate.from_buffer(io.BytesIO(bbuff), _use_NTLMv2 = _use_NTLMv2)

	@staticmethod
	def from_buffer(buff:bytes, _use_NTLMv2 = True):
		auth = NTLMAuthenticate(_use_NTLMv2)
		auth.Signature    = buff.read(8)
		auth.MessageType  = int.from_bytes(buff.read(4), byteorder = 'little', signed = False)
		auth.LmChallengeResponseFields = Fields.from_buffer(buff)
		auth.NtChallengeResponseFields = Fields.from_buffer(buff)
		auth.DomainNameFields = Fields.from_buffer(buff)
		auth.UserNameFields = Fields.from_buffer(buff)
		auth.WorkstationFields = Fields.from_buffer(buff)
		auth.EncryptedRandomSessionKeyFields = Fields.from_buffer(buff)
		auth.NegotiateFlags = NegotiateFlags(int.from_bytes(buff.read(4), byteorder = 'little', signed = False))
		#try:
		#	versiondata = buff.read(8)
		#	if auth.NegotiateFlags & NegotiateFlags.NEGOTIATE_VERSION: 
		#		auth.Version = Version.from_bytes(versiondata)
		#except Exception as e:
		#	raise e

		try:
			auth.Version = buff.read(8)
			if auth.NegotiateFlags & NegotiateFlags.NEGOTIATE_VERSION: 
				auth.Version = Version.from_bytes(auth.Version)
		except Exception as e:
			raise e

		currPos = buff.tell()
		

		#if auth._use_NTLMv2 and auth.NtChallengeResponseFields.length > 24:
		#	buff.seek(auth.LmChallengeResponseFields.offset, io.SEEK_SET)
		#	auth.LMChallenge = LMv2Response.from_buffer(buff)
		#	
		#
		#	buff.seek(auth.NtChallengeResponseFields.offset, io.SEEK_SET)
		#	auth.NTChallenge = NTLMv2Response.from_buffer(buff)
		#	if AVPAIRType.MsvAvFlags in auth.NTChallenge.ChallengeFromClinet.Details:
		#		if MsvAvFlags.MIC_PRESENT in auth.NTChallenge.ChallengeFromClinet.Details[AVPAIRType.MsvAvFlags]:
		#			buff.seek(mic_pos, 0)
		#			auth.MIC = buff.read(16)
		#
		#else:
		#	buff.seek(auth.LmChallengeResponseFields.offset, io.SEEK_SET)
		#	auth.LMChallenge = LMResponse.from_buffer(buff)
		#		
		#	buff.seek(auth.NtChallengeResponseFields.offset, io.SEEK_SET)
		#	auth.NTChallenge = NTLMv1Response.from_buffer(buff)

		if auth._use_NTLMv2 and auth.LmChallengeResponseFields.length > 24:
			buff.seek(auth.LmChallengeResponseFields.offset, io.SEEK_SET)
			auth.LMChallenge = LMv2Response.from_buffer(buff)
		else:
			buff.seek(auth.LmChallengeResponseFields.offset, io.SEEK_SET)
			auth.LMChallenge = LMResponse.from_buffer(buff)

		if auth._use_NTLMv2 and auth.NtChallengeResponseFields.length > 24:
			buff.seek(auth.NtChallengeResponseFields.offset, io.SEEK_SET)
			auth.NTChallenge = NTLMv2Response.from_buffer(buff)
			if AVPAIRType.MsvAvFlags in auth.NTChallenge.ChallengeFromClinet.Details:
				if MsvAvFlags.MIC_PRESENT in auth.NTChallenge.ChallengeFromClinet.Details[AVPAIRType.MsvAvFlags]:
					buff.seek(currPos, 0)
					auth.MIC = buff.read(16)
					currPos += 16
		else:
			buff.seek(auth.NtChallengeResponseFields.offset, io.SEEK_SET)
			auth.NTChallenge = NTLMv1Response.from_buffer(buff)

		buff.seek(auth.DomainNameFields.offset,io.SEEK_SET)
		auth.DomainName = buff.read(auth.DomainNameFields.length).decode('utf-16le')
		
		buff.seek(auth.UserNameFields.offset,io.SEEK_SET)
		auth.UserName = buff.read(auth.UserNameFields.length).decode('utf-16le')

		buff.seek(auth.WorkstationFields.offset,io.SEEK_SET)
		auth.Workstation = buff.read(auth.WorkstationFields.length).decode('utf-16le')

		buff.seek(auth.EncryptedRandomSessionKeyFields.offset,io.SEEK_SET)
		auth.EncryptedRandomSession = buff.read(auth.EncryptedRandomSessionKeyFields.length)
		
		buff.seek(currPos, io.SEEK_SET)
		auth.Payload = buff.read()

		return auth

	def __repr__(self):
		t  = '== NTLMAuthenticate ==\r\n'
		t += 'Signature     : %s\r\n' % repr(self.Signature)
		t += 'MessageType   : %s\r\n' % repr(self.MessageType)
		t += 'NegotiateFlags: %s\r\n' % repr(self.NegotiateFlags)
		t += 'Version       : %s\r\n' % repr(self.Version)
		t += 'MIC           : %s\r\n' % repr(self.MIC.hex() if self.MIC else None)
		t += 'LMChallenge   : %s\r\n' % repr(self.LMChallenge)
		t += 'NTChallenge   : %s\r\n' % repr(self.NTChallenge)
		t += 'DomainName    : %s\r\n' % repr(self.DomainName)
		t += 'UserName      : %s\r\n' % repr(self.UserName)
		t += 'Workstation   : %s\r\n' % repr(self.Workstation)
		t += 'EncryptedRandomSession: %s\r\n' % repr(self.EncryptedRandomSession.hex())
		return t
