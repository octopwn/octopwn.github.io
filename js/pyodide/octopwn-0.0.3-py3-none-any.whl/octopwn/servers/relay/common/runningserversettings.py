import asyncio
from octopwn.servers.relay.common.serversettings import ServerSettings
from octopwn.servers.relay.common.authentication.spnego.relay import SPNEGORelay

class RunningServerSettings:
	def __init__(self, server_settings: ServerSettings, gssapi: SPNEGORelay, log_q: asyncio.Queue = None, client_ip:str = None, client_port:int = None):
		self.server_settings = server_settings
		self.gssapi = gssapi
		self.log_q = log_q
		self.client_ip   = client_ip
		self.client_port = client_port