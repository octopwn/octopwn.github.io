from asyncio.base_events import Server
import json
from os import stat
import toml
import copy
from octopwn.servers.relay.common.constants import RELAYServerType, RELAYClientType
from octopwn.clients.base import ClientConsoleBase

from asysocks.common.clienturl import SocksClientURL

class ServerSettings:
	def __init__(self, server_type:RELAYServerType, serverobj, connsettingsobj, listen_ip, listen_port):
		self.server_type = server_type
		self.server_socket:RELAYServerType = server_type
		self.ip:str = listen_ip
		self.port:int = listen_port
		self.serverobj = serverobj
		self.connsettingsobj = connsettingsobj
	
	def to_dict(self):
		t = {}
		for k in self.__dict__:
			val = self.__dict__[k]
			if isinstance(self.__dict__[k], RELAYServerType):
				val = val.value.upper()
			t[k] = val
		return t
	
	#@staticmethod
	#def from_dict(d):
	#	clinet_type = RELAYServerType(d['server_type'].upper())
	#	t = copy.deepcopy(d)
	#	del t['server_type']
	#	res = srvtype2obj[clinet_type](**t)
	#	return res
	
	@staticmethod
	def from_json(x):
		return ServerSettings.from_dict(json.loads(x))
	
	@staticmethod
	def from_arg(x):
		cd = {
			'listen_ip' : '0.0.0.0'
		}
		ctype, *rest = x.split(',',1)
		cd['server_type'] = ctype.upper()
		for entry in x.split(',')[1:]:
			key, val = entry.split(':',1)
			key = key.lower()
			if key == 'port':
				cd['listen_port'] = int(val)
			if key == 'ip':
				cd['listen_ip'] = val
			else:
				cd[key] = val
		return ServerSettings.from_dict(cd)
	
	@staticmethod
	def from_toml(x):
		return ServerSettings.from_dict(toml.loads(x))
	
	def to_toml(self):
		return toml.dumps(self.to_dict())
	
	def to_json(self):
		return json.dumps(self.to_dict())

class NTLMClientSettings:
	def __init__(self, signdisable:bool = False, dropmic:bool = False, dropmic2:bool = False):
		self.signdisable:bool = signdisable
		self.dropmic:bool = dropmic
		self.dropmic2:bool = dropmic2
		self.modify_negotiate_cb = None
		self.modify_challenge_cb = None
		self.modify_authenticate_cb = None
	
	def to_dict(self):
		t = {}
		for k in self.__dict__:
			val = self.__dict__[k]
			t[k] = val
		return t
	
	@staticmethod
	def from_keyword(keyword):
		# this is specifically for parsing command-line format
		d = {
			keyword : True
		}
		return NTLMClientSettings(**d)

	@staticmethod
	def from_dict(d):
		return NTLMClientSettings(**d)
	
	@staticmethod
	def from_json(x):
		return NTLMClientSettings.from_dict(json.loads(x))
	
	@staticmethod
	def from_toml(x):
		return NTLMClientSettings.from_dict(toml.loads(x))
	
	def to_toml(self):
		return toml.dumps(self.to_dict())
	
	def to_json(self):
		return json.dumps(self.to_dict())

class ClientSettings:
	def __init__(self, client_type: RELAYClientType, clientobj: ClientConsoleBase, ip, port = None, proxies = None, timeout = 10, commands = '', ntlm = None):
		self.client_type = client_type
		self.clientobj = clientobj
		self.ip:str = ip
		self.port:int = port
		self.timeout:int = timeout
		self.proxies = proxies
		self.ntlm = ntlm
		self.commands:str = commands

	def get_ntlm(self) -> NTLMClientSettings:
		if self.ntlm is not None:
			if isinstance(self.ntlm, NTLMClientSettings):
				return copy.deepcopy(self.ntlm)
			if isinstance(self.ntlm, dict):
				return NTLMClientSettings.from_dict(self.ntlm)
			if isinstance(self.ntlm, str):
				return NTLMClientSettings.from_keyword(self.ntlm)
		return NTLMClientSettings()
	
	def get_proxy(self, endpoint_ip = None, endpoint_port = None) -> SocksClientURL:
		if self.proxies is not None:
			if isinstance(self.proxies, list):
				return SocksClientURL.from_urls(self.proxies, endpoint_ip, endpoint_port)
			else:
				return SocksClientURL.from_url(self.proxies)
		return None
	
	def to_dict(self):
		t = {}
		for k in self.__dict__:
			val = self.__dict__[k]
			if isinstance(self.__dict__[k], RELAYClientType):
				val = val.value.upper()
			if isinstance(self.__dict__[k], (NTLMClientSettings)):
				val = val.to_dict()
			t[k] = val
		return t
	
	#@staticmethod
	#def from_dict(d):
	#	clinet_type = RELAYClientType(d['client_type'].upper())
	#	t = copy.deepcopy(d)
	#	del t['client_type']
	#	res = clitype2obj[clinet_type](**t)
	#	return res

	@staticmethod
	def from_json(x):
		return ClientSettings.from_dict(json.loads(x))
	
	@staticmethod
	def from_toml(x):
		return ClientSettings.from_dict(toml.loads(x))
	
	@staticmethod
	def from_arg(x):
		cd = {
			'commands' : ''
		}
		ctype, rest = x.split(',',1)
		cd['client_type'] = ctype.upper()
		for entry in x.split(',')[1:]:
			key, val = entry.split(':',1)
			key = key.lower()
			if key == 'port':
				cd[key] = int(val)
			elif key == 'c':
				cd['commands'] += ' "%s"' % val
			else:
				cd[key] = val
		return ClientSettings.from_dict(cd)

	def __str__(self):
		t = '=== %s ===\r\n' % self.client_type.value
		for k in self.__dict__:
			val = self.__dict__[k]
			if isinstance(self.__dict__[k], RELAYClientType):
				val = val.value
			if isinstance(self.__dict__[k], NTLMClientSettings):
				val = str(val)
			t += '%s: %s\r\n' % (k, val)
		return t

	def __repr__(self):
		return str(self)

class ConfigFile:
	def __init__(self):
		self.client_section_name = 'client'
		self.client_settings = []
		self.server_section_name = 'server'
		self.server_settings = []
	
	def to_dict(self):
		clients = []
		for cs in self.client_settings:
			clients.append(cs.to_dict())
		
		servers = []
		for cs in self.server_settings:
			servers.append(cs.to_dict())
		
		return {
			self.server_section_name : servers,
			self.client_section_name : clients
		}
	
	@staticmethod
	def from_dict(d):
		res = ConfigFile()
		if res.client_section_name not in d:
			raise Exception('No clients defined in config file!')
		settings_list = d[res.client_section_name]
		for setting in settings_list:
			res.client_settings.append(ClientSettings.from_dict(setting))
		if res.server_section_name not in d:
			raise Exception('No servers defined in config file!')
		settings_list = d[res.server_section_name]
		for setting in settings_list:
			res.server_settings.append(ServerSettings.from_dict(setting))
		return res

	@staticmethod
	def from_json(x):
		return ConfigFile.from_dict(json.loads(x))
	
	@staticmethod
	def from_toml(x):
		return ConfigFile.from_dict(toml.loads(x))
	
	def to_toml(self):
		return toml.dumps(self.to_dict())
	
	def to_json(self):
		return json.dumps(self.to_dict())


cliarg2key = {
	'ip' : 'ip',
	'port' : 'port',
	'c' : 'command'
}

"""
from antlmrelay.common.settings import *

clitype2obj = {
	RELAYClientType.SMB : SMBClientSettings,
	RELAYClientType.LDAP : LDAPClientSettings,
	RELAYClientType.LDAPS : LDAPSClientSettings,
	RELAYClientType.HTTP : HTTPClientSettings,
	RELAYClientType.HTTPS : HTTPSClientSettings,
	RELAYClientType.TSCH : TSCHClientSettings,
	RELAYClientType.RSRV : RSRVClientSettings,
	RELAYClientType.SRVS : SRVSClientSettings,
	RELAYClientType.SAMR : SAMRSClientSettings,
	RELAYClientType.EVEN6 : EVEN6ClientSettings,
}

srvtype2obj = {
	RELAYServerType.SMB : SMBServerSettings,
	RELAYServerType.HTTP : HTTPServerSettings,
}

"""

