
import asyncio
import traceback
from octopwn.servers.wsnetws.protocol import OPCMD, CMD, WSNOK, CMDType, WSNSocketData, WSNConnect
from asysocks.unicomm.common.proxy import UniProxyProto

class WSNETSocksProxy:
	def __init__(self, in_q, ws, token, connectionfactory):
		self.in_q = in_q
		self.ws = ws
		self.token = token
		self.out_queue = asyncio.Queue()
		self.connectionfactory = connectionfactory
		self.timeout = 10
		
		self.in_task = None
		self.out_task = None

		self.buffer = b''
		self.bufferlock = asyncio.Lock()
		self.closed_event = asyncio.Event()
		self.data_in_evt = asyncio.Event()

	async def terminate(self):
		if self.in_task is not None:
			self.in_task.cancel()

	def close(self):
		self.out_queue.put_nowait(None)
		
		if self.in_task is not None:
			self.in_task.cancel()
		if self.out_task is not None:
			self.out_task.cancel()
		self.closed_event.set()
		self.data_in_evt.set()
	
	async def sr(self, cmd:CMD):
		try:
			await asyncio.wait_for(self.ws.send(cmd.to_bytes()), timeout = self.timeout)
			reply = await self.in_q.get()
			if reply.type == CMDType.ERR:
				raise Exception("Reason: %s Extra: %s" % (reply.reason, reply.extra))
			return reply, None
		except Exception as e:
			return None, e
	

	async def __handle_in(self):
		try:
			while self.ws.open is True:
				cmd = await self.in_q.get()
				if cmd.type == CMDType.OK:
					print('Remote end terminated the socket')
					raise Exception('Remote end terminated the socket')
				elif cmd.type == CMDType.ERR:
					print('Proxy sent error during data transmission. Killing the tunnel.')
					raise Exception('Proxy sent error during data transmission. Killing the tunnel.')

				self.buffer += cmd.data
				self.data_in_evt.set()
				if cmd.data == b'':
					break
		except asyncio.CancelledError:
			return
		except Exception as e:
			print(e)
			return
		finally:
			self.close()

	async def __handle_out(self):
		try:
			while self.ws.open is True:
				data = await self.out_queue.get()
				if data is None or data == b'':
					return
				cmd = WSNSocketData(self.token, data)
				await self.ws.send(cmd.to_bytes())
		except Exception as e:
			traceback.print_exc()
			return
		finally:
			try:
				if self.ws.open is True:
					cmd = WSNOK(self.token)
					await self.ws.send(cmd.to_bytes())
			except:
				pass

	async def connect(self, ip, port, protocol:UniProxyProto):
		try:
			#if protocol != UniProxyProto.CLIENT
			#print('proxy connect: %s %s %s' % (ip, port, protocol))
			cmd = WSNConnect(self.token, 'TCP', ip, port)
			reply, err = await self.sr(cmd)
			if err is not None:
				raise err
			
			if reply.type == CMDType.CONTINUE:
				self.in_task = asyncio.create_task(self.__handle_in())
				self.out_task = asyncio.create_task(self.__handle_out())
				return self, self, None
			raise Exception('Connection failed, expected CONTINUE, got %s' % cmd.type.value)
			
		except Exception as e:
			return None, None, e

	#############################################################################################################

	def write(self, data):
		self.out_queue.put_nowait(data)

	#def close(self):
	#already defined...
		
	async def drain(self):
		await asyncio.sleep(0)
		return

	#############################################################################################################

	async def read(self, n = -1):
		try:
			if self.closed_event.is_set():
				return b''

			async with self.bufferlock:
				if n == -1:
					if len(self.buffer) == 0:
						self.data_in_evt.clear()
						await self.data_in_evt.wait()


					temp = self.buffer
					self.buffer = b''
				else:
					if len(self.buffer) == 0:
						self.data_in_evt.clear()
						await self.data_in_evt.wait()
					
					temp = self.buffer[:n]
					self.buffer = self.buffer[n:]

			return temp

		except Exception as e:
			#print(e)
			self.closed_event.set()
			raise

	async def readexactly(self, n):
		try:
			if self.closed_event.is_set():
				raise Exception('Pipe broken!')

			if n < 1:
				raise Exception('Readexactly must be a positive integer!')

			async with self.bufferlock:
				while len(self.buffer) < n:
					self.data_in_evt.clear()
					await self.data_in_evt.wait()
				
				#print('self.buffer %s' % self.buffer)
				temp = self.buffer[:n]
				self.buffer = self.buffer[n:]
				#print('readexactly ret %s' % temp)
			return temp

		except Exception as e:
			#print(e)
			self.closed_event.set()
			raise

	async def readuntil(self, separator = b'\n'):
		try:
			if self.closed_event.is_set():
				raise Exception('Pipe broken!')

			async with self.bufferlock:
				while self.buffer.find(separator) == -1:
					self.data_in_evt.clear()
					await self.data_in_evt.wait()
				
				end = self.buffer.find(separator)+len(separator)
				temp = self.buffer[:end]
				self.buffer = self.buffer[end:]
				#print('readuntil ret %s' % temp)
			return temp

		except Exception as e:
			#print(e)
			self.closed_event.set()
			raise

	async def readline(self):
		return await self.readuntil(b'\n')
	
	def at_eof(self):
		return self.closed_event.is_set() and len(self.buffer) == 0

	def __deepcopy__(self, memo=None):
		newproxy, err = self.connectionfactory()
		if err is not None:
			raise err
		return newproxy