import io
import json
import enum
import ipaddress
import datetime

def readBytes(buff:io.BytesIO):
	strlen = int.from_bytes(buff.read(4), byteorder='big', signed = False)
	data = buff.read(strlen)
	return data

def writeBytes(buff:io.BytesIO, data):
	dlen = len(data).to_bytes(4, byteorder='big', signed = False)
	buff.write(dlen)
	buff.write(data)

def readStr(buff:io.BytesIO, encoding='ascii'):
	strlen = int.from_bytes(buff.read(4), byteorder='big', signed = False)
	data = buff.read(strlen).decode(encoding)
	return data

def writeStr(buff:io.BytesIO, data, encoding='ascii'):
	if isinstance(data, str) is False:
		data = str(data)
	data = data.encode(encoding)
	dlen = len(data).to_bytes(4, byteorder='big', signed = False)
	buff.write(dlen)
	buff.write(data)


class UniversalEncoder(json.JSONEncoder):
	"""
	Used to override the default json encoder to provide a direct serialization for formats
	that the default json encoder is incapable to serialize
	"""
	def default(self, obj):
		if isinstance(obj, datetime.datetime):
			return obj.isoformat()
		elif isinstance(obj, enum.Enum):
			return obj.value
		elif isinstance(obj, (ipaddress.IPv4Address, ipaddress.IPv6Address)):
			return str(obj)
		elif hasattr(obj, 'to_dict'):
			return obj.to_dict()
		else:
			return json.JSONEncoder.default(self, obj)