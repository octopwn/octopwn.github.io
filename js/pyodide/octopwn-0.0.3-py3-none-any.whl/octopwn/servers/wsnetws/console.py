import asyncio
import os
from typing import Dict
import websockets

from octopwn.common.proxy import Proxy
from octopwn.common.credential import Credential
from octopwn.clients.scannerbase import ScannerConsoleBase
from octopwn.servers.wsnetws.protocol import CMD
from octopwn.servers.wsnetws.agent import WSNETWSAgent
from octopwn.common.clientconfig import UtilsConfig
from asyauth.common.subprotocols.custom import SubProtocolCustom
from asyauth.common.constants import asyauthSubProtocol

class WSNETServer(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'listen_ip': (str, '0.0.0.0'),
			'listen_port': (int, 8901),
			'sslcert': (str, None),
			'sslkey': (str, None),
			'sslca': (str, None),
			'autoapply': (bool, True),
		}

		self.wsserver = None
		self.agents:Dict[bytes] = {}
		self.registered_agents_ctr = 0

	async def __create_agent_session(self, agentid, ws, info):
		try:
			#adding client
			clid = self.octopwnobj.get_clientid()
			clientname = '[AGENT-WS/%s]' % clid
			prompt = '[%s] '% ('AGENT-WS')
			cmd_q = asyncio.Queue()
			client = WSNETWSAgent(clid, (agentid, ws, info), cmd_q, self.octopwnobj.client_msg_queue, prompt, self.octopwnobj)
			client_settings = UtilsConfig('AGENT-WS', clientname, client.make_completer(), 'WSNETWSAgent')
			client.load_settings(client_settings)
			
			_, err = await self.octopwnobj.screen_handler.create_client_window(clid, prompt, client_settings, client)
			if err is not None:
				raise err
			
			client_task, err = await client.run()
			if err is not None:
				raise err
				
			self.octopwnobj.client_messages[clid] = []
			self.octopwnobj.clients[clid] = (client_settings, client)
			await self.octopwnobj.do_refreshclients()

			infod = info.to_dict()
			#adding credential
			domain = infod.get('domain')
			username = infod.get('username')
			udomain = None
			if username is not None:
				if username.find('\\') is not None:
					udomain, username = username.split('\\', 1)
			if domain is None and udomain is not None:
				domain = udomain

			credential = Credential(str(username), '', '', domain = domain, description='WSNETWS -> AGENT[%s]' % clid, subprotocol = asyauthSubProtocol.CUSTOM, subprotocolobj=SubProtocolCustom(client))
			_, err = await self.octopwnobj.addcredential_obj(credential, to_print = False)
			if err is not None:
				raise err
			
			proxy = Proxy('CUSTOM', '', port = 0, description='WSNETWS -> AGENT[%s]' % clid, proxyfactory=client.create_proxy)
			_, err = await self.octopwnobj.addproxy_obj(proxy, to_print = False)
			if err is not None:
				raise err
			
			if self.params['autoapply'][1] is True and self.registered_agents_ctr == 0:
				await client.do_applyinfo()

			self.registered_agents_ctr += 1

			return client.closed_evt, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Agent creation failed!')
			return None, e

	async def handle_client(self, ws, path):
		agentid = None
		try:
			agentid = os.urandom(16)
			self.agents[agentid] = ws
			remote_ip, remote_port = ws.remote_address
			await self.print('AGENT connected from %s:%d' % (remote_ip, remote_port))
			try:
				data = await ws.recv()
				#await self.print('DATA IN: %s' % data)
				token = data[6:22]
				if token == b'\x00'*16:
					reply = CMD.from_bytes(data)
					agent_closed_evt, err = await self.__create_agent_session(agentid, ws, reply)
					if err is not None:
						return
					await agent_closed_evt.wait()
				else:
					raise Exception('Agent did not send info request! Terminating agent...')
					
			except Exception as e:
				await self.print_exc(e, extra_msg='Error in agent handling')
				return
		except Exception as e:
			await self.print_exc(e, extra_msg='Server crasheded')
		finally:
			if agentid in self.agents:
				del self.agents[agentid]
				#await self.signal_q_out.put(('AGENTOUT', agentid, None))
			await ws.close()

	async def do_stop(self):
		if self.wsserver is not None:
			self.wsserver.stop()
		
		await self.print('Stopped!')


	async def do_serve(self):
		#TODO: ssl_ctx builder...
		self.wsserver = await websockets.serve(self.handle_client, self.params['listen_ip'][1], self.params['listen_port'][1], ssl=None)
		await self.wsserver.wait_closed()
		print('Agent handler exiting')
