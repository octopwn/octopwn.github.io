from octopwn.servers.wsnetws.protocol import *
import asyncio
from asyauth.protocols.ntlm.client.native import NTLMClientNative
from asyauth.common.credentials.ntlm import NTLMCredential
from asyauth.common.credentials.kerberos import KerberosCredential
from asyauth.common.winapi.constants import ISC_REQ
from minikerberos.protocol.asn1_structs import AP_REQ, AP_REP
from minikerberos.protocol.encryption import Key
from asyauth.protocols.kerberos.gssapi import get_gssapi, GSSWrapToken
from asyauth.protocols.kerberos.gssapismb import get_gssapi as gssapi_smb
from asyauth.common.winapi.token import InitialContextToken
from minikerberos.protocol.encryption import Key, _enctype_table, _HMACMD5, Enctype, _checksum_table
import copy

class AuthProxy:
	def __init__(self, in_q, ws, token):
		self.in_q = in_q
		self.ws = ws
		self.token = token
		self.iter = 0
		self.timeout = 10

	async def sr(self, cmd:CMD):
		try:
			await asyncio.wait_for(self.ws.send(cmd.to_bytes()), timeout = self.timeout)
			reply = await self.in_q.get()
			if reply.type == CMDType.ERR:
				raise Exception("Reason: %s Extra: %s" % (reply.reason, reply.extra))
			return reply, None
		except Exception as e:
			return None, e
	
	async def get_sequenceno(self):
		try:
			cmd = WSNGetSequenceNo(self.token)
			#print(cmd.to_bytes())
			reply, err = await self.sr(cmd)
			if err is not None:
				raise err

			if reply.type == CMDType.AUTHERR:
				raise Exception('Connection failed, proxy sent error. Err: %s' % reply.get_details())
			
			#print('reply.encdata %s' % reply.encdata)
			return reply.encdata, None
		
		except Exception as e:
			return None, e

	async def get_sessionkey(self):
		try:
			cmd = WSNGetSessionKey(self.token)
			reply, err = await self.sr(cmd)
			if err is not None:
				raise err

			if reply.type == CMDType.AUTHERR:
				raise Exception('Connection failed, proxy sent error. Err: %s' % reply.get_details())
			
			return reply.sessionkey, None
		
		except Exception as e:
			return None, e

	async def authenticate(self, auth_type, username, target, credusage, flags, authdata):
		try:
			if auth_type.upper() == 'KERBEROS':
				cmd = WSNKerberosAuth(self.token, target, username, credusage, flags, authdata)
				reply, err = await self.sr(cmd)
				if err is not None:
					raise err
				if reply.type == CMDType.AUTHERR:
					raise Exception('Connection failed, proxy sent error. Err: %s' % reply.get_details())
				
				self.iter += 1

				return reply.status, reply.ctxattr, reply.authdata, None

			elif auth_type.upper() == 'NTLM':
				if self.iter == 0:
					cmd = WSNNTLMAuth(self.token, username, credusage, flags, target)
					reply, err = await self.sr(cmd)
					if err is not None:
						raise err
					if reply.type == CMDType.AUTHERR:
						raise Exception('Connection failed, proxy sent error. Err: %s' % reply.get_details())

					self.iter += 1
					return reply.status, reply.ctxattr, reply.authdata, None
				
				elif self.iter == 1:
					cmd = WSNNTLMChallenge(self.token, authdata, flags, target)
					reply, err = await self.sr(cmd)
					if err is not None:
						raise err
					if reply.type == CMDType.AUTHERR:
						raise Exception('Connection failed, proxy sent error. Err: %s' % reply.get_details())

					self.iter += 1
					return reply.status, reply.ctxattr, reply.authdata, None
				
				else:
					raise Exception('Too many tries for NTLM!')
		except Exception as e:
			return None, None, None, e


class AuthProxyNTLMClient:
	def __init__(self, authproxy:AuthProxy, credential:NTLMCredential, authfactory):
		self.authproxy = authproxy
		self.orig_credential = copy.deepcopy(credential)
		self.authfactory = authfactory
		self.ntlm_ctx = NTLMClientNative(credential)

	@property
	def ntlmChallenge(self):
		return self.ntlm_ctx.ntlmChallenge
	
	def get_seq_number(self):
		return self.ntlm_ctx.seq_number
		
	def get_sealkey(self, mode = 'Client'):
		return self.ntlm_ctx.get_sealkey(mode = mode)
			
	def get_signkey(self, mode = 'Client'):
		return self.ntlm_ctx.get_signkey(mode = mode)
	
	async def encrypt(self, data, sequence_no):
		return await self.ntlm_ctx.encrypt(data, data, sequence_no)

	async def decrypt(self, data, sequence_no, direction='init', auth_data=None):
		return await self.ntlm_ctx.decrypt(data, sequence_no, direction=direction, auth_data=auth_data)

	async def sign(self, data, message_no, direction=None, reset_cipher = False):
		return await self.ntlm_ctx.sign(data, message_no, direction=direction, reset_cipher = reset_cipher)

	async def verify(self, data, signature):
		return await self.ntlm_ctx.verify(data, signature)
		
	def SEAL(self, signingKey, sealingKey, messageToSign, messageToEncrypt, seqNum, cipher_encrypt):
		return self.ntlm_ctx.SEAL(signingKey, sealingKey, messageToSign, messageToEncrypt, seqNum, cipher_encrypt)
		
	def SIGN(self, signingKey, message, seqNum, cipher_encrypt):
		return self.ntlm_ctx.SIGN(signingKey, message, seqNum, cipher_encrypt)
	
	def get_session_key(self):
		return self.session_key
		
	def get_extra_info(self):
		return self.ntlm_ctx.get_extra_info()
		
	def is_extended_security(self):
		return self.ntlm_ctx.is_extended_security()
	
	def signing_needed(self):
		return self.ntlm_ctx.signing_needed()
	
	def encryption_needed(self):
		return self.ntlm_ctx.encryption_needed()
		
	async def encrypt(self, data, message_no):
		return await self.ntlm_ctx.encrypt(data, message_no)
		
	async def decrypt(self, data, sequence_no, direction='init', auth_data=None):
		return await self.ntlm_ctx.decrypt(data, sequence_no, direction=direction, auth_data=auth_data)
	
	async def authenticate(self, authData = None, flags = None, seq_number = 0, spn = None, cb_data = None):
		try:
			to_continue = False
			if flags is None:
				flags = ISC_REQ.CONNECTION | ISC_REQ.INTEGRITY | ISC_REQ.CONFIDENTIALITY
			flags = int(flags)
			if authData is None:
				authData = b''
			if spn is None:
				spn = ''

			
			if authData is None:
				status, ctxattr, data, err = await self.authproxy.authenticate('NTLM', '', spn, 3, flags, authData)
				if err is not None:
					raise err
				self.ntlm_ctx.load_negotiate(data)
				self.ntlm_ctx.credential.flags = ISC_REQ(ctxattr)
				return data, True, None
			else:
				self.ntlm_ctx.load_challenge(authData)
				status, ctxattr, data, err = await self.authproxy.authenticate('NTLM', '', spn, 3, flags, authData)
				if err is not None:
					raise err
				self.ntlm_ctx.load_authenticate(data)
				self.ntlm_ctx.credential.flags = ISC_REQ(ctxattr)
				if self.ntlm_ctx.encryption_needed() is True or self.ntlm_ctx.signing_needed() is True:
					self.session_key, err = await self.authproxy.get_sessionkey()
					if err is not None:
						raise err
					self.ntlm_ctx.load_sessionkey(self.session_key)
				
				return data, to_continue, None
		except Exception as e:
			return None, False, e

	def __deepcopy__(self, memo=None):
		return self.authfactory(copy.deepcopy(self.orig_credential))

class AuthProxyKerberosClient:
	def __init__(self, authproxy:AuthProxy, credential:KerberosCredential, authfactory):
		self.authproxy = authproxy
		self.authfactory = authfactory
		self.orig_credential = copy.deepcopy(credential)
		self.iterations = 0
		self.gssapi = None
		self.etype = None
		self.actual_ctx_flags = None

		self.seq_number = None
		self.session_key = None

	def get_seq_number(self):
		return self.seq_number

	def signing_needed(self):
		return ISC_REQ.INTEGRITY in self.actual_ctx_flags
	
	def encryption_needed(self):
		return ISC_REQ.CONFIDENTIALITY in self.actual_ctx_flags
		
	async def encrypt(self, data, message_no):
		return self.gssapi.GSS_Wrap(data, message_no)
		
	async def decrypt(self, data, message_no, direction='init', auth_data=None):
		return self.gssapi.GSS_Unwrap(data, message_no, direction=direction, auth_data=auth_data)
	
	def get_session_key(self):
		return self.session_key
	
	async def authenticate(self, authData = None, flags = ISC_REQ.CONNECTION, seq_number = 0, client_name = None, spn=None, cb_data = None):
		try:
			if authData is None:
				authData = b''
			if spn is None:
				spn = ''
			if flags is None:
				flags = ISC_REQ.CONNECTION
			
			
			#authdata is only for api compatibility reasons
			if ISC_REQ.USE_DCE_STYLE in flags or ISC_REQ.MUTUAL_AUTH in flags:
				if self.iterations == 0:
					flags = ISC_REQ.CONFIDENTIALITY | \
							ISC_REQ.INTEGRITY | \
							ISC_REQ.MUTUAL_AUTH | \
							ISC_REQ.REPLAY_DETECT | \
							ISC_REQ.SEQUENCE_DETECT|\
							ISC_REQ.USE_DCE_STYLE
					
					status, retflags, token, err = await self.authproxy.authenticate('KERBEROS', '', spn, 3, int(flags), authData)
					if err is not None:
						raise err
					self.actual_ctx_flags = ISC_REQ(retflags)
					#print(token.hex())
					self.iterations += 1
					return token, True, None
				
				elif self.iterations == 1:
					flags = ISC_REQ.USE_DCE_STYLE
					status, retflags, token, err = await self.authproxy.authenticate('KERBEROS', '', spn, 3, int(flags), authData)
					if err is not None:
						raise err
					
					aprep = AP_REP.load(token).native
					self.actual_ctx_flags = ISC_REQ(retflags)
					self.session_key, err = await self.authproxy.get_sessionkey()
					if err is not None:
						raise err

					if aprep['enc-part']['etype'] != 23: #no need for seq number in rc4
						raw_seq_data, err = await self.authproxy.get_sequenceno()
						if err is not None:
							raise err
						self.seq_number = GSSWrapToken.from_bytes(raw_seq_data[16:]).SND_SEQ

					
					subkey = Key(aprep['enc-part']['etype'], self.get_session_key())
					self.gssapi = gssapi_smb(subkey)
					
					self.iterations += 1
					return token, False, None
					
				else:
					raise Exception('SSPI Kerberos -RPC - auth encountered too many calls for authenticate.')
				
			else:
				if self.iterations > 1:
					raise Exception('More than one iterations should not be possbile with current flag settings!')
				status, retflags, token, err = await self.authproxy.authenticate('KERBEROS', '', spn, 3, int(flags), authData)
				if err is not None:
					raise err
				
				self.actual_ctx_flags = ISC_REQ(retflags)
				self.session_key, err = await self.authproxy.get_sessionkey()
				if err is not None:
					raise err

				
				token = InitialContextToken.load(token)
				apreq = AP_REQ(token.native['innerContextToken'])
				skey = Key(apreq.native['ticket']['enc-part']['etype'], self.get_session_key())
				
				if self.signing_needed() is True or self.encryption_needed() is True:
					raw_seq_data, err = await self.authproxy.get_sequenceno()
					if err is not None:
						raise err
					self.seq_number = GSSWrapToken.from_bytes(raw_seq_data[16:]).SND_SEQ

				self.gssapi = get_gssapi(skey)
				self.iterations = 1
				
				return apreq.dump(), False, None
		except Exception as e:
			return None, True, e
	
	def __deepcopy__(self, memo=None):
		return self.authfactory(copy.deepcopy(self.orig_credential))