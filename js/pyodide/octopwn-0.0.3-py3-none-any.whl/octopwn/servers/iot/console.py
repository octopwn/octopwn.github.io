import asyncio
import os
from typing import Dict
import websockets

from octopwn.clients.scannerbase import ScannerConsoleBase
from octopwn.servers.wsnetws.protocol import CMD
from octopwn.servers.wsnetws.agent import WSNETWSAgent
from octopwn.common.clientconfig import UtilsConfig

class IOTServer(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')

		self.params = {
			'listen_ip': (str, '0.0.0.0'),
			'listen_port': (int, 8011),
			'sslcert': (str, None),
			'sslkey': (str, None),
			'sslca': (str, None),
		}

		self.wsserver = None
		self.devices:Dict[bytes] = {}
		self.__current_device_id = 1
	
	def get_device_id(self):
		t = self.__current_device_id
		self.__current_device_id += 1
		return str(t)

	async def __create_device_session(self, agentid, ws, info):
		try:
			#adding client
			clid = self.octopwnobj.get_clientid()
			clientname = '[DEVICE-%s]' % clid
			prompt = '[%s] '% ('DEVICE')
			cmd_q = asyncio.Queue()
			client = WSNETWSAgent(clid, (agentid, ws, info), cmd_q, self.octopwnobj.client_msg_queue, prompt, self.octopwnobj)
			client_settings = UtilsConfig('DEVICE', clientname, client.make_completer(), 'DEVICE')
			client.load_settings(client_settings)
			
			_, err = await self.octopwnobj.screen_handler.create_client_window(clid, prompt, client_settings, client)
			if err is not None:
				raise err
			
			client_task, err = await client.run()
			if err is not None:
				raise err
				
			self.octopwnobj.client_messages[clid] = []
			self.octopwnobj.clients[clid] = (client_settings, client)
			await self.octopwnobj.do_refreshclients()

			return client.closed_evt, None
		except Exception as e:
			await self.print_exc(e, extra_msg='Agent creation failed!')
			return None, e

	async def handle_device(self, ws, path):
		device = None
		device_id = None
		try:
			data_raw = await ws.recv()
			packet = Packet()
			try:
				packet.ParseFromString(data_raw)
			except Exception as e:
				print('Device sent unintelligable stuff %s' % data_raw)
				return
			
			print(str(packet)[0:50])
			if packet.cmd != CommandType.HWREGISTERREQ:
				print('Device did not send register request!')
				await ws.send(self.get_error(packet.token, ''))
				return
			
			msg = HardwareRegisterRequest()
			msg.ParseFromString(packet.data)

			if self.authenticator is not None:
				if self.authenticator.authenticate_device(msg.username, msg.password) is False:
					print('[!] Device authentication failed! Dropping device!')
					return
			
			device_id = self.get_device_id()
			in_q = asyncio.Queue()
			device = Device(ws, in_q, msg, device_id)
			

			msg = HardwareRegisterResponse()
			msg.registrationToken = device_id
			rep_packet = Packet()
			rep_packet.cmd = CommandType.HWREGISTERRESP
			rep_packet.token = packet.token
			rep_packet.data = msg.SerializeToString()

			await ws.send(rep_packet.SerializeToString())

			rep_packet = Packet()
			rep_packet.cmd = CommandType.OK
			rep_packet.token = packet.token

			await ws.send(rep_packet.SerializeToString())

			self.__devices[device_id] = device
			evt, err = await self.__create_device_session()
			if err is not None:
				raise err
			await evt.wait()
			print('Device disconnecting!')
			
		except Exception as e:
			traceback.print_exc()
		finally:
			try:
				del self.__devices[device_id]
			except:
				pass
			
			if device is None or device_id is None:
				return

			for op in device.subscriptions:
				try:
					del op.subscriptions[device_id]
				except:
					pass


		agentid = None
		try:
			agentid = os.urandom(16)
			self.agents[agentid] = ws
			remote_ip, remote_port = ws.remote_address
			await self.print('AGENT connected from %s:%d' % (remote_ip, remote_port))
			try:
				data = await ws.recv()
				#await self.print('DATA IN: %s' % data)
				token = data[6:22]
				if token == b'\x00'*16:
					reply = CMD.from_bytes(data)
					agent_closed_evt, err = await self.__create_agent_session(agentid, ws, reply)
					if err is not None:
						return
					await agent_closed_evt.wait()
				else:
					raise Exception('Agent did not send info request! Terminating agent...')
					
			except Exception as e:
				await self.print_exc(e, extra_msg='Error in agent handling')
				return
		except Exception as e:
			await self.print_exc(e, extra_msg='Server crasheded')
		finally:
			if agentid in self.agents:
				del self.agents[agentid]
				#await self.signal_q_out.put(('AGENTOUT', agentid, None))
			await ws.close()

	async def do_stop(self):
		if self.wsserver is not None:
			self.wsserver.stop()
		
		await self.print('Stopped!')


	async def do_serve(self):
		#TODO: ssl_ctx builder...
		self.wsserver = await websockets.serve(self.handle_device, self.params['listen_ip'][1], self.params['listen_port'][1], ssl=None)
		await self.wsserver.wait_closed()
		print('Agent handler exiting')
