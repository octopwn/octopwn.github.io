import asyncio
from typing import Dict
from octopwn.clients.scannerbase import ScannerConsoleBase
from websockets.client import WebSocketClientProtocol

#TODO: implement this!

class Peripheral:
	def __init__(self):
		pass
	
	async def getbool(self):
		raise NotImplementedError()

	async def setbool(self, newstate, remote = False):
		raise NotImplementedError()

	async def getint(self):
		raise NotImplementedError()
	
	async def setint(self, newint, remote = False):
		raise NotImplementedError()

	async def getstring(self):
		raise NotImplementedError()
	
	async def setstring(self, newint, remote = False):
		raise NotImplementedError()

	async def getbytes(self):
		raise NotImplementedError()
	
	async def setbytes(self, newint, remote = False):
		raise NotImplementedError()

	async def gettag(self, tag):
		raise NotImplementedError()
	
	async def settag(self, tag, newbytes, remote = False):
		raise NotImplementedError()

	async def getvideo(self, x,y,width, height, vtype, data):
		raise NotImplementedError()

	async def getaudio(self, data):
		raise NotImplementedError()

class SwitchController(ScannerConsoleBase, Peripheral):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.state:bool = None
		self.out_q = None

	async def start(self):
		return True, None

	async def do_state(self):
		await self.print(self.state)

	async def setbool(self, newstate, remote = False):
		if remote is False:
			await self.out_q.put()

class Device(ScannerConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ScannerConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.nologon_commands.append('any')
		self.params = {}
		self.device_id = connection[0]
		self.ws = connection[1]
		self.deviceinfo = connection[2]
		self.closed_evt = asyncio.Event()
		self.__agent_reader_task = None
		self.token_table:Dict[bytes, asyncio.Queue] = {}
		self.peripherals:Dict[str, PeripheralAdded] = {}

	def get_device_info(self):
		msg = HardwareInfo()
		msg.mainModelType = self.deviceinfo.mainModelType
		msg.subModelType = self.deviceinfo.subModelType
		msg.version = self.deviceinfo.version
		msg.description = self.deviceinfo.description
		msg.registrationToken = self.device_id
		msg.peripheralTokens.extend([str(peripheraltoken) for peripheraltoken in self.peripherals])

		peripherals = []
		for pt in self.peripherals:
			peripherals.append(self.peripherals[pt])

		return msg, peripherals

	async def start(self):
		asyncio.create_task(self.__handle_msg_in())
		return True, None
	
	async def __handle_msg_in(self):
		try:
			while self.ws.open is True:
				data_raw = await self.ws.recv()
				try:
					packet = Packet()
					packet.ParseFromString(data_raw)
					#print(str(packet)[0:50])
					if packet.token != self.device_id:
						await self.print('Device is misbehaving!!!')
						return
					if packet.cmd == CommandType.PERIPHERALMESSAGE:
						#for op in self.subscriptions:
						#	await op.out_q.put(data_raw)
						continue
					
					elif packet.cmd == CommandType.PERIPHERALADDED:
						msg = PeripheralAdded()
						msg.ParseFromString(packet.data)
						self.peripherals[msg.peripheral.peripheralToken] = msg.peripheral
						#for op in self.subscriptions:
						#	op.out_q.put(data_raw)
						continue
					
					elif packet.cmd == CommandType.PERIPHERALREMOVED:
						msg = PeriPheralRemoved()
						msg.ParseFromString(packet.data)
						#for op in self.subscriptions:
						#	op.out_q.put(data_raw)
						if msg.peripheralToken in self.peripherals:
							del self.peripherals[msg.peripheralToken]
						continue
				except Exception as e:
					await self.print_exc(e, extra_msg='Device message processing error!')

			await self.print('Device websocket ended!')
		except Exception as e:
			await self.print_exc(e)