
import asyncio

## https://gist.github.com/vxgmichel/e47bff34b68adb3cf6bd4845c4bed448
#class UDPServerProtocol:
#	def __init__(self, in_queue:asyncio.Queue):
#		self.in_queue = in_queue
#
#	def connection_made(self, transport):
#		self.transport = transport
#
#	def datagram_received(self, data, addr):
#		#message = data.decode()
#		#print('Received %r from %s' % (message, addr))
#		#print('Send %r to %s' % (message, addr))
#		#self.transport.sendto(data, addr)
#		self.in_queue.put_nowait((data, addr))
#	
#	def connection_lost(self, exc):
#		self.in_queue.put_nowait((None, exc))
#
#from octopwn.servers.llmnr.console import LLMNRServer
#from octopwn.servers.nbtns.console import NBTNSServer
#from octopwn.servers.mdns.console import MDNSServer
#from octopwn.servers.relay.smbrelay.console import SMBServer
#
#OCTOPWN_SERVER_TABLE = {
#	'LLMNR': LLMNRServer,
#	'NBTNS': NBTNSServer,
#	'MDNS': MDNSServer,
#	'SMBRELAY': SMBServer,
#}

from octopwn.servers.wsnetws.console import WSNETServer

OCTOPWN_SERVER_TABLE = {
    'WSNET' : WSNETServer,
}