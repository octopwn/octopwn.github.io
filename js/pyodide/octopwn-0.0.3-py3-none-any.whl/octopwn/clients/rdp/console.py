from aardwolf import logger
from aardwolf.commons.factory import RDPConnectionFactory
from aardwolf.commons.iosettings import RDPIOSettings
from aardwolf.commons.queuedata import *
from aardwolf.protocol.x224.constants import SUPP_PROTOCOLS
from aardwolf.extensions.RDPECLIP.protocol.formatlist import CLIPBRD_FORMAT
from aardwolf.commons.queuedata.mouse import RDP_MOUSE
from aardwolf.commons.queuedata.constants import MOUSEBUTTON, VIDEO_FORMAT
from octopwn.clients.base import ClientConsoleBase
from octopwn.remote.protocol.python import rdp_pb2, smb_pb2
from octopwn.remote.protocol.python import messages_pb2

from aardwolf.keyboard.layoutmanager import KeyboardLayoutManager
from aardwolf.utils.ducky import DuckyExecutorBase, DuckyReaderFile
from aardwolf.commons.target import RDPConnectionDialect
from aardwolf.keyboard import VK_MODIFIERS


import platform
import asyncio
import datetime

if platform.system().lower() == 'emscripten':
	from pyodide import create_proxy

class RDPClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		# the connection object is in fact a tuple of KerberosCredential and KerberosTarget
		self.nologon_commands.append('login')
		self.nologon_commands.append('duckyfile')
		self.connection = connection
		self.target = connection[0]
		self.credential = connection[1]
		self.__rdpconn = None
		self.__video_task = None
		self.mouse_cb_proxy = None
		self.keyboard_cb_proxy = None
		self.paste_cb_proxy = None
		self.duckyscriptpath = None
		self.remote_clientids = {}
		self.height = None
		self.width = None
		self.bpp = None
		self.help_groups['COMMANDS'] = {
			'CONNECTION' : {'login':0, 'logout': 0, 'nodce':0},
			'CLIPBOARD OPERATIONS' : {'paste':0,},
			'RUBBERDUCKY': {'duckyexec':0, 'duckyfile':0},
		}

	async def start(self):
		return True, None

	async def remote_in(self, remote_clientid:int, msg:messages_pb2.OctoClientMessage, username:str = 'default'):
		try:
			if remote_clientid not in self.remote_clientids:
				await self.print("Unsubscribed client tried to send message to RDP session!")
				return
			if msg.cmdtype == 'RDPMouse':
				cmdmsg = rdp_pb2.RDPMouse()
				cmdmsg.ParseFromString(msg.cmddata)
				await self.mouse_evt(cmdmsg.xPos, cmdmsg.yPos, cmdmsg.button, cmdmsg.isPressed, False)
			
			elif msg.cmdtype == 'RDPKeyboardUnicode':
				cmdmsg = rdp_pb2.RDPKeyboardUnicode()
				cmdmsg.ParseFromString(msg.cmddata)
				if cmdmsg.char is None:
					return
				if len(cmdmsg.char) == 0:
					return
				if cmdmsg.isPressed is None:
					return
				character = cmdmsg.char
				character = character[0]
				await self.keyboard_evt(character, cmdmsg.isPressed, is_scancode = False)

		except Exception as e:
			await self.print_exc(e)

	async def mouse_evt(self, x:int, y:int, button:int, press:bool, release:bool):
		#if press is True:
		#	self.print_sync('MOUSE! X: %s Y: %s BUTTON: %s PRESS: %s RELEASE: %s' % (x, y, button, press, release))
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		button = int(button)
		if button == 1:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_LEFT
		elif button == 2:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_RIGHT
		elif button == 3:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_MIDDLE
		else:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_HOVER
		
		mi = RDP_MOUSE()
		mi.xPos = x
		mi.yPos = y
		mi.button = buttontype
		mi.is_pressed = press
		await self.__rdpconn.ext_in_queue.put(mi)

	async def keyboard_evt(self, keychar:str, press:bool, is_scancode:bool = False):
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		if keychar is None:
			self.print_sync('Not recognized input char: %s Skipping!' % keychar)
			return
		if is_scancode is True:
			ki = RDP_KEYBOARD_SCANCODE()
			ki.is_pressed = press
			if keychar.startswith('VK_') is True:
				ki.vk_code = keychar
			else:
				ki.keyCode = int(keychar)
		else:
			ki = RDP_KEYBOARD_UNICODE()
			ki.char = keychar
			ki.is_pressed = press
		self.__rdpconn.ext_in_queue.put_nowait(ki)
	
	async def ducky_keyboard_sender(self, scancode, is_pressed, as_char = False):
		### Callback function for the duckyexecutor to dispatch scancodes/characters to the remote end
		try:
			if as_char is False:
				ki = RDP_KEYBOARD_SCANCODE()
				ki.keyCode = scancode
				ki.is_pressed = is_pressed
				ki.modifiers = VK_MODIFIERS(0)
				await self.__rdpconn.ext_in_queue.put(ki)
			else:
				ki = RDP_KEYBOARD_UNICODE()
				ki.char = scancode
				ki.is_pressed = is_pressed
				await self.__rdpconn.ext_in_queue.put(ki)
		except Exception as e:
			await self.print_exc(e)
	
	def paste_evt(self, *args):
		# not yet used
		self.print_sync('paste! %s' % args)
	
	async def __video_data_handle(self, is_remote = False):
		try:
			while not self.__rdpconn.disconnected_evt.is_set():
				await asyncio.sleep(0) # this is needed ot let other coroutines function in case we have too manu updates
				data = await self.__rdpconn.ext_out_queue.get()
				if data is None:
					break

				if data.type == RDPDATATYPE.VIDEO:
					if platform.system().lower() == 'emscripten':
						_, err = await self.octopwnobj.screen_handler.update_rdp_canvas(self.client_id, data.data, data.x, data.y, data.width, data.height)
						if err is not None:
							raise err
					elif is_remote is True:
						clients_to_remove = []
						msg = rdp_pb2.RDPFrame()
						msg.format = "RGB"
						msg.xPos = data.x
						msg.yPos = data.y
						msg.width = data.width
						msg.height = data.height
						msg.bitsPerPixel = data.bitsPerPixel
						msg.data = data.data
						for clientid in self.remote_clientids:
							_, err = await self.remotemsg(msg, clientid, remote_token=self.remote_clientids[clientid])
							if err is not None:
								clients_to_remove.append(clientid)
						for clinentid in clients_to_remove:
							del self.remote_clientids[clinentid]
					#else:
					#	# CLI mode how to display video? :(
					#	await self.print("VIDEO DATA: %s" % data.data)

						
				elif data.type == RDPDATATYPE.CLIPBOARD_READY:
					await self.print("Clipboard ready!")
				elif data.type == RDPDATATYPE.CLIPBOARD_CONSUMED:
					await self.print("Clipboard data consumed by server!")
				elif data.type == RDPDATATYPE.CLIPBOARD_NEW_DATA_AVAILABLE:
					await self.print("Got clipboard event: new data is available")
				elif data.type == RDPDATATYPE.CLIPBOARD_DATA_TXT:
					await self.print("Got clipboard data:")
					await self.print(str(data.data))

			await self.print('[-] Connection terminated!')
		
		except asyncio.CancelledError:
			return
		except Exception as e:
			await self.print_exc(e)

	async def do_login(self, size:str = '1024x768', h_token = None, h_clientid = None):
		"""Connect + login"""
		try:
			if h_token is not None:
				self.remote_clientids[h_clientid] = h_token
			if self.logon_ok is True:
				if h_token is None:
					await self.print("Already logged in!")
				else:
					# this section is needed but breaks protocol flow :(
					# by design first we'd need  to send a CONTINUE response before the data
					# TODO fix this!
					msg = rdp_pb2.RDPWindowDimensions()
					msg.width = self.width
					msg.height = self.height
					msg.bitsPerPixel = self.bpp
					_, err = await self.remotemsg(msg, h_clientid, remote_token=h_token)

					#first login of this client, but the connection is already open
					#so we send the entire buffer before the updates
					imgdata = self.__rdpconn.get_desktop_buffer(VIDEO_FORMAT.RAW)
					msg = rdp_pb2.RDPFrame()
					msg.format = "RGB"
					msg.xPos = 0
					msg.yPos = 0
					msg.width = self.width
					msg.height = self.height
					msg.bitsPerPixel = self.bpp
					msg.data = imgdata
					_, err = await self.remotemsg(msg, h_clientid, remote_token=h_token)

				return None, None

			self.__rdpconn = None
			if size is None:
				size = '1024x768'
			
			width, height = size.lower().split('x')
			self.height = int(height)
			self.width = int(width)
			self.bpp = 16 # most of the time

			if platform.system().lower() == 'emscripten':
				self.mouse_cb_proxy = create_proxy(self.mouse_evt)
				self.keyboard_cb_proxy = create_proxy(self.keyboard_evt)
				self.paste_cb_proxy = create_proxy(self.paste_evt)
				_, err = await self.octopwnobj.screen_handler.create_rdp_canvas(self.client_id, '%s[%s][%sx%s]' % (self.connection[0].dialect.name, self.client_id, self.width, self.height), self.width, self.height, self.mouse_cb_proxy, self.keyboard_cb_proxy, self.paste_cb_proxy)
				if err is not None:
					raise err

			iosettings = RDPIOSettings()
			iosettings.video_width = self.width
			iosettings.video_height = self.height
			iosettings.video_bpp_min = 15 #servers dont support 8 any more :/
			iosettings.video_bpp_max = 32
			iosettings.video_out_format = VIDEO_FORMAT.RAW
			iosettings.clipboard_use_pyperclip = False
			
			rdpurl = RDPConnectionFactory(iosettings, target = self.connection[0], credential = self.connection[1], proxies = self.connection[0].proxies)
			self.__rdpconn = rdpurl.get_connection(iosettings)
			
			await self.print('[+] Login started! %s' % datetime.datetime.utcnow())
			_, err = await asyncio.wait_for(self.__rdpconn.connect(), timeout=15)
			if err is not None:
				await self.__rdpconn.terminate()
				raise err
			
			self.__video_task = asyncio.create_task(self.__video_data_handle(h_token is not None))
			self.logon_ok = True
			await self.print('[+] Login OK! %s' % datetime.datetime.utcnow())
			if h_token is not None:
				msg = rdp_pb2.RDPWindowDimensions()
				msg.width = self.width
				msg.height = self.height
				msg.bitsPerPixel = self.bpp
				_, err = await self.remotemsg(msg, h_clientid, remote_token=h_token)

			return None, None

		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_logout(self):
		try:
			self.logon_ok = False
			if self.__video_task is not None:
				self.__video_task.cancel()
				self.__video_task = None
			if self.__rdpconn is not None:
				await self.__rdpconn.terminate()
			self.__rdpconn = None
			await self.print('[-] Connection terminated!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_paste(self, text):
		"""Set remote clipboard text (PASTE)"""
		try:
			if self.logon_ok is False:
				raise Exception("Not logged in!")
			
			if len(text) > 16000:
				raise Exception("Too much data, currently only 16k chars accepted.")

			ki = RDP_CLIPBOARD_DATA_TXT()
			ki.datatype = CLIPBRD_FORMAT.CF_UNICODETEXT
			ki.data = text
			await self.__rdpconn.ext_in_queue.put(ki)
			await self.print("[+] Remote clipboard set!")
			return True, None
			
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_duckyexec(self):
		"""Starts ducky script. You'll need to login first!"""
		try:
			if self.duckyscriptpath is None:
				await self.print("No duckyscript file is set! Use 'duckyscriptpath' command first!")
				return True, None
			
			layout = KeyboardLayoutManager().get_layout_by_shortname(self.__rdpconn.iosettings.client_keyboard)
			executor = DuckyExecutorBase(layout, self.ducky_keyboard_sender, send_as_char = True if self.__rdpconn.target.dialect == RDPConnectionDialect.VNC else False)
			reader = DuckyReaderFile.from_file(self.duckyscriptpath, executor)
			x = asyncio.create_task(reader.parse())
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_screenshot(self):
		try:
			fname = 'screenshot_%s.png' % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
			fpath = self.octopwnobj.sanitize_path(fname)
			self.__rdpconn.get_desktop_buffer().save(fpath)
			await self.print('Screenshot saved to %s' % fname)

		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_duckyfile(self, duckyscriptpath):
		"""Sets duckyscript file to use with duckyexec"""
		try:
			self.duckyscriptpath = duckyscriptpath
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e
		

		

	