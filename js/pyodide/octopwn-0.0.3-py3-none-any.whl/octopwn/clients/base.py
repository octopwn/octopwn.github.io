
# this is a modified version of AIOCMD http://github.com/KimiNewt/aiocmd

from __future__ import annotations
import datetime
import inspect
import asyncio
import traceback
import shlex
import copy
import os
import shutil
from typing import Dict, Tuple
from octopwn.common.utils import chunker, hexdump
from octopwn.remote.protocol.python import messages_pb2

from prompt_toolkit.completion.nested import NestedCompleter
from prompt_toolkit.completion import WordCompleter

class OctoPwnPendingOp:
	def __init__(self, pid, coro, name, started_by):
		self.pid:int = pid
		self.coro:asyncio.coroutine = coro
		self.task:asyncio.Task = None
		self.name:str = name
		self.started_at:datetime.datetime = datetime.datetime.utcnow()
		self.started_by:str = started_by
		self.finished:bool = False
		self.finished_at:datetime.datetime = None
		self.success:bool = None
		self.error:Exception = None
		
	async def run(self):
		self.task = asyncio.create_task(self.coro)
		return await self.task

	async def stop(self):
		if self.task is not None:
			self.task.cancel()

class ClientConsoleBase:
	def __init__(self, client_id:int, connection, cmd_q, msg_queue, prompt, octopwnobj, settings = None):
		self.prompt = prompt
		self.octopwnobj = octopwnobj
		self.settings = settings
		self.ATTR_START = 'do_'
		self.doc_header = ""
		self.aliases = {"?": "help", "exit": "quit"}
		self.cmd_q = cmd_q
		self.client_id = client_id
		self.connection = connection
		self.original_connection = copy.deepcopy(connection)
		self.msg_queue = msg_queue
		self.nologon_commands = ['?', 'help', 'q', 'quit', 'exit', 'listop', 'stop']
		self.logon_ok = False
		self.pending_ops:Dict[int, OctoPwnPendingOp] = {} # IDs of pending operations
		self.pending_ctr = 1

	def get_pendingid(self):
		t = self.pending_ctr
		self.pending_ctr += 1
		return t

	async def start_op(self, coro, name, started_by = 'MAIN'):
		try:
			pid = self.get_pendingid()
			pod = OctoPwnPendingOp(pid, coro, name, started_by)
			self.pending_ops[pid] = pod
			res = await pod.run()
			await self.do_stopop(pid, to_print=False)
			return res
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def do_listop(self, to_print = True, h_token = None):
		try:
			if len(self.pending_ops) == 0 and to_print is True:
				await self.print('No pending operations!')
				return True, None
			for pid in self.pending_ops:
				po = self.pending_ops[pid]
				if po.name == 'listop':
					continue
				if to_print is True:
					await self.print('PID: %s NAME: %s STARTED_AT: %s STARTED_BY: %s' % (pid, po.name, po.started_at.isoformat(), po.started_by))
				if h_token is not None:
					msg = messages_pb2.OctoPendingOp()
					msg.pid = int(pid)
					msg.name = str(po.name)
					msg.startedAt = str(po.started_at.isoformat())
					msg.startedBy = str(po.started_by)
					await self.remotemsg(msg, h_token)
			return True, None
		except Exception as e:
			return None, e

	async def do_stopop(self, pid:int, to_print = True):
		try:
			pid = int(pid)
			if pid not in self.pending_ops:
				if to_print is True:
					await self.print('PID not found!')
				raise Exception('PID not found!')
			await self.pending_ops[pid].stop()
			del self.pending_ops[pid]
			return True, None
		except Exception as e:
			return None, e


	def load_settings(self, settings):
		self.settings = settings
		
	def to_dict(self):
		return {}

	def make_completer(self):
		return NestedCompleter({com: self._completer_for_command(com) for com in self.command_list()})
	
	def _completer_for_command(self, command):
		if not hasattr(self, "_%s_completions" % command):
			return WordCompleter([])
		return getattr(self, "_%s_completions" % command)()
	
	def _get_command(self, command):
		if command in self.aliases:
			command = self.aliases[command]
		return getattr(self, self.ATTR_START + command)

	def _get_command_args(self, command):
		args = [param for param in inspect.signature(self._get_command(command)).parameters.values()
				if param.default == param.empty]
		kwargs = [param for param in inspect.signature(self._get_command(command)).parameters.values()
				  if param.default != param.empty]
		return args, kwargs

	def _get_command_usage(self, command, args, kwargs):
		return ("%s %s %s" % (command,
							  " ".join("<%s>" % arg for arg in args if str(arg).startswith('h_') is False and str(arg).startswith('to_print') is False),
							  " ".join("[%s]" % kwarg for kwarg in kwargs if str(kwarg).startswith('h_') is False and str(kwarg).startswith('to_print') is False),
							  )).strip()
	
	async def _run_single_command(self, username, command, args):
		fullcmd = shlex.join([command] + args)
		await self.print('>>> %s' % fullcmd)
		if 'any' not in self.nologon_commands:
			if self.logon_ok is False and command.lower() not in self.nologon_commands:
				await self.print("Command '%s' can\'t be executed without login first!" % command )
				return
		try:
			command_real_args, command_real_kwargs = self._get_command_args(command)
		except Exception as e:
			await self.print("Unknown command '%s'" % command )
			return
		if len(args) < len(command_real_args) or len(args) > (len(command_real_args) + len(command_real_kwargs)):
			await self.print("Bad command args. Usage: %s" % self._get_command_usage(command, command_real_args, command_real_kwargs))
			return

		try:
			com_func = self._get_command(command)
			if asyncio.iscoroutinefunction(com_func):
				coro = com_func(*args)
				asyncio.create_task(self.start_op(coro, command, started_by = username))
			else:
				#this should not be a thing :(
				com_func(*args)
			return
		except (asyncio.CancelledError):
			raise
		except Exception as ex:
			await self.print('Command "%s" from user "%s" failed: %s Exc: %s' % (command, username, traceback.format_tb(ex.__traceback__), ex))

	def command_list(self):
		return [attr[len(self.ATTR_START):]
				for attr in dir(self) if attr.startswith(self.ATTR_START)] + list(self.aliases.keys())

	async def do_help(self, command:str = None):
		"""Displays help menu"""
		if command is None:
			await self.print()
			if self.doc_header is not None and len(self.doc_header) >0 :
				await self.print(self.doc_header)
				await self.print("=" * len(self.doc_header))
			await self.print("Command list")
			await self.print('Use "help <command>" to get more info on the specific command')
			await self.print()
			cmdmaxlen = max([len(x) for x in self.command_list()]) + 2
			for command in sorted(self.command_list()):
				command_doc = self._get_command(command).__doc__
				if command_doc is None:
					command_doc = ''
				command_doc = command_doc.split('\n',1)[0]
				await self.print('%s%s%s' % (command, ' '*(cmdmaxlen - len(command)), command_doc))
			await self.print()

			#await self.print()
			#await self.print(self.doc_header)
			#await self.print("=" * len(self.doc_header))
			#await self.print()
			#
			#get_usage = lambda command: self._get_command_usage(command, *self._get_command_args(command))
			#max_usage_len = max([len(get_usage(command)) for command in self.command_list()])
			#for command in sorted(self.command_list()):
			#	command_doc = self._get_command(command).__doc__
			#	await self.print(("%-" + str(max_usage_len + 2) + "s%s") % (get_usage(command), command_doc or ""))
		else:
			try:
				self._get_command(command)
			except:
				await self.print('Command not found "%s"' % command)
				return
			alias = self.aliases.get(command, None)
			docstr = self._get_command(command).__doc__
			command_real_args, command_real_kwargs = self._get_command_args(command)
			command_params = self._get_command_usage(command, command_real_args, command_real_kwargs)
			await self.print('Command: "%s"' % command)
			if alias is not None:
				await self.print('Alias  : "%s"' % alias)
			
			await self.print('Usage  : "%s"' % command_params)
			if docstr is None or len(docstr) == 0:
				await self.print("No documentation provided currently.")
				return
			
			await self.print("Help")
			await self.print(docstr)
			await self.print()

	async def remotemsg(self, message, remote_clientid = None, remote_token = None):
		# message is a protobuf message!
		try:
			if self.octopwnobj.screen_handler.remoting_support is False:
				return True, None

			wrapped = messages_pb2.OctoClientMessage()
			wrapped.clientId = self.client_id
			if remote_token is not None:
				wrapped.token = remote_token
			wrapped.cmdtype = message.__class__.__name__
			wrapped.cmddata = message.SerializeToString()
			await self.octopwnobj.screen_handler.dispatch_message(wrapped, remote_clientid)
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_quit(self):
		try:
			if hasattr(self, 'do_logout') is True:
				await self.do_logout()
			if self.client_id != 0:
				await self.octopwnobj.do_switchclient(0)
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_pwd(self):
		"""Prints the path of the current working dir"""
		try:
			await self.print(os.getcwd())
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_lls(self, path = None):
		"""Lists files and folders in given path. Default: current workdir"""
		try:
			for item in os.listdir(path):
				await self.print(item)
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_lcp(self, src, dst):
		"""Copies file from src to dst."""
		try:
			shutil.copy2(src, dst)
			await self.print('File copied!')
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def do_lmove(self, src, dst):
		"""Moves files and folders from src to dst."""
		try:
			shutil.move(src, dst)
			await self.print('File copied!')
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def do_lcat(self, filepath):
		"""Prints !TEXT! file contents to current window"""
		try:
			with open(filepath, 'r') as f:
				for line in f:
					await self.print(line.strip())
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def do_lxxd(self, filepath):
		"""Prints hex contents of the file to the current window"""
		try:
			offset = 0
			with open(filepath, 'r') as f:
				while True:
					data = f.read(1024)
					if data == b'':
						break
					await self.print_hex(data, offset=offset)
					offset += len(data)
		except Exception as e:
			traceback.print_exc()
			return None, e

	def print_sync(self, msg = '', store_file = False):
		asyncio.create_task(self.print(msg))

	async def print(self, msg = ''):
		msg = str(msg)
		for line in msg.split('\n'):
			await self.msg_queue.put((self.client_id, str(line)))
	
	async def print_table(self, lines, separate_head=True):
		"""Prints a formatted table given a 2 dimensional array"""
		#Count the column width
		widths = []
		for line in lines:
				for i,size in enumerate([len(x) for x in line]):
						while i >= len(widths):
								widths.append(0)
						if size > widths[i]:
								widths[i] = size
		
		#Generate the format string to pad the columns
		print_string = ""
		for i,width in enumerate(widths):
				print_string += "{" + str(i) + ":" + str(width) + "} | "
		if (len(print_string) == 0):
				return
		print_string = print_string[:-3]
		
		#Print the actual data
		for i,line in enumerate(lines):
				await self.print(print_string.format(*line))
				if (i == 0 and separate_head):
						await self.print("-"*(sum(widths)+3*(len(widths)-1)))

	async def print_hex(self, data, offset = 0):
		await self.print(hexdump(data, offset=offset))
	
	def print_exc_sync(self, err:Exception, with_tb = True, extra_msg = ''):
		asyncio.create_task(self.print_exc(err, with_tb, extra_msg))

	async def print_exc(self, err:Exception, with_tb = True, extra_msg = ''):
		if with_tb is False:
			await self.print('Error: %s Exception: %s' % (extra_msg, err))
			return
		
		await self.print('Error: %s Exception: %s' % (extra_msg, err))
		for lines in traceback.format_tb(err.__traceback__):
			for line in lines.split('\n'):
				await self.print('Traceback: %s' % line)


	async def change_prompt(self, newprompt):
		self.prompt = newprompt
		await self.octopwnobj.client_changeprompt_cb(self.client_id, newprompt)

	async def __run_core(self):
		try:
			while True:
				try:
					username, command = await self.cmd_q.get()
					if command is None:
						await self.do_quit()
					cmd = shlex.split(command)
					await self._run_single_command(username, cmd[0], cmd[1:])
				except Exception as e:
					await self.print_exc(e)
					continue
		except Exception as e:
			await self.print_exc(e)
			return False, e
	
	async def run(self):
		try:
			if hasattr(self, 'start') is True:
				#additional setup might be needed for the child
				_, err = await self.start()
				if err is not None:
					raise err
			core_task = asyncio.create_task(self.__run_core())
			return core_task, None
			
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def remote_command_internal(self, remote_clientid:int, msg:messages_pb2.OctoClientMessage, username:str = 'default'):
		try:
			if msg.cmdtype == 'OctoClientCommandGeneric':
				cmdmsg = messages_pb2.OctoClientCommandGeneric()
				cmdmsg.ParseFromString(msg.cmddata)

				print(cmdmsg)

				try:
					command_real_args, command_real_kwargs = self._get_command_args(cmdmsg.command)
				except Exception as e:
					await self.print("Unknown command '%s'" % cmdmsg.command )
					return
				
				hasremoteid = False
				hasclientid = False
				finalargs = {}
				cmdargs = command_real_args + command_real_kwargs
				print(cmdargs)
				for x in cmdargs:
					if x.name == 'h_token':
						hasremoteid = True
					if x.name == 'h_clientid':
						hasclientid = True

				for x in zip(cmdargs, cmdmsg.params):
					print(x)
					#print(x)
					#print(x[0].name)
					#print(repr(x[0].annotation))
					cf = str
					if x[0].annotation == 'str' or x[0].annotation is str:
						cf = str
					elif x[0].annotation == 'int' or x[0].annotation is int:
						cf = int
					else:
						print('Unknown annotation type! %s Please add correct annotations to your functions mr. developer!!' % x[0].annotation)

					#not set param	
					if x[1] == 'None':
						continue
					
					finalargs[x[0].name] = cf(x[1])
				
				#print('ARGS: ')
				#for arg in command_real_args:
				#	print(arg)
				#
				#print('KWARGS: ')
				#for arg in command_real_kwargs:
				#	print(arg)
				if hasremoteid is True:
					finalargs['h_token'] = cmdmsg.token # maybe this should be the token?
				if hasclientid is True:
					finalargs['h_clientid'] = remote_clientid # maybe this should be the token?
				

				print(finalargs)
				com_func = self._get_command(cmdmsg.command)
				coro = com_func(**finalargs)
				res = await self.start_op(coro, cmdmsg.command, started_by = username)
				print(res)
				if len(res) != 2:
					print("Res incorrect number of params! FIX THIS SHIT!!!!!")
				res, err = res
				preamble = '[%s][%s] CMD: %s RES: ' % (remote_clientid, self.client_id, cmdmsg.command)
				if err is not None:
					print("%s Sending ERR" % preamble)
					await self.remote_err(remote_clientid, cmdmsg.token, message = str(err))
				elif res is None:
					print("%s Sending CONTINUE" % preamble)
					await self.remote_continue(remote_clientid, cmdmsg.token)
				else:
					print("%s Sending OK" % preamble)
					await self.remote_ok(remote_clientid, cmdmsg.token)
			else:
				await self.print('Unknown command type: %s' % msg.cmdtype)
				await self.remote_in(remote_clientid, msg, username = username)
			
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def remote_ok(self, remote_clientid, token, message = None):
		try:
			msg = messages_pb2.OctoClientReplyOk()
			msg.token = token
			if message is not None:
				msg.message = str(message)
			
			await self.remote_climsg(remote_clientid, msg)
			
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def remote_continue(self, remote_clientid, token, message = None):
		try:
			msg = messages_pb2.OctoClientReplyContinue()
			msg.token = token
			await self.remote_climsg(remote_clientid, msg)
			
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def remote_err(self, remote_clientid, token, message = None):
		try:
			msg = messages_pb2.OctoClientReplyError()
			msg.token = token
			if message is not None:
				msg.message = str(message)
			
			await self.remote_climsg(remote_clientid, msg)

		except Exception as e:
			await self.print_exc(e)
			return False, e
	
	async def remote_climsg(self, remote_clientid, message, remote_token = None):
		try:
			wrapped = messages_pb2.OctoClientMessage()
			wrapped.clientId = self.client_id
			if remote_token is not None:
				wrapped.token = remote_token
			wrapped.cmdtype = message.__class__.__name__
			wrapped.cmddata = message.SerializeToString()
			await self.octopwnobj.screen_handler.dispatch_message(wrapped, remote_clientid)

		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def remote_in(self, remote_clientid:int, msg:messages_pb2.OctoClientMessage, username:str = 'default'):
		try:
			await self.print("SHOULD NOT SEE ME!")

		except Exception as e:
			await self.print_exc(e)

	def normalize_path(self, path):
		startdir = os.path.abspath(self.octopwnobj.work_dir)
		os.path.join(startdir, path)

	async def do_remoteListDirectory(self, path:str, h_remoteid, h_token):
		raise NotImplementedError()
		try:
			async def temp(results):
				with os.scandir(self.normalize_path(path)) as it:
					for entry in it:
						if entry.is_symlink() is True:
							continue
						stat = entry.stat()
						res = {
							'type': 'file' if entry.is_file() is True else 'dir',
							'name' : entry.name,
							'creationtime'    : gts(stat.st_birthtime),
							'lastaccesstime' : gts(stat.st_atime),
							'lastwritetime'  : gts(stat.st_mtime),
							'changetime'      : gts(fsobj.st_mtime),
						}
						if res['type'] == 'file':
							res['size'] = stat.st_size

				for res in results:
					msg = ParseDict(res, smb_pb2.SMBFileEntry())
					await self.remote_climsg(h_clientid, msg, h_token)
				await self.remote_ok(h_clientid, h_token)
			
			x = asyncio.create_task(temp())
			return None, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	