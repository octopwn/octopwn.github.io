import copy
import asyncio
import platform

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from asysocks.client import SOCKSClient
from asysocks.common.comms import SocksQueueComms


class NetCatClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue,prompt, octopwnobj)
		# the connection object is in fact a tuple of KerberosCredential and KerberosTarget
		self.nologon_commands.append('connect')
		self.nologon_commands.append('lineterm')
		self.nologon_commands.append('encoding')
		self.nologon_commands.append('binprint')

		
		self.target = self.connection[0]
		self.credential = self.connection[1]

		self.encoding = 'ascii'
		self.lineterm = '\r\n'
		self.binprint = False
		self.data_in_q = None
		self.data_out_q = None
		self.datareader_task = None
		self.client = None
		self.connection_monitor_task = None
	
	async def start(self):
		return True, None

	async def do_disconnect(self):
		self.logon_ok = False
		if self.connection_monitor_task is not None:
			self.connection_monitor_task.cancel()
		if self.client is not None:
			self.client.terminate()
		if self.writer is not None:
			self.writer.close()
		if self.datareader_task is not None:
			self.datareader_task.cancel()
		await self.print('Connection terminated!')

	async def __print_data(self, data:bytes):
		if self.binprint is True:
			await self.print_hex(data)
		else:
			try:
				await self.print(data.decode(self.encoding))
			except:
				await self.print_hex(data)

	async def __data_reader(self):
		try:
			if self.data_in_q is not None:
				while True:
					data, err = await self.data_in_q.get()
					if err is not None:
						raise err
					await self.__print_data(data)
			else:
				while True:
					data = await self.reader.read(1024)
					await self.__print_data(data)
		except asyncio.CancelledError:
			return

		except Exception as e:
			await self.print_exc(e)
			await self.do_disconnect()
	
	async def __connection_monitor(self):
		try:
			if self.client is not None:
				await self.client.proxy_running_evt.wait()
			else:
				await self.writer.wait_closed()
			await self.do_disconnect()
		except asyncio.CancelledError:
			return
		except Exception as e:
			await self.print_exc(e)


	async def do_connect(self):
		try:
			await self.print('Connecting...')
			if self.target.proxies is not None:
				self.data_in_q = asyncio.Queue()
				self.data_out_q = asyncio.Queue()
				comms = SocksQueueComms(self.data_out_q, self.data_in_q)
				self.client = SOCKSClient(comms, self.target.proxies)
				self.datareader_task = asyncio.create_task(self.__data_reader())
				proxy_coro = await self.client.run(True)
				self.proxy_task = asyncio.create_task(proxy_coro)
			else:
				self.reader, self.writer = await asyncio.open_connection(self.target.get_hostname_or_ip(), self.target.port)
				self.datareader_task = asyncio.create_task(self.__data_reader())
			
			self.connection_monitor_task = asyncio.create_task(self.__connection_monitor())
			self.logon_ok = True
			await self.print('Connected OK!')
		except Exception as e:
			await self.print_exc(e)
			await self.do_disconnect()
	
	async def send(self, data):
		try:
			if self.data_in_q is not None:
				await self.data_out_q.put(data)
			else:
				self.writer.write(data)
				await self.writer.drain()
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_send(self, data:str):
		"""Sends a string encoded by 'encoding' to the socket"""
		await self.send(data.encode(self.encoding) + self.lineterm.encode(self.encoding))

	async def do_sendhex(self, data):
		"""Sends a hex-encoded binary data to the socket. WARNING! Doesn't add line terminator!"""
		await self.send(bytes.fromhex(data))
	
	async def do_sendfile(self, filepath:str, blocksize = 1024):
		"""Reads a file in blocksize and send it to the server"""
		if blocksize is None or blocksize == '':
			blocksize = 1024
		elif isinstance(blocksize, str):
			blocksize = int(blocksize)
		with open(filepath, 'rb') as f:
			while True:
				data = f.read(blocksize)
				if data == b'':
					break
				await self.send(data)
		await self.print('Data sent OK')

	async def do_encoding(self, encoding = ''):
		"""Sets or gets the text encoding for incoming and outgoing text data"""
		if encoding != '':
			self.encoding = encoding
		await self.print('Encoding set to: %s' % self.encoding)
	
	async def do_lineterm(self, lineterm = ''):
		if lineterm != '':
			self.lineterm = lineterm
		await self.print('Line terminator set to: %s' % self.lineterm)
	
	async def do_binprint(self, binprint = ''):
		"""Enables binary print. Incoming data will be printed as hexdump
Use '1' to enable
Use '0' to disable
"""
		if binprint != '':
			self.binprint = bool(int(binprint))
		await self.print('Binary print set to: %s' % self.binprint)