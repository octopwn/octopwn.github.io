import asyncio

from aiosmb import logger
from octopwn.clients.base import ClientConsoleBase
from amurex.clientconnection import SSHClientConnection
from amurex.common.settings import SSHClientSettings

class SSHClient(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue,prompt, octopwnobj, command_modifier=':')
		self.nologon_commands.append('login')
		self.connection = connection
		self.target = self.connection[0]
		self.credential = self.connection[1]
		self.client = None
		self.stdin = None
		self.stdout = None
		self.stderr = None
		self.stdout_reader_task = None
		self.stderr_reader_task = None
		self.help_groups['COMMANDS'] = {
			'CONNECTION' : {'login':0, 'logout': 0},
		}

	async def start(self):
		await self.print('## All commands will be channeled trough SSH.')
		await self.print('## For session control prepend the local commands with ":". Example: ":login" will initiate a login.')
		return True, None

	async def __pipe_reader(self, pipe:asyncio.Queue):
		while True:
			data = await pipe.get()
			if data == b'':
				break
			await self.print(data)
	
	async def do_logout(self):
		try:
			if self.client is not None:
				await self.client.close()
			
			if self.stdout_reader_task is not None:
				self.stdout_reader_task.cancel()
			if self.stderr_reader_task is not None:
				self.stdout_reader_task.cancel()

			await self.print('Connection terminated!')

		except Exception as e:
			self.logon_ok = False
			await self.print_exc(e)
			return None, e

	async def do_login(self):
		"""Login"""
		try:
			settings = SSHClientSettings()
			settings.skip_hostkey_verification = True
			self.client = SSHClientConnection(self.credential, self.target, settings)
			_, err = await self.client.connect()
			if err is not None:
				raise err
			await self.print('Connected')
			self.stdin, self.stdout, self.stderr = await self.client.get_shell()
			await self.print('Shell created!')
			self.stdout_reader_task = asyncio.create_task(self.__pipe_reader(self.stdout))
			self.stderr_reader_task = asyncio.create_task(self.__pipe_reader(self.stderr))
			self.logon_ok = True
			return True, None
		except Exception as e:
			self.logon_ok = False
			await self.print_exc(e)
			return None, e

	async def console_command_handler(self, cmd:str):
		cmd = cmd.encode() + b'\n'
		await self.stdin.put(cmd)

	