# this is a modified version of AIOCMD http://github.com/KimiNewt/aiocmd

import os
import ipaddress
from textwrap import wrap
import traceback

from octopwn.common.utils import isint, create_table
from octopwn.common.target import Target

from prompt_toolkit.completion.nested import NestedCompleter
from prompt_toolkit.completion import WordCompleter
from octopwn.clients.base import ClientConsoleBase
from aiosmb.examples.smbpathcompleter import SMBPathCompleter
from octopwn.common.clientconfig import ScannerConfig
from octopwn.remote.protocol.python import messages_pb2
from octopwn.common.paramsutil import serializeParamsDict


class ScannerConsoleBase(ClientConsoleBase):
	def __init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj):
		ClientConsoleBase.__init__(self, client_id, connection, cmd_q, msg_queue, prompt, octopwnobj)
		self.doc_header = "Use 'options' to list configurable parameters, use 'set' to modify them.\nStart the scan with the 'scan' command."
		self.aliases['set'] = 'setparam'
		target_gens = [] #dynamically populated during scan
		self.params = {}
		self.scan_running = False
	
	def load_config(self, scannerconfig:ScannerConfig):
		def ton(vt, x):
			if x == 'None':
				return None
			if vt == bool:
				x = ton(int,scannerconfig.params[pname])
			return vt(x)

		for pname in scannerconfig.params:
			if pname not in self.params:
				print('Parameter "%s" will be rejected! Are you using the correct version?' % pname)
				continue
			value = ton(self.params[pname][0], scannerconfig.params[pname])
			if len(self.params[pname]) == 2:
				self.params[pname] = (self.params[pname][0], value)
			else:
				self.params[pname] = (self.params[pname][0], value, self.params[pname][2])

	def save_config(self, scannerconfig:ScannerConfig):
		for pname in self.params:
			if self.params[pname][0] == bool:
				scannerconfig.params[pname] = '0' if self.params[pname][1] is False else '1'
			elif self.params[pname][0] == list:
				scannerconfig.params[pname] = self.params[pname][1]
			else:
				scannerconfig.params[pname] = str(self.params[pname][1])
		
		return scannerconfig

	
	def _set_completions(self):
		return self._setparam_completions()

	def _showparam_completions(self):
		return self._setparam_completions()

	def _setparam_completions(self):
		return SMBPathCompleter(get_current_dirs = self.__paramlist)
	
	def _settargetfile_completions(self):
		return SMBPathCompleter(get_current_dirs = self.__localfiles)
	
	def __paramlist(self):
		return list(self.params.keys())
	
	def __localfiles(self):
		return [f for f in os.listdir('.') if os.path.isfile(f)]

	async def do_options(self):
		"""Lists editable parameters"""
		try:
			await self.print('Editable parameters:')
			pt = []
			pt.append(['param', 'value', 'vtype', 'description'])
			for param in self.params:
				decription = ''
				if len(self.params[param]) == 2:
					vtype, value = self.params[param]
				else:
					vtype, value, decription = self.params[param]
				
				value = str(value)
				if len(value) > 50:
					value = value[:20] + ' <TOOLONG> ' + value[-20:]
				pt.append([param, value, str(vtype), decription])
			await self.print(create_table(pt))
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def do_clearparam(self, parameter):
		"""Resets parameters to original state. Only list currently!"""
		try:
			parameter = parameter.lower()
			if parameter not in self.params:
				await self.print('Unknown parameter "%s"' % parameter)
				return False, None
			
			if self.params[parameter][0] != list:
				await self.print('Currently only list-type parameters can be emptied this way.')
				return False, None
			
			self.params[parameter][1].clear()

			msg = messages_pb2.ScannerParamsChangedEvt()
			msg.params.CopyFrom(serializeParamsDict({ parameter : self.params[parameter]}))
			await self.remotemsg(msg)

			return True, None

		
		except Exception as e:
			await self.print_exc(e)
			return None, e
	
	async def do_showparam(self, parameter, to_print = True):
		try:
			parameter = parameter.lower()
			if parameter not in self.params:
				if to_print is True:
					await self.print('Unknown parameter "%s"' % parameter)
				return False, None
			if self.params[parameter][0] == list:
				for x in self.params[parameter][1]:
					await self.print(x)
			else:
				await self.print(str(self.params[parameter][1]))


		except Exception as e:
			await self.print_exc(e)
			return None, e
		

	async def do_setparam(self, parameter, value, to_print = True):
		"""Updates an editable parameter"""
		try:
			parameter = parameter.lower()
			if parameter not in self.params:
				if to_print is True:
					await self.print('Unknown parameter "%s"' % parameter)
				return False, None
			
			if parameter == 'targets':
				targetid = value
				if targetid == 'all':
					for tid in self.octopwnobj.targets:
						if self.octopwnobj.targets[tid].hidden is True:
							continue
						self.params[parameter][1].append(self.octopwnobj.targets[tid].get_hostname_or_ip())
					return True, None
				if isint(targetid) is True:
					self.params[parameter][1].append(self.octopwnobj.targets[int(targetid)].get_hostname_or_ip())
				else:
					# ip/ ipnetwork/hostname goes here
					self.params[parameter][1].append(targetid)

				return True, None
			
			if parameter == 'targetfiles':
				try:
					x = open(value, 'r')
					x.close()
					self.params[parameter][1].append(value)
				except Exception as e:
					if to_print is True:
						await self.print('Could not set target file! Does the file exist? Err: %s' % e)
					return None, e
				
				return True, None

			if self.params[parameter][0] != list:
				self.params[parameter] = (self.params[parameter][0], self.params[parameter][0](value))
			else:
				vl = []
				for v in value.split(','):
					vl.append(v)
				self.params[parameter] = (self.params[parameter][0], vl)
			if to_print is True:
				await self.print('Parameter "%s" updated to "%s"' % (parameter, self.params[parameter][1]))
			
			msg = messages_pb2.ScannerParamsChangedEvt()
			msg.params.CopyFrom(serializeParamsDict({ parameter : self.params[parameter]}))
			await self.remotemsg(msg)

			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def remoteres(self, tid, msg, remote_clientid = None):
		try:
			wrapped = messages_pb2.ScannerResult()
			wrapped.targetId = tid
			wrapped.resType = msg.__class__.__name__
			wrapped.resData = msg.SerializeToString()
			await self.remotemsg(wrapped, remote_clientid)
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def add_target(self, val, source = 'SCANNER'):
		def get_vatype(val):
			try:
				int(val)
				return 'int'
			except:
				pass
			try:
				ipaddress.ip_address(val)
				return 'ip'
			except:
				pass
			return 'hostname'

		try:
			valtype = get_vatype(val)
			if valtype == 'int':
				return int(val), None
			elif valtype == 'ip':
				for tid in self.octopwnobj.targets:
					target = self.octopwnobj.targets[tid]
					if target.ip == val:
						return tid, None
				target = Target(val, source=source)
				tid, err = await self.octopwnobj.addtarget_obj(target, to_print=False)
				if err is not None:
					raise err
				return tid, None
			elif valtype == 'hostname':
				for tid in self.octopwnobj.targets:
					target = self.octopwnobj.targets[tid]
					if target.hostname == val:
						return tid, target
				target = Target(None, hostname = val, source=source)
				tid, err = await self.octopwnobj.addtarget_obj(target, to_print=False)
				if err is not None:
					raise err
				return tid, None

		except Exception as e:
			await self.print_exc(e)
			return None, e