import traceback
from octopwn.remote.protocol.python import messages_pb2
from google.protobuf.json_format import ParseDict
from octopwn.common.paramsutil import serializeParamsDict

class Dummy:
	def __init__(self):
		self.completer = None

class RemoteScreenHandler:
	def __init__(self, is_shared:bool = True):
		self.is_shared = is_shared
		self.input_area = Dummy()
		self.multi_window_support = False
		self.remoting_support = True
		self.dispatch_history = []
		self.remote_clients = {}

	async def dispatch_message(self, msg, remote_clientid = None):
		wrapped = messages_pb2.OctoMessage()
		wrapped.msgtype = msg.__class__.__name__
		wrapped.msgdata = msg.SerializeToString()
		if self.is_shared is True and remote_clientid is None:
			self.dispatch_history.append(wrapped.SerializeToString())
		
		if remote_clientid is None:
			for clientid in self.remote_clients:
				try:
					#print('Sending to %s' % clientid)
					await self.remote_clients[clientid].send(wrapped.SerializeToString())
				except Exception as e:
					# error happened while sending!
					traceback.print_exc()
		else:
			try:
				#print('Sending to %s' % remote_clientid)
				await self.remote_clients[remote_clientid].send(wrapped.SerializeToString())
			except Exception as e:
				# error happened while sending!
				traceback.print_exc()
		
	async def print_client_msg(self, clientid:int, msg:str):
		"""Called when a new message needs to be printed for a specific client window"""
		msgpacket = messages_pb2.ClientMessageEvt()
		msgpacket.clientId = clientid
		msgpacket.message = msg
		await self.dispatch_message(msgpacket)
		return True, None

	async def print_main_window(self, msg):
		msgpacket = messages_pb2.ClientMessageEvt()
		msgpacket.clientId = 0
		msgpacket.message = msg
		await self.dispatch_message(msgpacket)

	async def clear_main_window(self):
		#not needed here
		pass
	

	#### CLIENT CONTROLS #####
	async def client_added(self, cid, client):
		t = ParseDict(self.octopwn.clients[cid][0].to_dict(), messages_pb2.ClientConfig())
		msgpacket = messages_pb2.ClientAddedEvt()
		msgpacket.clientId = cid
		msgpacket.clientConfig.CopyFrom(t)
		await self.dispatch_message(msgpacket)
		return True, None

	async def refresh_clients(self):
		msg = messages_pb2.RefreshClients()
		await self.dispatch_message(msg)
	

	#### TARGET CONTROLS #####
	async def target_added(self, tid:int, target):
		t = ParseDict(target.to_dict(), messages_pb2.Target())
		for port in target.ports:
			t.ports.add(port)
		msg = messages_pb2.TargetAddedEvt()
		msg.targetId = tid
		msg.target.CopyFrom(t)
		await self.dispatch_message(msg)
		return None, None

	async def refresh_targets(self, force=False):
		msg = messages_pb2.RefreshTargets()
		await self.dispatch_message(msg)
		return None, None
	
	#### CREDENTIAL CONTROLS #####
	async def refresh_credentials(self):
		msg = messages_pb2.RefreshCreds()
		await self.dispatch_message(msg)
		return None, None
	
	async def credential_added(self, cid, credential):
		t = ParseDict(credential.to_dict(), messages_pb2.Credential())
		msg = messages_pb2.CredentialAddedEvt()
		msg.credentialId = cid
		msg.credential.CopyFrom(t)
		await self.dispatch_message(msg)
		return None, None
	
	#### PROXY(CHAIN) CONTROLS #####
	async def refresh_proxies(self):
		msg = messages_pb2.RefreshProxies()
		await self.dispatch_message(msg)
		return None, None
	
	async def proxy_added(self, pid, proxy):
		if proxy.ptype != 'CHAIN':
			tp = proxy.to_dict()
			t = ParseDict(tp, messages_pb2.Proxy())
			
			msg = messages_pb2.ProxyAddedEvt()
			msg.proxyId = pid
			msg.proxy.CopyFrom(t)
		else:
			t = messages_pb2.ProxyChain()	
			t.ptype = proxy.ptype
			t.description = proxy.description
			t.chain.extend(proxy.chain)

			msg = messages_pb2.ProxyChainAddedEvt()
			msg.proxyId = pid
			msg.chain.CopyFrom(t)

		await self.dispatch_message(msg)
		return None, None	

	#### ADDITIONAL STUFF #####
	async def set_input_dialog_title(self, clientid, title):
		return True
	
	def set_message_dialog_title(self, clientid:int, title:str):
		return True
	
	def abort(self, event = None):
		# this should never happen
		return
	
	async def create_client_window(self, clientid:int, cliname:str, client_settings, client):
		try:

			d = client_settings.to_dict()
			t = messages_pb2.ClientConfig()
			if 'config_type' in d:
				t.configType = d['config_type']
			if 'clientname' in d:
				t.clientname = d['clientname']
			if 'description' in d and d['description'] is not None:
				t.description = d['description']
			if 'connection_type' in d and d['connection_type'] is not None:
				t.connectionType = d['connection_type']
			if 'authentication_type' in d and d['authentication_type'] is not None:
				t.authenticationType = d['authentication_type']
			if 'target_id' in d and d['target_id'] is not None:
				t.targetId = d['target_id']
			if 'credential_id' in d and d['credential_id'] is not None:
				t.credentialId = d['credential_id']
			if 'proxy_id' in d and d['proxy_id'] is not None:
				t.proxyId = d['proxy_id']
			if 'scanner_type' in d and d['scanner_type'] is not None:
				t.scannerType = d['scanner_type']
			if 'client_type' in d and d['client_type'] is not None:
				t.clientType = d['client_type']
			for command in client.command_list():
				t.commands.append(str(command))
			
			if hasattr(client, 'params'):
				t.params.CopyFrom(serializeParamsDict(client.params))

					
			msgpacket = messages_pb2.ClientWindowCreatedEvt()
			msgpacket.clientId = clientid
			msgpacket.clientName = cliname
			msgpacket.clientConfig.CopyFrom(t)
			await self.dispatch_message(msgpacket)
		except Exception as e:
			traceback.print_exc()

		return True, None

	async def run(self, octopwn, input_handler):
		return True, None