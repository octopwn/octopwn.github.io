from typing import Dict, List, Tuple
from octopwn.remote.protocol.python import messages_pb2
import asyncio
from asn1crypto.x509 import Certificate
from octopwn.remote.server.authentication import AuthHandler, UserAuthError


class AuthHandlerFile(AuthHandler):
	def __init__(self, credfile, authmethods = ['PLAIN', 'CERT']):
		AuthHandler.__init__(self, authmethods)
		self.credfile = credfile
		self.credentials = {}

		with open(credfile, 'r') as f:
			for line in f:
				line = line.strip()
				if line == '':
					continue
				if line.find(':') != -1:
					username, password = line.split(':')
				else:
					username = line
					password = None #CERT auth only
				self.credentials[username] = password
	
	def authenticate(self, msg:messages_pb2.RegisterClient, connection:asyncio.StreamWriter) -> Tuple[str, bool, Exception]:
		try:
			raddr = ':'.join([str(x) for x in connection.get_extra_info('peername')])
			username = msg.username
			if msg.regtype.upper() == 'NONE':
				return username, False, None

			elif msg.regtype.upper() == 'PLAIN':
				if msg.password is None:
					raise UserAuthError(raddr, 'Client using PLAIN auth did not send a password')
				if username not in self.credentials:
					raise UserAuthError(raddr, 'Bad username or password')
				if self.credentials[username] == msg.password:
					return username, False, None
				else:
					raise UserAuthError(raddr, 'Bad username or password')

			elif msg.regtype.upper() == 'CERT':
				# TLS client certificate auth
				#cli_sslobj = ws.transport.get_extra_info('ssl_object', default=None)
				cli_sslobj = connection.get_extra_info('ssl_object', default=None)
				if cli_sslobj is None:
					raise UserAuthError(raddr, 'Client tried to use CERT auth but this connection is not over SSL')
						
						
				validated_cert = None
				try:
					validated_cert = cli_sslobj.getpeercert()
				except:
					raise UserAuthError(raddr, 'User certificate validation error')
				if validated_cert is None:
					raise UserAuthError(raddr, 'User certificate is empty. Validation/session error!')
						
				validated_cert_raw = cli_sslobj.getpeercert(True)
				cli_cert = Certificate.load(validated_cert_raw)
				username = cli_cert.native['tbs_certificate']['subject']['common_name']
				if username in self.credentials:
					return username, False, None
				else:
					raise UserAuthError(raddr, 'Client SSL cert verified but user is not in the DB. Username: %s' % username)
		except Exception as e:
			return None, False, e
