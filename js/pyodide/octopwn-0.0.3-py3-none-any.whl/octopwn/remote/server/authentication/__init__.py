from typing import Dict, List, Tuple
import asyncio
from octopwn.remote.protocol.python import messages_pb2


class UserAuthError(Exception):
	def __init__(self, raddr, msg):
		super().__init__(msg)

		self.raddr = raddr


class AuthHandler:
	def __init__(self, authmethods):
		self.authmethods = authmethods

	def get_supported_types(self) -> List[str]:
		return self.authmethods

	def authenticate(self, msg:messages_pb2.RegisterClient, connection:asyncio.StreamWriter) -> Tuple[str, bool, Exception]:
		# username, to_continue, error
		raise NotImplementedError()