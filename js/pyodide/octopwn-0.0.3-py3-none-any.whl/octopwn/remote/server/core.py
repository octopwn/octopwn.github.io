import os
import ssl
import asyncio
import sys
import traceback
import datetime
from typing import Dict, List, Tuple
import uuid
from octopwn.common.credential import Credential
from octopwn.common.target import Target

from octopwn.core import OctoPwn
from octopwn.remote.protocol.python import messages_pb2
from octopwn.remote.server import logger
from octopwn.remote.server.screenhandler import RemoteScreenHandler
from octopwn.remote.server.authentication import AuthHandler, UserAuthError

import websockets

class RemoteClientHandler:
	def __init__(self, client_id:int, ws:websockets, octopwn):
		self.client_id = client_id
		self.ws = ws
		self.octopwn = octopwn

	async def cleanup(self):
		pass


class RemoteServer:
	def __init__(self, listen_ip:str = '127.0.0.1', listen_port:int = 8181, listen_sslctx:ssl.SSLContext = None, is_shared:bool=True, workdir:str = './', authhandler:AuthHandler = None):
		self.listen_ip = listen_ip
		self.listen_port = listen_port
		self.listen_sslctx = listen_sslctx
		self.is_shared = is_shared
		self.workdir = workdir
		self.clients:Dict[int, RemoteClientHandler] = {}
		self.__shared_octopwn = None
		self.__periodic_save_task = None
		self.history_save_time = 1
		self.history_save_location = os.path.join(self.workdir, 'history.raw')
		self.__incoming_buff = []

		self.authentication_handler:AuthHandler = authhandler
		
	
	def get_clientid(self):
		return uuid.uuid4()

	async def __periodic_save(self):
		try:
			while True:
				await asyncio.sleep(self.history_save_time * 60)
				if self.__shared_octopwn is None:
					continue
				batch = messages_pb2.OctoHistoryBatch()
				for msg in self.__shared_octopwn.screen_handler.dispatch_history:
					batch.messages.append(msg)
				for msg in self.__incoming_buff:
					batch.messages.append(msg)
				with open(self.history_save_location, 'wb') as f:
					f.write(batch.SerializeToString())
				logger.debug('History saved!')
				self.__incoming_buff = []
		except Exception as e:
			traceback.print_exc()

	async def __client_registration(self, ws:websockets.WebSocketCommonProtocol):
		try:
			raddr = ':'.join([str(x) for x in ws.transport.get_extra_info('peername')])
			clientid = self.get_clientid()
			logger.info('[%s][AUTHINFO] Waiting for client auth' % raddr)
			async for message in ws:
				msg = messages_pb2.OctoMessage()
				msg.ParseFromString(message)
				if msg.msgtype == 'RegisterClient':
					t = messages_pb2.RegisterClient()
					t.ParseFromString(msg.msgdata)
					logger.info('[%s][AUTHPROGRESS][%s][%s][%s]' % (raddr, msg.msgtype, t.regtype, t.username))
					if t.regtype is None:
						raise UserAuthError(raddr, 'Registration with missing regtype')
					if self.authentication_handler is None:
						logger.warning('[%s][AUTHINFO] Letting another user in without authentication because you did not set an authentication handler...' % raddr)
						return clientid, str(clientid), t.regtype, None
					
					if t.regtype.upper() not in self.authentication_handler.get_supported_types():
						raise UserAuthError(raddr, 'Client tried "%s" regtype but it\'s not supported by the server' % t.regtype.upper())
					
					username, to_continue, err = self.authentication_handler.authenticate(t, ws.transport)
					if err is not None:
						raise err
					if to_continue is True:
						#sending continue to client, bc we need more auth steps
						msg = messages_pb2.OctoClientReplyContinue()
						wrapped = messages_pb2.OctoMessage()
						wrapped.msgtype = msg.__class__.__name__
						wrapped.msgdata = msg.SerializeToString()
						await ws.send(wrapped.SerializeToString())
						continue
					if username is None:
						username = str(clientid)
					return clientid, username, t.regtype, None

				else:
					raise UserAuthError(raddr, 'Client did not try to register!')

			raise UserAuthError(raddr, 'Client terminated the connection before registering!')

		except Exception as e:
			return None, None, None, e

	async def __client_registration_ack(self, ws, username, authmethod):
		try:
			msg = messages_pb2.RegisterClient()
			msg.regtype = str(authmethod)
			msg.username = str(username)
			wrapped = messages_pb2.OctoMessage()
			wrapped.msgtype = msg.__class__.__name__
			wrapped.msgdata = msg.SerializeToString()
			await ws.send(wrapped.SerializeToString())

		except Exception as e:
			return None, None, e
		
	
	async def __client_handler(self, ws, path):
		client = None
		clientid = None
		username = None
		raddr = ':'.join([str(x) for x in ws.transport.get_extra_info('peername')])
		logger.info('[%s][CONNECTION] Connected' % raddr)
		try:
			try:
				clientid, username, authmethod, err = await asyncio.wait_for(self.__client_registration(ws), timeout=10) #we wait for 10s to auth to finish
			except asyncio.TimeoutError:
				raise UserAuthError('Authentication timeout')
			except Exception as e:
				raise UserAuthError('Unknown auth error! %s' % e)

			if err is not None:
				raise err
			
			await self.__client_registration_ack(ws, username, authmethod)
			logger.info('[%s][AUTHOK][%s][%s] Authentication OK!' % (raddr, clientid, username))
			if self.is_shared is True:
				if self.__shared_octopwn is None:
					sch = RemoteScreenHandler()
					self.__shared_octopwn = OctoPwn(sch, work_dir = self.workdir)
					_, err = await self.__shared_octopwn.run()
					if err is not None:
						raise err
					await self.__shared_octopwn.do_createutil('CHAT', 'CHAT', h_forcelocal=True)

				for msg in self.__shared_octopwn.screen_handler.dispatch_history:
					# TODO: add batching
					await ws.send(msg.message.SerializeToString())
				
				msg = messages_pb2.ConnectionSynchronizedEvt()
				wrapped = messages_pb2.OctoMessage()
				wrapped.msgtype = msg.__class__.__name__
				wrapped.msgdata = msg.SerializeToString()
				
				await ws.send(wrapped.SerializeToString())
				
				self.__shared_octopwn.screen_handler.remote_clients[clientid] = ws
				client = RemoteClientHandler(clientid, ws, self.__shared_octopwn)
			else:
				raise NotImplementedError()
			
			async for message in ws:
				msg = messages_pb2.OctoMessage()
				msg.ParseFromString(message)
				#print(msg)
				history = messages_pb2.OctoHistory()
				history.tstamp.FromDatetime(datetime.datetime.utcnow())
				history.direction = False
				history.clientid = str(clientid)
				history.username = str(username)
				history.message.CopyFrom(msg)
				self.__incoming_buff.append(history)

				if msg.msgtype == 'RunCommand':
					t = messages_pb2.RunCommand()
					t.ParseFromString(msg.msgdata)
					try:
						logger.info('[%s][RunCommand][%s][%s][%s] "%s"' % (raddr, clientid, username, t.clientId, t.command))
						self.__shared_octopwn.input_handler(t.command, t.clientId, username=username)
					except Exception as e:
						traceback.print_exc()
				elif msg.msgtype == 'OctoClientMessage':
					t = messages_pb2.OctoClientMessage()
					t.ParseFromString(msg.msgdata)
					try:
						##### LOGGING STUFF
						if t.cmdtype not in ['RDPMouse', 'RDPKeyboardUnicode']:
							if t.cmdtype == 'OctoClientCommandGeneric':
								lt = messages_pb2.OctoClientCommandGeneric()
								lt.ParseFromString(t.cmddata)
								logger.info('[%s][%s][%s][%s][%s][%s][%s][START][%s]' % (raddr, t.cmdtype, clientid, username, t.clientId, lt.command, lt.token, '|'.join(lt.params)))
							else:
								logger.info('[%s][OctoClientMessage][%s][%s][%s] %s' % (raddr, clientid, username, t.clientId, t.cmdtype))
						##### EXECUTING STUFF
						await self.__shared_octopwn.remote_inputhandler(raddr, clientid, t.clientId, t, username=username)
					except Exception as e:
						traceback.print_exc()

				elif msg.msgtype == 'CredentialAddedEvt':
					try:
						logger.info('[%s][%s][%s][%s][%s]' % (raddr, 'CredentialAddedEvt', clientid, username, '0'))
						t = messages_pb2.CredentialAddedEvt()
						t.ParseFromString(msg.msgdata)
						credential = Credential.from_proto(t.credential)
						_, err = await self.__shared_octopwn.addcredential_obj(credential)
						if err is not None:
							raise err
						
					except Exception as e:
						traceback.print_exc()

				
				elif msg.msgtype == 'TargetAddedEvt':
					try:
						t = messages_pb2.TargetAddedEvt()
						t.ParseFromString(msg.msgdata)
						target = Target.from_proto(msg.target)
						_, err = await self.__shared_octopwn.addtarget_obj(target)
						if err is not None:
							raise err
					except Exception as e:
						traceback.print_exc()
	

		except UserAuthError as e:
			logger.info('[%s][AUTHFAIL] %s' % (raddr, e))
		except Exception as e:
			logger.info('[%s][CRITICAL] %s' % (raddr, e))
			traceback.print_exc()
		finally:
			logger.info('[%s][CONNECTION][%s] Disconnected' % (raddr, username))
			if client is not None:
				await client.cleanup()
				if client.client_id in self.clients:
					del self.clients[client.client_id]
				if self.is_shared is True:
					try:
						del self.__shared_octopwn.screen_handler.remote_clients[clientid]
					except:
						pass
	
	async def load_previous_state(self):
		if self.is_shared is False:
			return True, None
		if self.__shared_octopwn is not None:
			return True, None
		
		try:
			sch = RemoteScreenHandler()
			batch = None
			if os.path.exists(self.history_save_location) is True:
				with open(self.history_save_location, 'rb') as f:
					batch = messages_pb2.OctoHistoryBatch()
			if batch is not None:
				for msg in batch.messages:
					sch.dispatch_history.append(msg)
			
			sessionfile = os.path.join(self.workdir, 'octopwn.session')
			if os.path.exists(sessionfile) is False:
				sessionfile = os.path.join(self.workdir, 'octopwn.session.temp')
			if os.path.exists(sessionfile) is True:
				self.__shared_octopwn = OctoPwn.load(sessionfile, sch, work_dir = self.workdir, periodic_save=True)
				_, err = await self.__shared_octopwn.run()
				if err is not None:
					raise err
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def run(self):
		if self.authentication_handler is None or 'NONE' in self.authentication_handler.get_supported_types():
			print('WARNING!WARNING!WARNING!WARNING!WARNING!WARNING!')
			print('WARNING!WARNING!WARNING!WARNING!WARNING!WARNING!')
			print('This server is accepting "NONE" registration type!')
			print('Your server is open to anyone who has network access!! This should only be used for debug purposes.')
			print('')
		if self.authentication_handler is not None and 'CERT' in self.authentication_handler.get_supported_types() and self.listen_sslctx is None:
			print('WARNING! CERT regtype is supported but the server is not using SSL/TLS!')
			print('')

		# TODO: Implement this!
		#_, err = await self.load_previous_state()
		#if err is not None:
		#	print('Restoring previous session failed!')
		#	return

		async with websockets.serve(self.__client_handler, self.listen_ip, self.listen_port, ssl=self.listen_sslctx):
			print('OctoPwn server listening on ws%s://%s:%s/' % ('' if self.listen_sslctx is None else 's' ,self.listen_ip, self.listen_port))
			print('Press CTRL+C to exit')
			self.__periodic_save_task = asyncio.create_task(self.__periodic_save())
			await asyncio.Future()