import ssl
import asyncio
import traceback
from typing import Dict
import uuid

from octopwn.core import OctoPwn
from octopwn.remote.protocol.python import messages_pb2
from octopwn.remote.server.screenhandler import RemoteScreenHandler

import websockets



class RemoteClientHandler:
	def __init__(self, client_id:int, ws:websockets, octopwn):
		self.client_id = client_id
		self.ws = ws
		self.octopwn = octopwn

	async def cleanup(self):
		pass

	#async def handle_message(self, msg):


class RemoteServer:
	def __init__(self, listen_ip:str = '127.0.0.1', listen_port:int = 8181, listen_sslctx:ssl.SSLContext = None, is_shared:bool=True, workdir:str = None):
		self.listen_ip = listen_ip
		self.listen_port = listen_port
		self.listen_sslctx = listen_sslctx
		self.is_shared = is_shared
		self.workdir = workdir
		self.clients:Dict[int, RemoteClientHandler] = {}
		self.__shared_octopwn = None
	
	def get_clientid(self):
		return uuid.uuid4()
	
	async def __client_handler(self, ws, path):
		client = None
		clientid = None
		try:
			clientid = self.get_clientid()
			
			if self.is_shared is True:
				if self.__shared_octopwn is None:
					sch = RemoteScreenHandler()
					self.__shared_octopwn = OctoPwn(sch, work_dir = self.workdir)
					_, err = await self.__shared_octopwn.run()
					if err is not None:
						raise err
					await self.__shared_octopwn.do_createutil('CHAT', 'CHAT', h_forcelocal=True)

				for msg in self.__shared_octopwn.screen_handler.dispatch_history:
					# TODO: add batching
					await ws.send(msg)
				
				msg = messages_pb2.ConnectionSynchronizedEvt()
				wrapped = messages_pb2.OctoMessage()
				wrapped.msgtype = msg.__class__.__name__
				wrapped.msgdata = msg.SerializeToString()
				
				await ws.send(wrapped.SerializeToString())
				
				self.__shared_octopwn.screen_handler.remote_clients[clientid] = ws
				client = RemoteClientHandler(clientid, ws, self.__shared_octopwn)
			else:
				raise NotImplementedError()
			
			async for message in ws:
				msg = messages_pb2.OctoMessage()
				msg.ParseFromString(message)
				print(msg)
				if msg.msgtype == 'RunCommand':
					t = messages_pb2.RunCommand()
					t.ParseFromString(msg.msgdata)
					try:
						print('RunCommand: id: %s command: "%s"' % (t.clientId, t.command))
						self.__shared_octopwn.input_handler(t.command, t.clientId)
					except Exception as e:
						traceback.print_exc()
				elif msg.msgtype == 'OctoClientMessage':
					t = messages_pb2.OctoClientMessage()
					t.ParseFromString(msg.msgdata)
					try:
						print('OctoClientMessage: id: %s Message: "%s"' % (t.clientId, t))
						await self.__shared_octopwn.remote_inputhandler(clientid, t.clientId, t)
					except Exception as e:
						traceback.print_exc()

		except Exception as e:
			traceback.print_exc()
		finally:
			if client is not None:
				await client.cleanup()
				if client.client_id in self.clients:
					del self.clients[client.client_id]
				if self.is_shared is True:
					try:
						del self.__shared_octopwn.screen_handler.remote_clients[clientid]
					except:
						pass

	async def run(self):
		async with websockets.serve(self.__client_handler, self.listen_ip, self.listen_port, ssl=self.listen_sslctx):
			print('OctoPwn server listening on ws%s://%s:%s/' % ('' if self.listen_sslctx is None else 's' ,self.listen_ip, self.listen_port))
			print('Press CTRL+C to exit')
			await asyncio.Future()