import sys
import multiprocessing
import asyncio
import traceback
from octopwn.remote.server.authentication.fileauth import AuthHandlerFile
from octopwn.remote.server.core import RemoteServer

async def amain(listen_ip, listen_port, ssl_ctx, workdir = None, authfile=None):
	try:
		auth = None
		if authfile is not None:
			auth = AuthHandlerFile(authfile)
		rs = RemoteServer(listen_ip=listen_ip, listen_port=listen_port, listen_sslctx=ssl_ctx, workdir = workdir, authhandler = auth)
		await rs.run()
	except Exception as e:
		print('Failed to start server!')
		traceback.print_exc()

def main():
	if sys.platform.startswith('win'):
		# On Windows calling this function is necessary.
		multiprocessing.freeze_support()
	import argparse
	import logging
	from octopwn.remote import argparse_ssl, args_to_sslctx
	
	parser = argparse.ArgumentParser(description='Octopwn Server')
	parser.add_argument('-l', '--listen-ip', default='127.0.0.1', help='IP address to listen on')
	parser.add_argument('-p', '--listen-port', type=int, default=8181, help='Port to listen on')
	parser.add_argument('-w', '--work-dir', default='./', help='Work directory')
	parser.add_argument('-a', '--authfile', help='Credential database file for authentication. one user per line, format: "username:password"')
	argparse_ssl(parser)
	args = parser.parse_args()

	ssl_ctx = args_to_sslctx(args)
	asyncio.run(amain(args.listen_ip, args.listen_port, ssl_ctx, args.work_dir, authfile=args.authfile))

if __name__ == '__main__':
	main()