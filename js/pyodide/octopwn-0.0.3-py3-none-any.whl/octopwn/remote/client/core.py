import logging
import ssl
import asyncio
import traceback
from typing import Dict, List, Tuple
from google.protobuf.json_format import MessageToDict

import websockets
from octopwn.remote import client
from octopwn.remote.client import logger
from octopwn.remote.protocol.python import messages_pb2, smb_pb2
from octopwn._version import __banner__
from octopwn.common.target import Target
from octopwn.common.proxy import Proxy
from octopwn.common.credential import Credential
from octopwn.common.clientconfig import ClientConfig, ScannerConfig, UtilsConfig, ServerConfig, ClientConfigBase
from octopwn.remote.client.clients.base import ClientConsoleBaseRemote
from octopwn.remote.client.clients.smb import SMBClientConsoleRemote
from octopwn.remote.client.clients.ldap import LDAPClientConsoleRemote
from octopwn.remote.client.clients.rdp import  RDPClientConsoleRemote


class OctoPwnRemoteClient(ClientConsoleBaseRemote):
	def __init__(self, url:str, sslctx:ssl.SSLContext, screen_handler):
		ClientConsoleBaseRemote.__init__(self, None, 0)
		self.url = url
		self.sslctx = sslctx
		self.clients:Dict[int, Tuple[ClientConfigBase, ClientConsoleBaseRemote]] = {}
		self.targets = {}
		self.credentials = {}
		self.proxies = {}
		self.cmd_dispatch_table = {}
		self.screen_handler = screen_handler
		self.screen_handler_app = None
		self.__current_client_id = 0
		self.client_messages:Dict[int, List[str]] = {}
		self.ws = None
		self.remote_files = []
		
		# this is for main
		#self.clients[0] = (ClientConfigBase('DUNNO', 'MAIN', None, description='MAIN'), ClientConsoleBaseRemote())
		self.client_messages[0] = []
		self.channels = {}
	
	async def print_exc(self, err:Exception, with_tb = True, extra_msg = ''):
		if with_tb is False:
			await self.print('Error: %s Exception: %s' % (extra_msg, err))
			return
		
		await self.print('Error: %s Exception: %s' % (extra_msg, err))
		for lines in traceback.format_tb(err.__traceback__):
			for line in lines.split('\n'):
				await self.print('Traceback: %s' % line)

	async def handle_remote_out(self, clientid, msg):
		try:
			if clientid is None:
				clientid = 0
			clientid = int(clientid)
			if clientid == 0:
				if msg.command.startswith('s ') is True:
					await self.do_switchclient(msg.command[2:])
					return
				elif msg.command.startswith('switchclient') is True:
					await self.do_switchclient(msg.command[len('switchclient '):])
					return
				elif msg.command.startswith('exit') is True or msg.command.startswith('!exit'):
					if self.ws is not None:
						await self.ws.close()
					await self.screen_handler.abort(None)
					return

			await self.send_message(msg)


		except Exception as e:
			traceback.print_exc()

	async def print(self, msgdata, client_id = 0):
		try:
			msgdata = str(msgdata)
			for msg in msgdata.split('\n'):
				if client_id not in self.client_messages:
					await self.screen_handler.print_main_window('ClientID %s not recognized as a valid client!' % repr(client_id))
					return
				self.client_messages[client_id].append(msg)
				if self.screen_handler.multi_window_support is False and client_id == self.__current_client_id:
					await self.screen_handler.print_main_window(msg)
				else:
					_, err = await self.screen_handler.print_client_msg(client_id, msg)
					if err is not None:
						raise err
		except Exception as e:
			traceback.print_exc()
			await self.screen_handler.print_main_window('Failed to parse client message. Reason: %s' % e)

	async def do_switchclient(self, client_id:int):
		"""Changes the current clinet INPUT and OUTPUT window to another one"""
		try:
			if self.screen_handler.multi_window_support is True:
				await self.print('SwitchClient is not supported on multi-window supporting screens.')
				return
			
			client_id = int(client_id)
			if client_id not in self.clients:
				await self.print('Unknown client!')
				return
			await self.print('Switching to client %s' % client_id)
			if client_id == 0:
				# main menu
				self.__current_client_id = 0
				self.__current_client_settings = None
				self.__current_client = None
				await self.screen_handler.clear_main_window()
				#self.screen_handler.input_area.completer = self.make_completer()
				msg = '\n'.join(self.client_messages[self.__current_client_id])
				await self.print(msg, self.__current_client_id)
				await self.screen_handler.set_input_dialog_title(0, 'PROMPT')
				await self.screen_handler.set_message_dialog_title(self.__current_client_id, 'MAIN')
			else:
				self.__current_client_settings, self.__current_client = self.clients[client_id]
				self.__current_client_id = client_id
				self.screen_handler.input_area.completer = self.__current_client_settings.completer
				await self.screen_handler.clear_main_window()
				msg = '\n'.join(self.client_messages[self.__current_client_id])
				await self.print(msg, self.__current_client_id)
				await self.screen_handler.set_input_dialog_title(self.__current_client_id, self.__current_client.prompt)
				await self.screen_handler.set_message_dialog_title(self.__current_client_id, self.__current_client_settings.clientname)
		except Exception as e:
			await self.print_exc(e, extra_msg='Failed to switch to client %s' % client_id)

	async def test(self):
		try:
			clientid = 1
			cmd = messages_pb2.OctoClientCommandGeneric()
			cmd.token = 1
			cmd.command = 'userenum'
			#cmd.params.append('smb')
			#cmd.params.append('ntlm')
			#cmd.params.append('0')
			#cmd.params.append('0')

			#cmd.command = "login"
			#cmd.params.append('smb')
			#cmd.params.append('ntlm')
			#cmd.params.append('0')
			#cmd.params.append('0')

			await self.send_generic(clientid, cmd)
		except Exception as e:
			traceback.print_exc()
	
	async def do_addtarget(self, ip:str, port:int = None, dcip:str = None, realm:str = None, hostname:str=None, to_print:bool=True):
		params = []
		params.append(ip)
		params.append(port)
		params.append(dcip)
		params.append(realm)
		params.append(hostname)

		await self.send_genericcommand(0, 'addtarget', params)

	async def do_addcred(self, username_with_domain, secret, secrettype, certfile, keyfile):
		params = []
		params.append(str(username_with_domain))
		params.append(str(secret))
		params.append(str(secrettype))
		params.append(str(certfile))
		params.append(str(keyfile))

		await self.send_genericcommand(0, 'addcred', params)

	async def do_addproxy(self, ptype, ip, port, agentid):
		params = []
		params.append(str(ptype))
		params.append(str(ip))
		params.append(str(port))
		params.append(str(agentid))
		await self.send_genericcommand(0, 'addproxy', params)

	async def do_createclient(self, ctype, cauth, cid, tid, pid):
		params = []
		params.append(str(ctype))
		params.append(str(cauth))
		params.append(str(cid))
		params.append(str(tid))
		params.append(str(pid))
		await self.send_genericcommand(0, 'createclient', params)

	async def do_createscanner(self, stype):
		params = []
		params.append(str(stype))
		await self.send_genericcommand(0, 'createscanner', params)

	async def do_createserver(self, stype):
		params = []
		params.append(str(stype))
		await self.send_genericcommand(0, 'createserver', params)

	async def do_createutil(self, stype):
		params = []
		params.append(str(stype))
		await self.send_genericcommand(0, 'createutil', params)
	
	async def do_changedescription(self, otype, oid, description):
		params = []
		params.append(str(otype))
		params.append(str(oid))
		params.append(str(description))
		await self.send_genericcommand(0, 'changedescription', params)

	def command_list(self):
		#availableCommandsProxy = 
		return []
	
	async def do_createchain(self):
		#resproxy = await 
		raise NotImplementedError()

	async def do_addproxychain(self, cid, pid):
		#addresproxy = await app.
		raise NotImplementedError()

	async def process_message_internal(self, msg):
		#TODO: this
		pass
	
	def input_handler(self, in_buffer, clientid = None):
		try:
			if isinstance(in_buffer, str):
				cmd = in_buffer
			else:
				cmd = in_buffer.text
			if cmd == '':
				return False
			
			### TEST!!!!
			#x = asyncio.create_task(self.test())
			#return
			###

			if clientid is not None:
				if cmd[0] == '!' or clientid == 0:
					if cmd[0] == '!':
						cmd = cmd[1:]
					if len(cmd) < 1:
						return False
					
					return False
				
				
				#self.clients[clientid][1].cmd_q.put_nowait(cmd)
				cmdwrapped = messages_pb2.RunCommand()
				cmdwrapped.clientId = clientid
				cmdwrapped.command = cmd

				x = asyncio.create_task(self.handle_remote_out(clientid, cmdwrapped))
				return False

			else:
				if cmd[0] == '!' or self.__current_client_id == 0:
					if cmd[0] == '!':
						cmd = cmd[1:]
					if len(cmd) < 1:
						return False
					
					cmdwrapped = messages_pb2.RunCommand()
					cmdwrapped.clientId = 0
					cmdwrapped.command = cmd
					x = asyncio.create_task(self.handle_remote_out(0, cmdwrapped))
					
					return False
				elif self.__current_client is not None:
					if cmd.startswith('login') is True:
						client = self.clients[self.__current_client_id][1]
						if hasattr(client, 'do_login') is True:
							x = asyncio.create_task(client.do_login(cmd[len('login'):]))
							return False
					cmdwrapped = messages_pb2.RunCommand()
					cmdwrapped.clientId = self.__current_client_id
					cmdwrapped.command = cmd
					x = asyncio.create_task(self.handle_remote_out(self.__current_client_id, cmdwrapped))
				else:
					self.print_sync('Unknown command %s' % cmd)


			return False #false signals that the text area should be cleared
		except Exception as e:
			traceback.print_exc()

	async def process_incoming_message(self, msg):
		try:
			if logger.level == logging.DEBUG:
				await self.print(str(msg))
			if msg.msgtype == 'Refresh':
				await self.screen_handler.refresh_targets()
				await self.screen_handler.refresh_credentials()
				await self.screen_handler.refresh_proxies()
				await self.screen_handler.refresh_clients()
			elif msg.msgtype == 'RefreshCreds':
				await self.screen_handler.refresh_credentials()
			elif msg.msgtype == 'RefreshTargets':
				await self.screen_handler.refresh_targets()
			elif msg.msgtype == 'RefreshProxies':
				await self.screen_handler.refresh_proxies()
			elif msg.msgtype == 'RefreshClients':
				await self.screen_handler.refresh_clients()
			elif msg.msgtype == 'ClearMainWindow':
				await self.screen_handler.clear_main_window()
			elif msg.msgtype == 'ProxyAddedEvt':
				t = messages_pb2.ProxyAddedEvt()
				t.ParseFromString(msg.msgdata)
				proxy = Proxy.from_dict(MessageToDict(t)['proxy'])
				self.proxies[t.proxyId] = proxy
				await self.screen_handler.proxy_added(t.proxyId, proxy)
				await self.screen_handler.refresh_proxies()
			elif msg.msgtype == 'TargetAddedEvt':
				t = messages_pb2.TargetAddedEvt()
				t.ParseFromString(msg.msgdata)
				target = Target.from_dict(MessageToDict(t)['target'])
				self.targets[t.targetId] = target
				await self.screen_handler.target_added(t.targetId, target)
				await self.screen_handler.refresh_targets()
			elif msg.msgtype == 'CredentialAddedEvt':
				t = messages_pb2.CredentialAddedEvt()
				t.ParseFromString(msg.msgdata)
				cred = Credential.from_dict(MessageToDict(t)['credential'])
				self.credentials[t.credentialId] = cred
				await self.screen_handler.credential_added(t.credentialId, cred)
				await self.screen_handler.refresh_credentials()
			elif msg.msgtype == 'ClientWindowCreatedEvt':
				t = messages_pb2.ClientWindowCreatedEvt()
				t.ParseFromString(msg.msgdata)
				cdt = MessageToDict(t.clientConfig)
				if logger.level == logging.DEBUG:
					await self.print(t.clientConfig)
				cd = {
					'config_type' : t.clientConfig.configType,
					'clientname' : t.clientConfig.clientname,
					'description' : t.clientConfig.description,
					'connection_type' : t.clientConfig.connectionType,
					'authentication_type' : t.clientConfig.authenticationType,
					'target_id' : t.clientConfig.targetId,
					'credential_id' : t.clientConfig.credentialId,
					'proxy_id' : t.clientConfig.proxyId,
					'scanner_type' : t.clientConfig.scannerType,
					'commands' : [],
				}

				for command in t.clientConfig.commands:
					cd['commands'].append(command)
				
				client = ClientConsoleBaseRemote(self, t.clientId, cd.get('commands'))
				if t.clientConfig.configType == 'NORMAL':
					cbase = ClientConfig.from_dict(cd)
					if t.clientConfig.clientType == 'SMB':
						client = SMBClientConsoleRemote(self, t.clientId, cd.get('commands'))
					elif t.clientConfig.clientType == 'LDAP':
						client = LDAPClientConsoleRemote(self, t.clientId, cd.get('commands'))
					elif t.clientConfig.clientType == 'RDP':
						client = RDPClientConsoleRemote(self, t.clientId, cd.get('commands'))
				elif t.clientConfig.configType == 'SCANNER':
					cbase = ScannerConfig.from_dict(cd)
				
				elif t.clientConfig.configType == 'UTILS':
					cbase = UtilsConfig.from_dict(cd)
				elif t.clientConfig.configType == 'SERVER':
					await self.print('Server sessions are not yet implemented!')
					return
					#cbase = ServerConfig.from_dict(MessageToDict(t)['clientConfig'])
				
				else:
					await self.print('Unknown clientconfig type %s' % t.clientConfig.configType)
					return
				cbase.clientname = t.clientConfig.clientname # ???? check this later!				
				
				self.clients[t.clientId] = (cbase, client)
				self.client_messages[t.clientId] = []
				await self.screen_handler.create_client_window(t.clientId, None, self.clients[t.clientId][0], self.clients[t.clientId][1])
				await self.screen_handler.refresh_clients()
			elif msg.msgtype == 'ClientMessageEvt':
				res = messages_pb2.ClientMessageEvt()
				res.ParseFromString(msg.msgdata)
				await self.print(res.message, res.clientId)
			elif msg.msgtype == 'OctoClientMessage':
				res = messages_pb2.OctoClientMessage()
				res.ParseFromString(msg.msgdata)
				if res.clientId == 0:
					x = asyncio.create_task(self.process_message_internal(res))
					return
				client = self.clients.get(res.clientId, None)
				if client is None:
					print('ClientMessage from unknown client ID: %s' % res.clientId)
					return
				client = client[1]
				x = asyncio.create_task(client.process_message(res))
		except Exception as e:
			traceback.print_exc()

	async def run(self):
		try:
			print('Connecting to %s ...' % self.url)
			async with websockets.connect(self.url, ssl=self.sslctx) as self.ws:
				self.screen_handler_app, err = await self.screen_handler.run(self, self.input_handler)
				if err is not None:
					raise err
				
				await self.do_createscanner('smbfile')
				async for data in self.ws:
					msg = messages_pb2.OctoMessage()
					msg.ParseFromString(data)
					await self.process_incoming_message(msg)

		except OSError as e:
			print('Connection to server failed! Reason: %s' % e)
		except Exception as e:
			traceback.print_exc()

	async def run_generic(self, comms):
		try:
			self.ws = comms
			self.screen_handler_app, err = await self.screen_handler.run(self, self.input_handler)
			if err is not None:
				raise err
				
			while True:
				data = await comms.recv()
				msg = messages_pb2.OctoMessage()
				msg.ParseFromString(data)
				print(msg)
				await self.process_incoming_message(msg)

		except Exception as e:
			traceback.print_exc()