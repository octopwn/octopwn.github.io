import shlex
import inspect
import asyncio
import traceback
from typing import List
from google.protobuf.json_format import MessageToDict

from octopwn.remote import client
from octopwn.remote.client import logger
from octopwn.remote.protocol.python import messages_pb2
from octopwn._version import __banner__
from octopwn.common.clientconfig import ClientConfig, ScannerConfig, UtilsConfig, ServerConfig, ClientConfigBase


class ClientConsoleBaseRemote:
	def __init__(self, octopwnobj, clientid, commands = [], command_modifier = None):
		self.aliases = {}
		self.ATTR_START = 'do_'
		self.prompt = '>>> '
		self.octopwnobj = octopwnobj
		self.clientid = clientid
		self.commans = commands
		self.tokenctr = 1
		self.__results = {}
		self.command_modifier = command_modifier
	
	def get_token(self):
		x = self.tokenctr
		self.tokenctr += 1
		return x

	async def print_exc(self, err:Exception, with_tb = True, extra_msg = ''):
		await self.octopwnobj.print_exc(err, with_tb = with_tb, extra_msg = extra_msg)
	
	async def print(self, msgdata, client_id = 0):
		await self.octopwnobj.print(msgdata, client_id = client_id)

	def command_list(self):
		if self.commans is None:
			return []
		return self.commans

	async def handle_remote_out(self, localclientid, msg):
		try:
			await self.send_message(msg)
		except Exception as e:
			traceback.print_exc()
	
	def _get_command(self, command):
		if command in self.aliases:
			command = self.aliases[command]
		return getattr(self, self.ATTR_START + command)

	def _get_command_args(self, command):
		args = [param for param in inspect.signature(self._get_command(command)).parameters.values()
				if param.default == param.empty]
		kwargs = [param for param in inspect.signature(self._get_command(command)).parameters.values()
				  if param.default != param.empty]
		return args, kwargs
	
	def _get_command_usage(self, command, args, kwargs):
		return ("%s %s %s" % (command,
							  " ".join("<%s>" % arg for arg in args if str(arg).startswith('h_') is False and str(arg).startswith('to_print') is False),
							  " ".join("[%s]" % kwarg for kwarg in kwargs if str(kwarg).startswith('h_') is False and str(kwarg).startswith('to_print') is False),
							  )).strip()

	
		
	async def _run_single_command(self, username:str, command:str, args:List[str]):
		if self.command_modifier is not None and command.startswith(self.command_modifier) is False:
			fullcmd = command
		else:
			fullcmd = shlex.join([command] + args)
		try:
			command_real_args, command_real_kwargs = self._get_command_args(command)
		except Exception as e:
			# command is not defined on the our side, this is normal
			cmdwrapped = messages_pb2.RunCommand()
			cmdwrapped.clientId = self.clientid
			cmdwrapped.command = fullcmd

			x = asyncio.create_task(self.handle_remote_out(self.clientid, cmdwrapped))
			return
		
		if self.octopwnobj.screen_handler.multi_window_support is False:
			# CLI based clients can't use the actual objects features, so here we're dispatching
			# the command as "RunCommand"
			cmdwrapped = messages_pb2.RunCommand()
			cmdwrapped.clientId = self.clientid
			cmdwrapped.command = fullcmd

			x = asyncio.create_task(self.handle_remote_out(self.clientid, cmdwrapped))
			return

		try:
			com_func = self._get_command(command)
			await com_func(*args)
			return
		except (asyncio.CancelledError):
			raise
		except Exception as ex:
			await self.print('LOCAL ERROR!!! Command "%s" failed: %s Exc: %s' % (command, traceback.format_tb(ex.__traceback__), ex))



	async def recv_token(self, token, to_cleanup = True, yield_continue = False, yield_ok = False):
		try:
			while True:
				try:
					data = await self.__results[token].get()
					if data[0] == 'DATA':
						yield data[1]
					elif data[0] == 'CONTINUE':
						if yield_continue is True:
							yield data[0]
						continue
					elif data[0] == 'OK':
						if data[1] is not None and yield_ok is True:
							yield data[1]
						break
					elif data[0] == 'ERR':
						break
				except Exception as e:
					traceback.print_exc()

		except Exception as e:
			traceback.print_exc()

		finally:
			if to_cleanup is True:
				del self.__results[token]

	async def process_message(self, msg):
		try:
			#print('process_message %s' % msg.cmdtype)
			if msg.cmdtype == 'OctoClientReplyError':
				cmd = messages_pb2.OctoClientReplyOk()
				cmd.ParseFromString(msg.cmddata)
				await self.__results[cmd.token].put(('ERR', cmd.message))
			elif msg.cmdtype == 'OctoClientReplyContinue':
				cmd = messages_pb2.OctoClientReplyContinue()
				cmd.ParseFromString(msg.cmddata)
				await self.__results[cmd.token].put(('CONTINUE', None))
			elif msg.cmdtype == 'OctoClientReplyOk':
				cmd = messages_pb2.OctoClientReplyOk()
				cmd.ParseFromString(msg.cmddata)
				await self.__results[cmd.token].put(('OK', cmd.message))
			else:
				if msg.token is not None and msg.token in self.__results:
					#print('process_message token queue put! %s %s' % (msg.cmdtype, msg.token))
					await self.__results[msg.token].put(('DATA', msg))
				else:
					# probably a public broadcast for the client
					await self.process_message_internal(msg)
					
		except Exception as e:
			traceback.print_exc()

	async def process_message_internal(self, msg):
		await self.print('Message with type "%s" is not processed!' % msg.cmdtype)
		return

	async def send_target(self, target):
		try:
			msg = messages_pb2.TargetAddedEvt()
			msg.target.CopyFrom(target.to_proto())
			await self.send_message(msg)
		except Exception as e:
			traceback.print_exc()

	async def send_credential(self, credential):
		try:
			msg = messages_pb2.CredentialAddedEvt()
			msg.credential.CopyFrom(credential.to_proto())
			await self.send_message(msg)
		except Exception as e:
			traceback.print_exc()

	async def send_genericcommand(self, clientid, command, params):
		try:
			cmd = messages_pb2.OctoClientCommandGeneric()
			cmd.token = self.get_token()
			cmd.command = command
			for param in params:
				cmd.params.append(str(param))

			self.__results[cmd.token] = asyncio.Queue()
			await self.send_clientmessage(clientid, cmd)
			return cmd.token
		except Exception as e:
			traceback.print_exc()

	async def send_clientmessage(self, clientid, cmd, token = None):
		try:
			msg = messages_pb2.OctoClientMessage()
			msg.clientId = clientid
			if token is not None:
				msg.token = token
			msg.cmdtype = cmd.__class__.__name__
			msg.cmddata = cmd.SerializeToString()
			await self.send_message(msg)
		except Exception as e:
			traceback.print_exc()

	async def send_message(self, msg):
		try:
			if self.octopwnobj is None:
				ws = self.ws
			else:
				ws = self.octopwnobj.ws
			if ws.open:
				wrapped = messages_pb2.OctoMessage()
				wrapped.msgtype = msg.__class__.__name__
				wrapped.msgdata = msg.SerializeToString()
				await ws.send(wrapped.SerializeToString())
		except Exception as e:
			traceback.print_exc()

	async def send_ok(self, clientid, token, message = None):
		try:
			msg = messages_pb2.OctoClientReplyOk()
			msg.token = token
			if message is not None:
				msg.message = str(message)
			
			await self.send_clientmessage(clientid, msg, token)
			
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def send_continue(self, clientid, token, message = None):
		try:
			msg = messages_pb2.OctoClientReplyContinue()
			msg.token = token
			await self.send_clientmessage(clientid, msg, token)
			
		except Exception as e:
			await self.print_exc(e)
			return False, e

	async def send_err(self, clientid, token, message = None):
		try:
			msg = messages_pb2.OctoClientReplyError()
			msg.token = token
			if message is not None:
				msg.message = str(message)
			
			await self.send_clientmessage(clientid, msg, token)

		except Exception as e:
			await self.print_exc(e)
			return False, e