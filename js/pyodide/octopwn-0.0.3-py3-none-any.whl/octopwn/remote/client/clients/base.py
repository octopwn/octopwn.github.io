import logging
import ssl
import asyncio
import traceback
from google.protobuf.json_format import MessageToDict

from octopwn.remote import client
from octopwn.remote.client import logger
from octopwn.remote.protocol.python import messages_pb2
from octopwn._version import __banner__
from octopwn.common.clientconfig import ClientConfig, ScannerConfig, UtilsConfig, ServerConfig, ClientConfigBase


class ClientConsoleBaseRemote:
	def __init__(self, octopwnobj, clientid, commands = []):
		self.prompt = '>>> '
		self.octopwnobj = octopwnobj
		self.clientid = clientid
		self.commans = commands
		self.tokenctr = 1
		self.__results = {}
	
	def get_token(self):
		x = self.tokenctr
		self.tokenctr += 1
		return x

	async def print_exc(self, err:Exception, with_tb = True, extra_msg = ''):
		await self.octopwnobj.print_exc(err, with_tb = with_tb, extra_msg = extra_msg)
	
	async def print(self, msgdata, client_id = 0):
		await self.octopwnobj.print(msgdata, client_id = client_id)

	def command_list(self):
		if self.commans is None:
			return []
		return self.commans

	async def recv_token(self, token):
		try:
			while True:
				try:
					data = await self.__results[token].get()
					print('data : %s' % str(data))
					if data[0] == 'DATA':
						print('Yielding data...')
						yield data[1]
					
					elif data[0] == 'OK':
						print('Command finished OK. Message: %s' % data[1])
						break
					elif data[0] == 'ERR':
						print('Error for token: %s' % data[1])
						break
				except Exception as e:
					traceback.print_exc()

		except Exception as e:
			traceback.print_exc()

		finally:
			del self.__results[token]

	async def process_message(self, msg):
		try:
			print('process_message %s' % msg)
			if msg.cmdtype == 'OctoClientReplyError':
				cmd = messages_pb2.OctoClientReplyOk()
				cmd.ParseFromString(msg.cmddata)
				await self.__results[cmd.token].put(('ERR', cmd.message))
			elif msg.cmdtype == 'OctoClientReplyContinue':
				return
			elif msg.cmdtype == 'OctoClientReplyOk':
				cmd = messages_pb2.OctoClientReplyOk()
				cmd.ParseFromString(msg.cmddata)
				await self.__results[cmd.token].put(('OK', cmd.message))
			else:
				if msg.token is not None and msg.token in self.__results:
					print('process_message token queue put! %s %s' % (msg.cmdtype, msg.token))
					await self.__results[msg.token].put(('DATA', msg))
				else:
					# probably a public broadcast for the client
					await self.process_message_internal(msg)
					
		except Exception as e:
			traceback.print_exc()

	async def process_message_internal(self, msg):
		await self.print('Message with type "" is not processed!' % msg.cmdtype)
		return

	async def send_genericcommand(self, clientid, command, params):
		cmd = messages_pb2.OctoClientCommandGeneric()
		cmd.token = self.get_token()
		cmd.command = command
		for param in params:
			cmd.params.append(str(param))

		self.__results[cmd.token] = asyncio.Queue()
		await self.send_clientmessage(clientid, cmd)
		return cmd.token

	async def send_clientmessage(self, clientid, cmd):
		msg = messages_pb2.OctoClientMessage()
		msg.clientId = clientid
		msg.cmdtype = cmd.__class__.__name__
		msg.cmddata = cmd.SerializeToString()
		await self.send_message(msg)

	async def send_message(self, msg):
		if self.octopwnobj is None:
			ws = self.ws
		else:
			ws = self.octopwnobj.ws
		if ws.open:
			wrapped = messages_pb2.OctoMessage()
			wrapped.msgtype = msg.__class__.__name__
			wrapped.msgdata = msg.SerializeToString()
			await ws.send(wrapped.SerializeToString())
