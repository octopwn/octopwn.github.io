import traceback
from octopwn.remote.client.clients.base import ClientConsoleBaseRemote
from octopwn.remote.protocol.python import messages_pb2, ldap_pb2
import pickle

class LDAPClientConsoleRemote(ClientConsoleBaseRemote):
	def __init__(self, octopwnobj, clientid, commands=[]):
		ClientConsoleBaseRemote.__init__(self, octopwnobj, clientid, commands=commands)
		self.adinfo = None

	async def process_message_internal(self, cmd):
		# processing unsolicited messages from server
		try:
			if cmd.cmdtype == 'PickledLDAPResult':
				msg = ldap_pb2.PickledLDAPResult()
				msg.ParseFromString(cmd.cmddata)
				if msg.type == 'adinfo':
					## YAAAAAAAYYY WHAT IS SECURITY ANYWAYS
					self.adinfo = pickle.loads(msg.data)
		except Exception as e:
			await self.print_exc(e)
	
	async def listDirectory(self, path:str):
		params = [path]
		token = await self.send_genericcommand(self.clientid, 'remoteListDirectory', params)
		result = None
		async for data in self.recv_token(token):
			obj = ldap_pb2.PickledLDAPResult()
			obj.ParseFromString(data.cmddata)
			## YAAAAAAAYYY WHAT IS SECURITY ANYWAYS
			result = pickle.loads(obj.data)

		return result, None
