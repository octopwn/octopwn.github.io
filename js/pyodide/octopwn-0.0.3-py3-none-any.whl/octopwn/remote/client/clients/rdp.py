import traceback
from aardwolf.commons.queuedata import *
from octopwn.remote.client.clients.base import ClientConsoleBaseRemote
from octopwn.remote.protocol.python import messages_pb2, rdp_pb2
from aardwolf.extensions.RDPECLIP.protocol.formatlist import CLIPBRD_FORMAT
from aardwolf.commons.queuedata.mouse import RDP_MOUSE
from aardwolf.commons.queuedata.constants import MOUSEBUTTON, VIDEO_FORMAT

class RDPClientConsoleRemote(ClientConsoleBaseRemote):
	def __init__(self, octopwnobj, clientid, commands = []):
		ClientConsoleBaseRemote.__init__(self, octopwnobj, clientid, commands=commands)

	async def mouse_evt(self, x:int, y:int, button:int, press:bool, release:bool):
		#if press is True:
		#	self.print_sync('MOUSE! X: %s Y: %s BUTTON: %s PRESS: %s RELEASE: %s' % (x, y, button, press, release))
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		button = int(button)
		if button == 1:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_LEFT
		elif button == 2:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_RIGHT
		elif button == 3:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_MIDDLE
		else:
			buttontype = MOUSEBUTTON.MOUSEBUTTON_HOVER
		
		mi = RDP_MOUSE()
		mi.xPos = x
		mi.yPos = y
		mi.button = buttontype
		mi.is_pressed = press
		await self.__rdpconn.ext_in_queue.put(mi)
	

	def keyboard_evt(self, keychar:str, press:bool, is_scancode:bool = False):
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		if keychar is None:
			self.print_sync('Not recognized input char: %s Skipping!' % keychar)
			return
		if is_scancode is True:
			ki = RDP_KEYBOARD_SCANCODE()
			ki.is_pressed = press
			if keychar.startswith('VK_') is True:
				ki.vk_code = keychar
			else:
				ki.keyCode = int(keychar)
		else:
			ki = RDP_KEYBOARD_UNICODE()
			ki.char = keychar
			ki.is_pressed = press
		self.__rdpconn.ext_in_queue.put_nowait(ki)
	
	async def __video_data_handle(self, token):
		async for data in self.recv_token(token):
			msg = rdp_pb2.RDPFrame()
			msg.ParseFromString(data.cmddata)
			_, err = await self.octopwnobj.screen_handler.update_rdp_canvas(self.clientid, msg.data, msg.xPos, msg.yPos, msg.width, msg.height)
			if err is not None:
				raise err
	
	async def do_login(self, resolution = '1024x768'):
		print('Login called! Resolution: %s' % resolution)
		if resolution is None:
			resolution = '1024x768'
		params = [resolution]
		token = await self.send_genericcommand(self.clientid, 'login', params)
		async for data in self.recv_token(token):
			#doesnt matter
			x = 1
