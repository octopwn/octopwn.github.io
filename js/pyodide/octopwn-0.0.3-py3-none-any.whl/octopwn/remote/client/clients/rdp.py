import asyncio
import platform
import traceback
from aardwolf.commons.queuedata import *
from octopwn.remote.client.clients.base import ClientConsoleBaseRemote
from octopwn.remote.protocol.python import messages_pb2, rdp_pb2
from aardwolf.extensions.RDPECLIP.protocol.formatlist import CLIPBRD_FORMAT
from aardwolf.commons.queuedata.constants import MOUSEBUTTON, VIDEO_FORMAT

class RDPClientConsoleRemote(ClientConsoleBaseRemote):
	def __init__(self, octopwnobj, clientid, commands = []):
		ClientConsoleBaseRemote.__init__(self, octopwnobj, clientid, commands=commands)
		self.__video_task = None
		self.logon_ok = False

	async def mouse_evt(self, x:int, y:int, button:int, press:bool, release:bool):
		#if press is True:
		#	self.print_sync('MOUSE! X: %s Y: %s BUTTON: %s PRESS: %s RELEASE: %s' % (x, y, button, press, release))
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		
		mi = rdp_pb2.RDPMouse()
		mi.xPos = x
		mi.yPos = y
		mi.button = int(button)
		mi.isPressed = press
		await self.send_clientmessage(self.clientid, mi)

	async def keyboard_evt(self, keychar:str, press:bool, is_scancode:bool = False):
		if self.logon_ok is False:
			# not logged in currently, nothing to do
			return
		if keychar is None:
			self.print_sync('Not recognized input char: %s Skipping!' % keychar)
			return
		if is_scancode is True:
			ki = RDP_KEYBOARD_SCANCODE()
			ki.is_pressed = press
			if keychar.startswith('VK_') is True:
				ki.vk_code = keychar
			else:
				ki.keyCode = int(keychar)
		else:
			ki = rdp_pb2.RDPKeyboardUnicode()
			ki.char = str(keychar)
			ki.isPressed = press
			await self.send_clientmessage(self.clientid, ki)
	
	def paste_evt(self, *args):
		# not yet used
		x = asyncio.create_task(self.print('paste! %s' % args))

	async def do_logout(self):
		try:
			self.logon_ok = False
			if self.__video_task is not None:
				self.__video_task.cancel()
				self.__video_task = None
			await self.print('[-] Connection terminated!')
			return True, None
		except Exception as e:
			await self.print_exc(e)
			return None, e

	async def __monitor(self, token):
		try:
			async for data in self.recv_token(token, to_cleanup=False):
				msg = rdp_pb2.RDPWindowDimensions()
				msg.ParseFromString(data.cmddata)
				width = msg.width
				height = msg.height
				break
			
			self.logon_ok = True
			if platform.system() == 'Emscripten':
				from pyodide import create_proxy
				self.mouse_cb_proxy = create_proxy(self.mouse_evt)
				self.keyboard_cb_proxy = create_proxy(self.keyboard_evt)
				self.paste_cb_proxy = create_proxy(self.paste_evt)
				_, err = await self.octopwnobj.screen_handler.create_rdp_canvas(
						self.clientid, 
						'%s[%s][%sx%s]' % ('RDP', self.clientid, width, height), 
						width, 
						height, 
						self.mouse_cb_proxy, 
						self.keyboard_cb_proxy, 
						self.paste_cb_proxy
					)
				if err is not None:
					raise err
			
			async for data in self.recv_token(token):
				if data.cmdtype == 'RDPFrame':
					msg = rdp_pb2.RDPFrame()
					msg.ParseFromString(data.cmddata)
					_, err = await self.octopwnobj.screen_handler.update_rdp_canvas(
							self.clientid, 
							msg.data, 
							msg.xPos, 
							msg.yPos, 
							msg.width, 
							msg.height
						)
				else:
					print('?????')
		except Exception as e:
			traceback.print_exc()
		finally:
			await self.do_logout()

	async def do_login(self, resolution:str = '1024x768'):
		if resolution is None or resolution == '':
			resolution = '1024x768'
		params = [resolution]
		token = await self.send_genericcommand(self.clientid, 'login', params)
		self.__video_task = asyncio.create_task(self.__monitor(token))
		return True, None