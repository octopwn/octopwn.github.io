import traceback
import asyncio
from octopwn.remote.client.clients.base import ClientConsoleBaseRemote
from octopwn.remote.protocol.python import messages_pb2, smb_pb2


class SMBClientConsoleRemote(ClientConsoleBaseRemote):
	def __init__(self, octopwnobj, clientid, commands = []):
		ClientConsoleBaseRemote.__init__(self, octopwnobj, clientid, commands=commands)
		self.shares = {}

	async def do_shares(self, to_print = False):
		try:
			params = []
			token = await self.send_genericcommand(self.clientid, 'remoteShares', params)
			async for data in self.recv_token(token):
				print('Share incoming!')
				shareobj = smb_pb2.SMBShare()
				shareobj.ParseFromString(data.cmddata)
				self.shares[shareobj.name] = shareobj
			
			print('Shares list finished!')
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def listDirectory(self, path:str):
		params = [path]
		token = await self.send_genericcommand(self.clientid, 'remoteListDirectory', params)
		results = []
		async for data in self.recv_token(token):
			obj = smb_pb2.SMBFileEntry()
			obj.ParseFromString(data.cmddata)			
			res = {
				'type': obj.type,
				'name' : obj.name,
				'size' : obj.size,
				'creationtime'   : obj.creationtime,
				'lastaccesstime' : obj.lastaccesstime,
				'lastwritetime'  : obj.lastwritetime,
				'changetime'     : obj.changetime,
				'allocationsize' : obj.allocationsize,
				'attributes' : obj.attributes,
			}
			results.append(res)
		
		return results, None

	async def downloadFile_internal(self, token, res_q):
		try:
			async for data in self.recv_token(token):
				print(data)
				obj = smb_pb2.SMBFileChunk()
				obj.ParseFromString(data.cmddata)
				
				await res_q.put([False, obj.data, obj.totalsize, None])
			await res_q.put([True, None, None, None])
		except Exception as e:
			traceback.print_exc()
			await res_q.put([True, None, None, e])

	async def downloadFile(self, path:str):
		try:
			res_q = asyncio.Queue()
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remoteDownloadFile', params)
			x = asyncio.create_task(self.downloadFile_internal(token, res_q))
			
			return res_q, None, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e

	async def deleteDirectory(self, path):
		try:
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remotedeleteDirectory', params)
			async for data in self.recv_token(token):
				x = 1

			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e
	
	async def createDirectory(self, path):
		try:
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remotecreateDirectory', params)
			async for data in self.recv_token(token):
				x = 1
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e

	async def deleteFile(self, path):
		try:
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remotedeleteFile', params)
			async for data in self.recv_token(token):
				x = 1
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e
