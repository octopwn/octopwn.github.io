import io
import traceback
import asyncio
from octopwn.remote.client.clients.base import ClientConsoleBaseRemote
from octopwn.remote.protocol.python import messages_pb2, smb_pb2


class SMBClientConsoleRemote(ClientConsoleBaseRemote):
	def __init__(self, octopwnobj, clientid, commands = []):
		ClientConsoleBaseRemote.__init__(self, octopwnobj, clientid, commands=commands)
		self.shares = {}

	async def do_shares(self, to_print = False):
		try:
			params = []
			token = await self.send_genericcommand(self.clientid, 'remoteShares', params)
			async for data in self.recv_token(token):
				shareobj = smb_pb2.SMBShare()
				shareobj.ParseFromString(data.cmddata)
				self.shares[shareobj.name] = shareobj
			
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, e
	
	async def listDirectory(self, path:str):
		params = [path]
		token = await self.send_genericcommand(self.clientid, 'remoteListDirectory', params)
		results = []
		async for data in self.recv_token(token):
			obj = smb_pb2.SMBFileEntry()
			obj.ParseFromString(data.cmddata)			
			res = {
				'type': obj.type,
				'name' : obj.name,
				'size' : obj.size,
				'creationtime'   : obj.creationtime,
				'lastaccesstime' : obj.lastaccesstime,
				'lastwritetime'  : obj.lastwritetime,
				'changetime'     : obj.changetime,
				'allocationsize' : obj.allocationsize,
				'attributes' : obj.attributes,
			}

			results.append(res)
		
		return results, None

	async def downloadFile_internal(self, token, res_q):
		try:
			async for data in self.recv_token(token):
				obj = smb_pb2.SMBFileChunk()
				obj.ParseFromString(data.cmddata)
				
				await res_q.put([False, obj.data, obj.totalsize, None])
			await res_q.put([True, None, None, None])
		except Exception as e:
			traceback.print_exc()
			await res_q.put([True, None, None, e])

	async def downloadFile(self, path:str):
		try:
			res_q = asyncio.Queue()
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remoteDownloadFile', params)
			x = asyncio.create_task(self.downloadFile_internal(token, res_q))
			
			return res_q, None, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e

	async def deleteDirectory(self, path):
		try:
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remotedeleteDirectory', params)
			async for data in self.recv_token(token):
				x = 1

			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e
	
	async def createDirectory(self, path):
		try:
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remotecreateDirectory', params)
			async for data in self.recv_token(token):
				x = 1
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e

	async def deleteFile(self, path):
		try:
			params = [path]
			token = await self.send_genericcommand(self.clientid, 'remotedeleteFile', params)
			async for data in self.recv_token(token):
				x = 1
			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e

	async def createFile(self, localpath:str, remotepath:str):
		try:
			with open(localpath, 'rb') as f:
				return await self.createFileBytes(remotepath, f)
		except Exception as e:
			traceback.print_exc()
			return None, None, e

	async def createFileBytes(self, remotepath, filedata):
		try:
			# sorry for this one but I'd rather not import pyodide
			if str(type(filedata)).find('JsProxy') != -1:
				jsproxy = filedata
				filedata = bytearray(filedata.to_py())
			
			if isinstance(filedata, (bytes, bytearray)) is True:
				filedata = io.BytesIO(filedata)
			
			params = [remotepath]
			token = await self.send_genericcommand(self.clientid, 'remotecreateFile', params)
			contd = False

			# waiting for continue
			async for data in self.recv_token(token, yield_continue = True, to_cleanup = False):
				contd = True
				break
			
			if contd is True:
				try:
					filedata.seek(0, io.SEEK_END)
					fsize = filedata.tell()
					filedata.seek(0, io.SEEK_SET)

					tosend = filedata.read(65535)
					while len(tosend) > 0:
						msg = smb_pb2.SMBFileChunk()
						msg.data = tosend
						msg.totalsize = fsize
						await self.send_clientmessage(self.clientid, msg, token = token)
						tosend = filedata.read(65535)

					await self.send_ok(self.clientid, token)
				except Exception as e:
					await self.send_err(self.clientid, token)
					raise e

			
			else:
				raise Exception('Server sent error!')
			#awaiting OK from the server
			async for data in self.recv_token(token, to_cleanup = False):
				x = 1

			return True, None
		except Exception as e:
			traceback.print_exc()
			return None, None, e