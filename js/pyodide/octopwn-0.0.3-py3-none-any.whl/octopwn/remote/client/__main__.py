import asyncio
import traceback
from octopwn.remote.client import logger

from octopwn.remote.client.core import OctoPwnRemoteClient
from octopwn.common.screenhandler import ScreenHandlerPromptToolkitApplication

async def amain(url, ssl_ctx = None):
	try:
		screen_handler = ScreenHandlerPromptToolkitApplication()
		rc = OctoPwnRemoteClient(url, ssl_ctx, screen_handler)
		await rc.run()
	except Exception as e:
		print('Failed to run client!')
		traceback.print_exc()

def main():
	import argparse
	import logging
	from octopwn.remote import argparse_ssl, args_to_sslctx
	
	parser = argparse.ArgumentParser(description='Octopwn Remote Client')
	parser.add_argument('-v', '--verbose', action='count', default=0, help='Increase verbosity, can be stacked')
	argparse_ssl(parser)
	parser.add_argument('--url', default='ws://127.0.0.1:8181', help='URL of the server. Eg. "ws://127.0.0.1:8181" or "wss://" for TLS')
	args = parser.parse_args()
	ssl_ctx = args_to_sslctx(args)

	if args.verbose == 0:
		logging.basicConfig(level=logging.CRITICAL)
		logger.setLevel(logging.INFO)
	
	elif args.verbose == 1:
		logging.basicConfig(level=logging.INFO)
		logger.setLevel(logging.DEBUG)
			
	elif args.verbose > 1:
		logging.basicConfig(level=logging.DEBUG)
		logger.setLevel(1)

	asyncio.run(amain(args.url, ssl_ctx))

if __name__ == '__main__':
	main()
