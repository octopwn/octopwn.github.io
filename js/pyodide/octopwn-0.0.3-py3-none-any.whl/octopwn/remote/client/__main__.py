import asyncio
import ssl
import sys
import multiprocessing
import traceback
from octopwn.remote.client import logger

from octopwn.remote.client.core import OctoPwnRemoteClient
from octopwn.common.screenhandler import ScreenHandlerPromptToolkitApplication

async def amain(url, authmethod, username = None, password = None, ssl_ctx = None):
	try:
		screen_handler = ScreenHandlerPromptToolkitApplication()
		rc = OctoPwnRemoteClient(
			url, 
			ssl_ctx, 
			screen_handler, 
			username=username, 
			password=password, 
			authmethod=authmethod
		)
		await rc.run()
	except Exception as e:
		print('Failed to run client!')
		traceback.print_exc()

def main():
	import argparse
	import logging
	from octopwn.remote import argparse_ssl, args_to_sslctx
	
	parser = argparse.ArgumentParser(description='Octopwn Remote Client')
	parser.add_argument('-v', '--verbose', action='count', default=0, help='Increase verbosity, can be stacked')
	parser.add_argument('-u', '--username', help='Username for authentication')
	parser.add_argument('-p', '--password', help='Password for authentication')
	parser.add_argument('--override-auth', help='Will override the selected authentication method. Only use this for developement purposes!')
	argparse_ssl(parser, 'client')
	parser.add_argument('--url', default='ws://127.0.0.1:8181', help='URL of the server. Eg. "ws://127.0.0.1:8181" or "wss://" for TLS')
	parser.add_argument('--ignore-ssl-errors', help='Who needs security anyways?')
	args = parser.parse_args()
	ssl_ctx = args_to_sslctx(args, 'client')

	if args.verbose == 0:
		logging.basicConfig(level=logging.CRITICAL)
		logger.setLevel(logging.INFO)
	
	elif args.verbose == 1:
		logging.basicConfig(level=logging.INFO)
		logger.setLevel(logging.DEBUG)
			
	elif args.verbose > 1:
		logging.basicConfig(level=logging.DEBUG)
		logger.setLevel(1)

	if args.override_auth is not None:
		authmethod = args.override_authmethod
	else:
		authmethod = 'NONE'
		if ssl_ctx is not None:
			authmethod = 'CERT'
		if args.username is not None and args.password is not None:
			authmethod = 'PLAIN'
	
	if ssl_ctx is None and args.url.startswith('wss://') is True:
		ssl_ctx = ssl.create_default_context()
		if args.ignore_ssl_errors is True:
			ssl_ctx.check_hostname = False
			ssl_ctx.verify_mode = ssl.CERT_NONE

	print('Selected authmethod: %s' % authmethod)
	#print(args.url)
	#return
	asyncio.run(amain(args.url, authmethod, args.username, args.password, ssl_ctx))

if __name__ == '__main__':
	if sys.platform.startswith('win'):
		# On Windows calling this function is necessary.
		multiprocessing.freeze_support()
	main()
