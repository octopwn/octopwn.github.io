import ssl

def argparse_ssl(parser, direction = 'server'):
	parser.add_argument('--ssl-cert', help='Certificate file for TLS')
	parser.add_argument('--ssl-verify-certs', help='Certificate verify location')
	parser.add_argument('--ssl-key', help='Key file for TLS')
	parser.add_argument('--ssl-dh', help='DH params for TLS')
	parser.add_argument('--ssl-ciphers', help='Cipher params for TLS')
	#parser.add_argument('--ssl-protocol', help='TLS protocl to be used')

def args_to_sslctx(args, direction = 'server'):
	ssl_ctx = None
	if args.ssl_cert is None:
		return None

	if direction == 'server':
		ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
		if args.ssl_key is None:
			raise Exception('TLS certificate is set but no keyfile!')
		ssl_ctx.load_cert_chain(args.ssl_cert, args.ssl_key)
		if args.ssl_verify_certs is not None:
			ssl_ctx.load_verify_locations(args.ssl_verify_certs)
			ssl_ctx.verify_mode = ssl.CERT_OPTIONAL
		if args.ssl_ciphers is not None:
			ssl_ctx.set_ciphers(args.ssl_ciphers)
		if args.ssl_dh is not None:
			ssl_ctx.load_dh_params(args.ssl_dh)

	if direction == 'client':
		ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
		if args.ssl_key is None:
			raise Exception('TLS certificate is set but no keyfile!')
		ssl_ctx.load_cert_chain(args.ssl_cert, args.ssl_key)
		if args.ssl_ciphers is not None:
			ssl_ctx.set_ciphers(args.ssl_ciphers)
		if args.ssl_dh is not None:
			ssl_ctx.load_dh_params(args.ssl_dh)
	return ssl_ctx