import ssl

def argparse_ssl(parser):
	parser.add_argument('--ssl-cert', help='Certificate file for TLS')
	parser.add_argument('--ssl-key', help='Key file for TLS')
	parser.add_argument('--ssl-dh', help='DH params for TLS')
	parser.add_argument('--ssl-ciphers', help='DH params for TLS')
	parser.add_argument('--ssl-protocol', help='TLS protocl to be used')

def args_to_sslctx(args):
	ssl_ctx = None
	if args.ssl_cert is not None:
		ssl_ctx = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
		if args.ssl_key is None:
			raise Exception('TLS certificate is set but no keyfile!')
		ssl_ctx.load_cert_chain(args.ssl_cert, args.ssl_key)
		if args.ssl_ciphers is not None:
			ssl_ctx.set_ciphers(args.ssl_ciphers)
		if args.ssl_dh is not None:
			ssl_ctx.load_dh_params(args.ssl_dh)
	return ssl_ctx