
from octopwn.remote.protocol.python import messages_pb2

def serializeParamsDict(d):
	sd = messages_pb2.GenericDict()
	for key in d:
		sk = messages_pb2.GenericDictEntry()
		sk.key = str(key)
		if d[key][0] == str:
			sk.valueType = 'str'
			if d[key][1] is not None:
				sv = messages_pb2.GenericStringVal()
				sv.value = str(d[key][1])
				sk.value = sv.SerializeToString()
		elif d[key][0] == int and d[key][1] is not None:
			sk.valueType = 'int'
			if d[key][1] is not None:
				sv = messages_pb2.GenericIntVal()
				sv.value = int(d[key][1])
				sk.value = sv.SerializeToString()
		elif d[key][0] == bool and d[key][1] is not None:
			sk.valueType = 'bool'
			if d[key][1] is not None:
				sv = messages_pb2.GenericBoolVal()
				sv.value = bool(d[key][1])
				sk.value = sv.SerializeToString()
		elif d[key][0] == list and d[key][1] is not None:
			sk.valueType = 'slist'
			if d[key][1] is not None:
				sv = messages_pb2.GenericStringListVal()
				for data in d[key][1]:
					sv.values.append(str(data))
				sk.value = sv.SerializeToString()
		sd.entries.append(sk)
	return sd

def deserializeParamsDict(msg:messages_pb2.GenericDict):
	res = {}
	for entry in msg.entries:
		vtype = None
		value = None
		if entry.valueType == 'str':
			vtype = str
			valueobj = messages_pb2.GenericStringVal()
			valueobj.ParseFromString(entry.value)
			value = valueobj.value
		elif entry.valueType == 'int':
			vtype = int
			valueobj = messages_pb2.GenericIntVal()
			valueobj.ParseFromString(entry.value)
			value = valueobj.value
		elif entry.valueType == 'bool':
			vtype = bool
			valueobj = messages_pb2.GenericBoolVal()
			valueobj.ParseFromString(entry.value)
			value = valueobj.value
		elif entry.valueType == 'slist':
			vtype = str
			valueobj = messages_pb2.GenericStringListVal()
			valueobj.ParseFromString(entry.value)
			value = []
			for data in valueobj.value:
				value.append(data)

		res[entry.key] = (vtype, value)
	
	return res