
import traceback
import asyncio
from octopwn._version import __banner__

def abort(event):
	return

def copy_selection(event):
	return

try:
	from prompt_toolkit.application import Application
	from prompt_toolkit.application.current import get_app
	from prompt_toolkit.key_binding import KeyBindings
	from prompt_toolkit.key_binding.bindings.focus import focus_next, focus_previous
	from prompt_toolkit.layout import Layout, VSplit, HSplit
	from prompt_toolkit.layout.layout import Layout
	from prompt_toolkit.widgets import TextArea, Frame, SearchToolbar
	from prompt_toolkit.clipboard.pyperclip import PyperclipClipboard
	# this has to be outside of self...
	def abort(event):
		# triggered on CTRL+C
		get_app().exit()

	def copy_selection(event):
		app = get_app()
		data = app.current_buffer.copy_selection()
		app.clipboard.set_data(data)

except ImportError:
	pass


class ScreenHandlerBase:
	def __init__(self):
		self.multi_window_support = False
		self.remoting_support = False
	
	async def print_client_msg(self, clientid:int, msg:str):
		"""Called when a new message needs to be printed for a specific client window"""
		raise NotImplementedError()

	async def print_main_window(self, msg):
		raise NotImplementedError()

	async def clear_main_window(self):
		raise NotImplementedError()
	

	#### CLIENT CONTROLS #####
	async def client_added(self, cid, client):
		return None, NotImplementedError()

	async def refresh_clients(self):
		return None, NotImplementedError()
	

	#### TARGET CONTROLS #####
	async def target_added(tid:int, target):
		"""Called when a new target has been added"""
		return None, NotImplementedError()

	async def refresh_targets(self, force=False):
		"""Called to trigger a full target window refresh"""
		return None, NotImplementedError()
	
	#### CREDENTIAL CONTROLS #####
	async def refresh_credentials(self):
		"""Called to trigger a full credential window refresh"""
		return None, NotImplementedError()
	
	async def credential_added(self, cid, credential):
		"""Called when a new credential has been added"""
		return None, NotImplementedError()
	
	#### PROXY(CHAIN) CONTROLS #####
	async def refresh_proxies(self):
		return None, NotImplementedError()
	
	async def proxy_added(self, pid, proxy):
		return None, NotImplementedError()
	

	#### ADDITIONAL STUFF #####
	async def set_input_dialog_title(self, clientid, title):
		raise NotImplementedError()
	
	def set_message_dialog_title(self, clientid:int, title:str):
		raise NotImplementedError()
	
	def abort(self, event = None):
		return
	
	async def create_client_window(self, clientid:int, cliname:str, client_settings, client):
		raise NotImplementedError()

	async def run(self, octopwn, input_handler):
		return True, None

class ScreenHandlerPromptToolkitApplication:
	def __init__(self):
		self.octopwn = None
		self.remoting_support = False
		self.multi_window_support = False
		self.message_area_textfield = None
		self.input_area_textfield = None
		self.dialog_window = None
		self.input_dialog = None
		self.creds_list_area = None
		self.creds_list_dialog = None
		self.target_list_area = None
		self.target_list_dialog = None
		self.proxy_list_area = None
		self.proxy_list_dialog = None
		self.clients_msg_text_area = None
		self.clients_msg_area = None
		self.application = None
		self.application_task = None
		self.bindings = None
		self.application_task = None
		self.input_handler = None

	async def build_screen(self):
		try:
			self.__input_queue = asyncio.Queue()
			kb_text = 'Key bindings:\nCTRL+C -> exit\nCTRL+X -> copy selected text to clipboard\nCTRL+SPACE -> selection mode\nCTRL+D -> focus next window\n\n'
			opening_text = __banner__ + '\n' + kb_text

			self.bindings = KeyBindings()
			self.bindings.add('c-c')(abort)
			self.bindings.add('c-x')(copy_selection)
			self.bindings.add('c-d')(focus_next)
			#self.bindings.add('c-n')(focus_previous)

			target_search = SearchToolbar()
			self.target_list_area = TextArea(text="", scrollbar=False, wrap_lines = True, read_only=True, search_field=target_search)
			self.target_list_dialog = Frame(
				title='TARGETS',
				body=self.target_list_area,
			)

			proxy_search = SearchToolbar()
			self.proxy_list_area = TextArea(text="", scrollbar=False, wrap_lines = True, read_only=True, search_field=proxy_search)
			self.proxy_list_dialog = Frame(
				title='PROXIES',
				body=self.proxy_list_area,
			)

			creds_search = SearchToolbar()
			self.creds_list_area = TextArea(text="", multiline=True, scrollbar=False, wrap_lines = True, read_only=True, search_field=creds_search)
			self.creds_list_dialog = Frame(
				title='CREDS',
				body=self.creds_list_area,
			)

			msg_search = SearchToolbar()
			self.message_area = TextArea(text=opening_text, multiline=True, scrollbar=False, wrap_lines = True, read_only=True, search_field=msg_search)
			self.message_dialog = Frame(
				title='OUTPUT',
				body=self.message_area,
			)

			self.input_area = TextArea(height=1, multiline=False, wrap_lines=False, accept_handler=self.input_handler)
			self.input_dialog = Frame(
				title='MAIN MENU',
				body=self.input_area,
				#width=50,
			)
			self.clients_msg_text_area = TextArea(text="", multiline=True, scrollbar=False, wrap_lines = True, read_only=True)
			self.clients_msg_area = Frame(
				title='CLIENTS',
				body=HSplit([
					self.clients_msg_text_area]),
				width=55,
			)

			new_container = VSplit([
				HSplit([
					HSplit([
						msg_search,
						self.message_dialog,
					]),
					self.input_dialog,
				],padding_char = '-'),
				HSplit([
					self.clients_msg_area,
					HSplit([
						creds_search,
						self.creds_list_dialog,
					]),
					VSplit([
						HSplit([
							proxy_search,
							self.proxy_list_dialog,
						]),
						HSplit([
							self.target_list_dialog,
							target_search
						])
						
					])
				],padding_char = '-')
			],padding_char = '|')


			self.application = Application(
				layout=Layout(
					new_container,
					focused_element = self.input_area
				),
				key_bindings=self.bindings,
				mouse_support=False,
				full_screen=True,
				clipboard=PyperclipClipboard()
			)
			return self.application, None
		except Exception as e:
			traceback.print_exc()
			return None, e

	async def run(self, octopwn, input_handler):
		try:
			self.octopwn = octopwn
			self.input_handler = input_handler
			self.application, err = await self.build_screen()
			if err is not None:
				raise err
			self.application_task = asyncio.create_task(self.application.run_async(set_exception_handler=False))
			return self.application_task, None
		except Exception as e:
			return None, e

	def abort(self, event = None):
		self.octopwn.main_stopped_evt.set()
		abort(event)

	async def print_main_window(self, msg):
		self.message_area.text += msg + '\n'
		self.message_area.buffer.cursor_position = len(self.message_area.text)

	async def clear_main_window(self):
		self.message_area.text = ''
	
	async def client_added(self, cid, client):
		try:


			return True, None
		except Exception as e:
			return None, e

	async def refresh_clients(self):
		try:
			self.clients_msg_text_area.text = ''
			msg = ''
			for tid in self.octopwn.clients:
				if tid == 0:
					continue
				msg += '[%s] %s\n' % (tid, self.octopwn.clients[tid][0].clientname)
			self.clients_msg_text_area.text += msg
			self.clients_msg_text_area.buffer.cursor_position = len(self.clients_msg_text_area.text)
			return True, None
		except Exception as e:
			return None, e
	
	async def target_added(self, tid, target):
		# No need for this, refresh target will redraw the window
		return True, None

	async def refresh_targets(self, force=False):
		try:
			self.target_list_area.text = ''
			msg = ''
			for tid in self.octopwn.targets:
				if self.octopwn.targets[tid].hidden is True:
					continue
				msg += '[%s] %s\n' % (tid, self.octopwn.targets[tid].to_line())
			self.target_list_area.text += msg
			self.target_list_area.buffer.cursor_position = len(self.target_list_area.text)
			return True, None
		except Exception as e:
			print(e)
			return None, e
	
	async def refresh_proxies(self):
		try:
			self.proxy_list_area.text = ''
			msg = ''
			for tid in self.octopwn.proxies:
				msg += '[%s] %s\n' % (tid, self.octopwn.proxies[tid].to_line())
			self.proxy_list_area.text += msg
			self.proxy_list_area.buffer.cursor_position = len(self.proxy_list_area.text)
			return True, None
		except Exception as e:
			return None, e

	async def proxy_added(self, pid, proxy):
		#Not needed for this gui
		return True, None

	async def credential_added(self, cid, credential):
		#Not needed for this gui
		return True, None
	
	async def refresh_credentials(self):
		try:
			self.creds_list_area.text = ''
			msg = ''
			for cid in self.octopwn.credentials:
				if self.octopwn.credentials[cid].hidden is True:
					continue
				msg += '[%s] %s\n' % (cid, self.octopwn.credentials[cid].to_line())

			self.creds_list_area.text += msg
			self.creds_list_area.buffer.cursor_position = len(self.creds_list_area.text)
			return True, None
		except Exception as e:
			return None, e
	
	async def set_input_dialog_title(self, clientid:int, title:str):
		self.input_dialog.title = title

	async def set_message_dialog_title(self, clientid:int, title:str):
		self.message_dialog.title = title
		self.message_area.buffer.auto_down()
	
	async def create_client_window(self, clientid:int, cliename:str, client_settings, client):
		return True, None
	
	async def print_client_msg(self, clientid:int, msg:str):
		return True, None