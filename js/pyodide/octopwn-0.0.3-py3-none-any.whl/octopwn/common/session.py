from os import stat
from typing import Dict, Tuple
import toml
import base64

from octopwn._version import __version__
from octopwn.clients.base import ClientConsoleBase
from octopwn.common.clientconfig import ClientConfigBase, ClientConfig, ScannerConfig, UtilsConfig, ServerConfig
from octopwn.common.credential import Credential
from octopwn.common.target import Target
from octopwn.common.proxy import Proxy, ProxyChain
from octopwn.core import OctoPwn

class OctoPwnSessionFile:
	def __init__(self, octopwnobj:OctoPwn = None):
		self.octopwnobj = octopwnobj
		self.dcip:str = None
		self.realm:str = None
		self.credentials:Dict[int, Credential] = {}
		self.targets:Dict[int, Target] = {}
		self.proxies:Dict[int, Proxy] = {}
		self.clients:Dict[int, Tuple[ClientConfigBase, ClientConsoleBase]] = {}
		self.work_dir:str = None
		self.messagebuffers:Dict[int, str] = {}

		if self.octopwnobj is not None:
			self.dcip = octopwnobj.dcip
			self.realm = octopwnobj.realm
			self.credentials = octopwnobj.credentials
			self.targets = octopwnobj.targets
			self.proxies = octopwnobj.proxies
			self.clients = octopwnobj.clients
			self.work_dir = octopwnobj.work_dir


	def to_dict(self):
		t = {}
		t['version'] = __version__
		t['dcip'] = self.dcip
		t['realm'] = self.realm
		t['work_dir'] = self.work_dir
		t['credentials'] = {}
		for tid in self.credentials:
			t['credentials'][str(tid)] = self.credentials[tid].to_dict()
		
		t['targets'] = {}
		for tid in self.targets:
			t['targets'][str(tid)] = self.targets[tid].to_dict()
		
		t['proxies'] = {}
		for tid in self.proxies:
			t['proxies'][str(tid)] = self.proxies[tid].to_dict()
		
		t['clients'] = {}
		for tid in self.clients:
			if tid == 0:
				#skipping main window...
				continue
			t['clients'][str(tid)] = {}
			client_config = self.clients[tid][0]
			client = self.clients[tid][1]
			t['clients'][str(tid)]['config'] = None
			if client_config is not None:
				if client_config.config_type in ['SCANNER', 'UTILS']:
					t['clients'][str(tid)]['config'] = client.save_config(client_config).to_dict()
				else:
					t['clients'][str(tid)]['config'] = client_config.to_dict()
			#t['clients'][tid]['client'] = client.to_dict()
		
		t['messagebuffers'] = {}
		for tid in self.octopwnobj.client_messages:
			if len(self.octopwnobj.client_messages) == 0:
				t['messagebuffers'][str(tid)] = base64.b64encode(b'<EMPTY>').decode('utf-8')
			else:
				buffer = '\r\n'.join(self.octopwnobj.client_messages[tid])
				t['messagebuffers'][str(tid)] = base64.b64encode(buffer.encode('utf-8')).decode('utf-8')
		
		return t
	
	def to_toml(self):
		return toml.dumps(self.to_dict())
	

	@staticmethod
	def from_dict(d:dict):
		res = OctoPwnSessionFile()
		res.work_dir = None
		res.dcip = d.get('dcip')
		res.realm = d.get('realm')
		res.work_dir = d.get('work_dir', None)
		
		res.credentials = {}
		if 'credentials' in d:
			for tid in d['credentials']:
				res.credentials[int(tid)] = Credential.from_dict(d['credentials'][tid])
		
		res.targets = {}
		if 'targets' in d:
			for tid in d['targets']:
				res.targets[int(tid)] = Target.from_dict(d['targets'][tid])
		
		res.proxies = {}
		if 'proxies' in d:
			for tid in d['proxies']:
				if d['proxies'][tid]['ptype'].upper() == 'CHAIN':
					res.proxies[int(tid)] = ProxyChain.from_dict(d['proxies'][tid])
				else:
					res.proxies[int(tid)] = Proxy.from_dict(d['proxies'][tid])
		
		res.clients = {}
		if 'clients' in d:
			for tid in d['clients']:
				client_config = d['clients'][tid]['config']
				if client_config is not None:
					if client_config['config_type'].upper() == 'NORMAL':
						client_config = ClientConfig.from_dict(client_config)
					elif client_config['config_type'].upper() == 'SCANNER':
						client_config = ScannerConfig.from_dict(client_config)
					elif client_config['config_type'].upper() == 'SERVER':
						client_config = ServerConfig.from_dict(client_config)
					elif client_config['config_type'].upper() == 'UTILS':
						client_config = UtilsConfig.from_dict(client_config)
				
				client = None
				if 'client' in d['clients'][tid]:
					client = d['clients'][tid]['client']
				res.clients[str(tid)] = (client_config, client)

		res.messagebuffers = {}
		if 'messagebuffers' in d:
			for tid in d['messagebuffers']:
				buffer = base64.b64decode(d['messagebuffers'][tid]).decode('utf-8')
				res.messagebuffers[int(tid)] = buffer.split('\r\n')

		return res


	@staticmethod
	def from_toml(data:str):
		return OctoPwnSessionFile.from_dict(toml.loads(data))