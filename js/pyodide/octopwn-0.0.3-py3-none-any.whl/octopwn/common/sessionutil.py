import gzip
import toml
from octopwn.common.session import OctoPwnSessionFile

# utils helping in recovering a broken session file
# hope it will not be needed

def decompress_sessionfile(sessionfilename):
	with gzip.open(sessionfilename, 'r') as f:
		with open('dec.session', 'w') as o:
			o.write(f.read().decode())
		f.seek(0,0)
		data = f.read()
		print(data)
	session = OctoPwnSessionFile.from_toml(data.decode())
		
	print(session)
	print('Decompression OK!')

def main():
	import argparse
	parser = argparse.ArgumentParser(description='Octopwn Session file utils')
	parser.add_argument('sessionfile', help='Session file')
	
	args = parser.parse_args()
	decompress_sessionfile(args.sessionfile)


if __name__ == '__main__':
	main()