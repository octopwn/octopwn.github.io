
import ipaddress
from typing import List
from aiosmb.commons.connection.target import SMBTarget
from msldap.commons.target import MSLDAPTarget
from minikerberos.common.target import KerberosTarget
from aardwolf.commons.target import RDPTarget, RDPConnectionDialect
from unicrypto.hashlib import md5
from asysocks.unicomm.common.target import UniTarget, UniProto
from octopwn.remote.protocol.python import messages_pb2
from google.protobuf.json_format import ParseDict
from google.protobuf.json_format import MessageToDict

class Target:
	def __init__(self, ip:str, hostname:str = None, ports:List[int] = None, dcip:str = None, realm:str = None, hidden:bool = False, isdc:bool=False, sid:str=None, source:str=None, description:str = None, samaccountname:str = None, ostype:str=None, osver:str=None, uac:int=None, checksum:str = None):
		self.hostname = hostname
		self.ip = ip
		self.ports = ports
		self.dcip = dcip #for kerberos auth
		self.realm = realm
		self.hidden = hidden
		self.description = description
		self.isdc = isdc
		self.sid = sid
		self.samaccountname = samaccountname
		self.ostype = ostype
		self.osver = osver
		self.uac = uac
		self.source = source
		self.dns = None # TODO
		self.checksum = checksum # this is for filtering out duplicates

		if self.ports is None:
			self.ports = []

		if checksum is None:
			self.checksum = self.calc_checksum()
	
	def calc_checksum(self):
		data = str(self.hostname) + str(self.ip) + str(self.dcip) + str(self.realm) + str(self.sid)
		return md5(data.encode()).hexdigest()
	
	def __str__(self):
		t = ''
		for k in self.__dict__:
			t += '%s: %s\r\n' % (k, self.__dict__[k])
		return t

	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	@staticmethod
	def from_dict(d:dict):
		ip = d.get('ip', None)
		hostname = d.get('hostname', None)
		ports = d.get('ports', None)
		dcip = d.get('dcip', None)
		description = d.get('description', None)
		realm = d.get('realm', False)
		isdc = d.get('isdc', False)
		hidden = d.get('hidden', False)
		sid = d.get('sid', None)
		samaccountname = d.get('samaccountname', None)
		ostype = d.get('ostype', None)
		osver = d.get('osver', None)
		uac = d.get('uac', None)
		source = d.get('source', None)
		checksum = d.get('checksum', None)
		return Target(ip, hostname, ports, dcip, realm, hidden, isdc, sid, source, description, samaccountname, ostype, osver, uac, checksum)

	def get_hostname_or_ip(self):
		if self.hostname is not None:
			return self.hostname
		return self.ip

	def get_ip_or_hostname(self):
		if self.ip is not None:
			return self.ip
		return self.hostname
	
	def get_ip_and_hostname(self):
		ip = self.get_ip_or_hostname()
		hostname = self.get_hostname_or_ip()
		if ip is not None:
			try:
				ipaddress.ip_address(ip)
				ip = ip
				hostname = hostname
			except:
				ip = hostname
				hostname = hostname
		if hostname is not None:
			try:
				ipaddress.ip_address(hostname)
				ip = hostname
				hostname = None
			except:
				pass
		return ip, hostname

	def to_line(self):
		t = '%s' % self.get_hostname_or_ip()
		if self.isdc is True:
			t += ' (DC)'
		return t

	def to_compact(self):
		def noem(x):
			if x is None or x == '':
				return None
			return x

		ip = noem(self.ip)
		host = noem(self.hostname)
		if host is None:
			addr = ip
		else:
			addr = host
			if ip is not None:
				addr += ' [%s]' % ip
		
		#if self.ports is not None:
		#	addr += ':%s' % self.ports
		#
		if self.isdc is True:
			addr += ' (DC)'
		
		return addr

	async def do_portscan(self, portranges):
		#TODO: implement this!
		pass

	def get_smb_target(self, proxies = None, timeout = 1, domain = None, port:int = 445, protocol:UniProto = UniProto.CLIENT_TCP) -> SMBTarget:
		ip, hostname = self.get_ip_and_hostname()

		return SMBTarget(
			ip = ip,
			port = int(port),
			hostname = hostname,
			timeout = timeout,
			dc_ip = self.dcip,
			domain = domain if domain is not None else self.realm,
			proxies = proxies,
			protocol = protocol,
			dns = self.dns,
			path = None,
			compression = False,
			fragment = None
		)
	
	def get_ldap_target(self, proxies = None, timeout = 1, protocol = UniProto.CLIENT_TCP, port = None, domain = None) -> MSLDAPTarget:
		if port is None:
			if protocol == UniProto.CLIENT_TCP:
				port = 389
			elif protocol == UniProto.CLIENT_SSL_TCP:
				port = 636
		
		ip, hostname = self.get_ip_and_hostname()

		res = MSLDAPTarget(
			ip, 
			port = port, 
			protocol = protocol, 
			#tree = path, 
			proxies = proxies,
			timeout = timeout, 
			#ldap_query_page_size = pagesize, 
			#ldap_query_ratelimit = rate,
			dns = self.dns, 
			dc_ip = self.dcip, 
			domain = domain if domain is not None else self.realm, 
			hostname = hostname
		)
		return res
	
	def get_kerberos_target(self, proxies = None, timeout = 1) -> KerberosTarget:
		return KerberosTarget(
			self.get_ip_or_hostname(),
			proxies=proxies,
			protocol = UniProto.CLIENT_TCP,
			timeout = timeout,
			port = 88
		)

	def get_rdp_target(self, proxies = None, timeout = 1, domain = None, port = None, dialect:RDPConnectionDialect = RDPConnectionDialect.RDP) -> RDPTarget:
		ip, hostname = self.get_ip_and_hostname()
		if dialect == RDPConnectionDialect.RDP:
			port = 3389 if port is None else port
		elif dialect == RDPConnectionDialect.VNC:
			port = 5900 if port is None else port
		else:
			raise Exception("Unknown RDP/VNC protocol dialect '%s'" % dialect)
		
		return RDPTarget(
			ip, 
			port = port,
			hostname=hostname, 
			timeout=timeout, 
			dc_ip=self.dcip, 
			domain=domain if domain is not None else self.realm, 
			proxies=proxies, 
			protocol=UniProto.CLIENT_TCP, 
			dialect=dialect, 
			dns=self.dns
		)

	def get_vnctarget(self, proxies = None, timeout = 1, port = None) -> RDPTarget:
		# vnc and rdp are on the same interface
		target = self.get_rdp_target(proxies=proxies, timeout=timeout, dialect=RDPConnectionDialect.VNC)
		return target

	def get_ssh_target(self, proxies = None, timeout = 1) -> UniTarget:
		return KerberosTarget(
			self.get_ip_or_hostname(),
			proxies=proxies,
			protocol = UniProto.CLIENT_TCP,
			timeout = timeout,
			port = 22
		)
	
	def to_proto(self):
		t = ParseDict(self.to_dict(), messages_pb2.Target())
		for port in self.ports:
			t.ports.add(port)
		return t
	
	@staticmethod
	def from_proto(msg):
		return Target.from_dict(MessageToDict(msg))