import copy
import base64
from aiosmb.commons.connection.target import SMBTarget
from aiosmb.connection import SMBConnection
from msldap.commons.target import MSLDAPTarget
from msldap.connection import MSLDAPClientConnection
from unicrypto.hashlib import md5
from asysocks.unicomm.common.target import UniProto, UniTarget
from asyauth.common.subprotocols import SubProtocol, SubProtocolNative, SubProtocolSSPI, SubProtocolSSPIProxy, SubProtocolWSNet
from asyauth.common.constants import asyauthProtocol, asyauthSecret, asyauthSubProtocol
from asyauth.common.credentials import UniCredential, NTLMCredential, KerberosCredential, SPNEGOCredential, CREDSSPCredential
from amurex.common.credential import SSHCredentialPrivKey
from octopwn.remote.protocol.python import messages_pb2
from google.protobuf.json_format import ParseDict, MessageToDict


class Credential:
	def __init__(
			self, username:str, secret:str, stype:str, domain:str = None, certfile:str = None, keyfile:str = None, 
			hidden:bool = False, certfiledata:str=None, keyfiledata:str=None, sid:str=None, source:str=None, 
			description:str = None, subprotocol:str = 'NATIVE', subprotocolobj = None, checksum:str = None):
		self.domain = domain
		self.username = username
		self.stype = stype #password/nt/rc4/aes/kirbi/...
		self.secret = secret
		self.hidden = hidden
		self.certfile = certfile
		self.keyfile = keyfile
		self.certfiledata = certfiledata
		self.keyfiledata = keyfiledata
		self.description = description
		self.subprotocol = subprotocol
		self.subprotocolobj = subprotocolobj
		self.sid = sid
		self.source = source

		self.checksum = checksum # this is for filtering out duplicates

		self.__process_secret()

		if checksum is None:
			self.checksum = self.calc_checksum()

	def __process_secret(self):
		if self.stype.lower() in ['pw', 'pass', 'password']:
			self.stype = 'password'
		if self.stype.lower() == 'pwb64':
			self.stype = 'password'
			if isinstance(self.secret, str):
				self.secret = self.secret.encode()
			self.secret = base64.b64decode(self.secret).encode()

		if self.stype.lower() in ['ssh', 'sshprivkey']:
			self.stype = 'sshprivkey'

		if self.stype.lower() == 'sshprivkeystr':
			self.stype = 'SSHPRIVKEYB64'
			self.certfiledata = base64.b64encode(self.certfile.encode()).decode()
		
		if self.stype.lower() in ['sshprivkey']:
			if self.certfile is not None and self.certfiledata is None:
				with open(self.certfile, 'rb') as f:
					self.stype = 'SSHPRIVKEYB64'
					self.certfiledata = base64.b64encode(f.read()).decode()
		
		if self.stype.lower() in ['pfx', 'p12']:
			if self.certfile is not None and self.certfiledata is None:
				with open(self.certfile, 'rb') as f:
					self.certfiledata = base64.b64encode(f.read()).decode()
			
			if self.keyfile is not None and self.keyfiledata is None:
				with open(self.keyfile, 'rb') as f:
					self.keyfiledata = base64.b64encode(f.read()).decode()
		
		if self.stype.lower() == 'ccache':
			self.stype = 'ccacheb64'
			with open(self.secret, 'rb') as f:
				self.secret = base64.b64encode(f.read()).decode()
		
		if self.stype.lower() == 'keytab':
			self.stype = 'keytabb64'
			with open(self.secret, 'rb') as f:
				self.secret = base64.b64encode(f.read()).decode()
		
		if self.stype.lower() == 'kirbi':
			self.stype = 'kirbib64'
			with open(self.secret, 'rb') as f:
				self.secret = base64.b64encode(f.read()).decode()

	
	def calc_checksum(self):
		data = str(self.domain) + str(self.username) + str(self.stype) + str(self.secret) +str(self.certfiledata) + str(self.keyfiledata) + str(self.sid) 
		return md5(data.encode()).hexdigest()

	def to_dict(self):
		# we can do this as it's a simple object
		t = self.__dict__
		del t['subprotocolobj']
		return t
	
	def __str__(self):
		t = ''
		for k in self.__dict__:
			t += '%s: %s\r\n' % (k, self.__dict__[k])
		return t
	
	@staticmethod
	def from_dict(d:dict):
		username = d['username']
		secret = d['secret']
		stype = d['stype']
		hidden = d.get('hidden', False)
		domain = d.get('domain', None)
		certfile = d.get('certfile', None)
		keyfile = d.get('keyfile', None)
		certfiledata = d.get('certfiledata', None)
		keyfiledata = d.get('keyfiledata', None)
		description = d.get('description', None)
		sid = d.get('sid', None)
		source = d.get('source', None)
		subprotocol = d.get('subprotocol', 'NATIVE')
		checksum = d.get('checksum', None)

		return Credential(
			username,
			secret,
			stype,
			domain = domain,
			certfile = certfile,
			keyfile = keyfile, 
			hidden = hidden, 
			certfiledata = certfiledata, 
			keyfiledata = keyfiledata, 
			sid = sid, 
			source = source,
			description = description, 
			subprotocol = subprotocol,
			checksum = checksum
		)

	def to_line(self, truncate = True):
		domain = self.domain
		if self.domain is None:
			domain = '.'
		secret = self.secret
		if truncate is True and len(secret) > 10:
			secret = self.secret[:4] + '<REDACTED>' + self.secret[-4:]
		return '(%s) %s\\%s:%s' % (self.stype, domain, self.username, secret)
	
	def to_simple_line(self):
		domain = self.domain
		if self.domain is None:
			domain = '.'
		secret = self.secret
		if len(secret) > 10:
			secret = self.secret[:4] + '<REDACTED>' + self.secret[-4:]
		return '%s\\%s:%s' % (domain, self.username, secret)
	
	def get_subprotocol(self, target:UniTarget = None) -> SubProtocol:
		subprotocol = asyauthSubProtocol(self.subprotocol)
		if subprotocol == asyauthSubProtocol.NATIVE:
			return SubProtocolNative()
		if subprotocol == asyauthSubProtocol.SSPI:
			return SubProtocolSSPI()
		#if subprotocol == asyauthSubProtocol.SSPIPROXY:
		#	return SubProtocolSSPIProxy(self.subproto, self.subhost, self.subport, self.subagentid, copy.deepcopy(target.proxies))
		if subprotocol == asyauthSubProtocol.WSNET:
			return SubProtocolWSNet()
		if subprotocol == asyauthSubProtocol.CUSTOM:
			return self.subprotocolobj
		raise Exception("asyauth unknown subprotocol %s" % subprotocol)
	
	def get_kerberos_target_from_target(self, target:UniTarget):
		target = copy.deepcopy(target)
		return UniTarget(
			target.dc_ip, 
			88,
			UniProto.CLIENT_TCP, 
			timeout=target.timeout, 
			proxies=copy.deepcopy(target.proxies), 
			domain=target.domain,
			dc_ip=target.dc_ip
		)
	
	def get_credential(self, authprotocol:asyauthProtocol, target:UniTarget = None) -> UniCredential:
		target = copy.deepcopy(target)
		subprotocol = self.get_subprotocol(target)
		if self.stype.lower().startswith('ssh') is True:
			return SSHCredentialPrivKey(self.username, base64.b64decode(self.certfiledata), self.secret, domain = self.domain)
		if authprotocol == asyauthProtocol.NONE:
			return UniCredential(secret=None, username=None, domain=None, stype=asyauthSecret.NONE, protocol=asyauthProtocol.NONE, subprotocol=subprotocol)
		elif authprotocol in [asyauthProtocol.PLAIN, asyauthProtocol.SIMPLE]:
			return UniCredential(secret=self.secret, username=self.username, domain=self.domain, stype=asyauthSecret.PASSWORD, protocol=authprotocol, subprotocol=subprotocol)
		elif authprotocol in [ asyauthProtocol.NTLM, asyauthProtocol.SICILY]:
			if subprotocol.type in [asyauthSubProtocol.SSPI, asyauthSubProtocol.SSPIPROXY, asyauthSubProtocol.WSNET, asyauthSubProtocol.CUSTOM]:
				stype = asyauthSecret.NONE
			else:
				stype = asyauthSecret(self.stype.upper())
			cred = NTLMCredential(
				self.secret,
				self.username,
				self.domain,
				stype,
				subprotocol=subprotocol
			)
			if authprotocol == asyauthProtocol.SICILY:
				cred.protocol = asyauthProtocol.SICILY
			return cred
		elif authprotocol == asyauthProtocol.KERBEROS:
			if subprotocol.type in [asyauthSubProtocol.SSPI, asyauthSubProtocol.SSPIPROXY, asyauthSubProtocol.WSNET, asyauthSubProtocol.CUSTOM]:
				stype = asyauthSecret.NONE
			else:
				stype = asyauthSecret(self.stype.upper())
			
			return KerberosCredential(
				self.secret,
				self.username,
				self.domain,
				stype,
				self.get_kerberos_target_from_target(target),
				altname=self.username,
				altdomain=self.domain,
				etypes = [23,17,18],
				subprotocol=subprotocol,
				certdata=self.certfiledata,
				keydata=self.keyfiledata,
			)
		else:
			raise Exception('Unknown authprotocol "%s"' % authprotocol)
	
	def get_spnego_credential(self, authprotocol:asyauthProtocol, target:UniTarget) -> SPNEGOCredential:
		cred = self.get_credential(authprotocol, target)
		return SPNEGOCredential([cred])

	def get_credssp_credential(self, authprotocol:asyauthProtocol, target:UniTarget) -> CREDSSPCredential:
		cred = self.get_credential(authprotocol, target)
		return CREDSSPCredential([cred])

	def get_spnegoex_credential(self, target:UniTarget) -> CREDSSPCredential:
		cred = self.get_credential(asyauthProtocol.KERBEROS, target)
		return CREDSSPCredential([cred])
	
	def get_smb_connection(self, authprotocol:asyauthProtocol, target:SMBTarget) -> SMBConnection:
		gssapi = self.get_spnego_credential(authprotocol, target).build_context()
		return SMBConnection(gssapi, target)
	
	def get_ldap_connection(self, authprotocol:asyauthProtocol, target:MSLDAPTarget = None) -> MSLDAPClientConnection:
		credential = self.get_credential(authprotocol, target)
		return MSLDAPClientConnection(target, credential)
	
	
	def to_proto(self):
		msg = ParseDict(self.to_dict(), messages_pb2.Credential())
		return msg

	@staticmethod
	def from_proto(msg):
		d = MessageToDict(msg)
		return Credential.from_dict(d)

	def __deepcopy__(self, memo=None):
		cred = Credential.from_dict(self.to_dict())
		cred.subprotocolobj = self.subprotocolobj
		return cred

	#def get_kerberos_cred(self):
	#	stype = None
	#	dbstype = self.stype.upper()
	#	if dbstype in ['PW', 'PASSWORD', 'PASS']:
	#		kc = KerberosCredential()
	#		kc.domain = self.domain
	#		kc.username = self.username
	#		kc.add_secret(KerberosSecretType.PASSWORD, self.secret)
	#		return kc
	#	elif dbstype in ['RC4', 'NT']:
	#		kc = KerberosCredential()
	#		kc.domain = self.domain
	#		kc.username = self.username
	#		kc.add_secret(KerberosSecretType.RC4, self.secret)
	#		return kc
	#	elif dbstype in ['AES', 'AES128', 'AES256']:
	#		kc = KerberosCredential()
	#		kc.domain = self.domain
	#		kc.username = self.username
	#		kc.add_secret(KerberosSecretType.AES, self.secret)
	#		return kc
	#	elif dbstype in ['KEYTAB']:
	#		kc = KerberosCredential.from_keytab(self.secret)
	#		kc.domain = self.domain
	#		kc.username = self.username
	#		return kc
	#	elif dbstype in ['KIRBI']:
	#		kc = KerberosCredential.from_kirbi(self.secret, principal=self.username, realm=self.domain)
	#		return kc
	#	elif dbstype in ['PFX', 'P12']:
	#		# at this point it's just a b64 encoded string...
	#		kc = KerberosCredential.from_pfx_string(self.certfiledata, self.secret, username=self.username, domain=self.domain)
	#		return kc
	#	elif dbstype in ['PEM']:
	#		kc = KerberosCredential.from_pem_file(self.username, self.secret)
	#		return kc
	#	elif dbstype in ['SSPI', 'WSNET']:
	#		return None
	#	
	#	if stype is None:
	#		raise Exception('Couldnt figure out correct stype for customcred!')
	#