from typing import Dict, List, Tuple
import copy
from asysocks.unicomm.common.proxy import UniProxyProto, UniProxyTarget, proxyshort_to_type

class Proxy:
	def __init__(self, ptype:str, ip:str, port:int = None, username:str = None, password:str = None, agentid:str = None, description:str = None):
		self.ptype = ptype #socks4,socks5, socks4a, http
		self.ip = ip
		self.port = port
		self.username = username
		self.password = password
		self.agentid = agentid
		self.description = description
	
	def __str__(self):
		t = ''
		for k in self.__dict__:
			t += '%s: %s\r\n' % (k, self.__dict__[k])
		return t
	
	@staticmethod
	def from_dict(d:dict):
		ptype = d['ptype']
		ip = d['ip']
		port = d.get('port', None)
		username = d.get('username', None)
		password = d.get('password', None)
		agentid = d.get('agentid', None)
		description = d.get('description', None)

		return Proxy(ptype, ip, port, username, password, agentid, description)
	
	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	def to_line(self):
		return "(%s) %s:%s" % (self.ptype, self.ip, self.port)
	
	def get_proxy(self, endpoint_ip, endpoint_port, timeout=10, wsnetreuse=True) -> UniProxyTarget:
		p = UniProxyTarget()
		p.server_ip = self.ip
		p.server_port = int(self.port)
		p.agentid = self.agentid
		p.protocol = proxyshort_to_type[self.ptype.upper()]
		p.timeout = timeout
		#self.ssl_ctx:ssl.SSLContext = None
		p.credential = None
		p.endpoint_ip = endpoint_ip
		p.endpoint_port = int(endpoint_port)
		p.wsnet_reuse = wsnetreuse
		#self.userid = os.urandom(4).hex().encode('ascii')
		return [p]
	
class ProxyChain:
	def __init__(self, description:str = None):
		self.ptype = 'CHAIN'
		self.chain = []
		self.description = description
	
	def __str__(self):
		t = 'ProxyChain'
		for item in self.chain:
			t += '%s: %s\r\n' % (item, str(item))
		return t
	
	@staticmethod
	def from_dict(d:dict):
		ptype = d['ptype']
		chain = d.get('chain', [])		
		description = d.get('description', None)
		res = ProxyChain(description)
		res.chain = chain
		return res
	
	def to_line(self):
		return "(%s) [%s]" % (self.ptype, ','.join([str(cid) for cid in self.chain]))
	
	def to_dict(self):
		# we can do this as it's a simple object
		return self.__dict__
	
	def resolve_proxies(self, octoproxies:Dict[int, Proxy], wsnetreuse=True) -> Tuple[List[UniProxyTarget], Proxy]:
		proxies:List[Proxy] = []
		for chain in self.chain:
			proxies.append(copy.deepcopy(octoproxies[int(chain)]))
		
		asyproxies = []
		for i, proxy in enumerate(proxies[:-1]):
			asyproxies+= proxy.get_proxy(proxies[i+1].ip, proxies[i+1].port, wsnetreuse=wsnetreuse)

		#proxies[-1] = copy.deepcopy(proxies[-1])
		#proxies[-1].wsnet_reuse = wsnetreuse
		return asyproxies, proxies[-1]

	

	def get_generic_proxy(self, hostname_or_ip:str, port:int, octoproxies:Dict[int, Proxy], timeout:int = 10, wsnetreuse = True) -> List[UniProxyTarget]:
		asyproxies, last_proxy = self.resolve_proxies(octoproxies, wsnetreuse)
		asyproxies +=last_proxy.get_proxy(hostname_or_ip, int(port))
		return asyproxies
