
class ClientConfigBase:
	def __init__(self, config_type:str, clientname:str, completer, description = None):
		self.config_type = config_type
		self.clientname = clientname
		self.completer = completer
		self.description = description
	
	def to_dict(self):
		raise NotImplementedError()

class ClientConfig(ClientConfigBase):
	def __init__(self, connection_type:str, authentication_type:str, target_id:int, credential_id:int, proxy_id:int, clientname:str, completer, client_type, description = None):
		ClientConfigBase.__init__(self, 'NORMAL', clientname, completer, description)
		self.connection_type = connection_type
		self.authentication_type = authentication_type
		self.target_id = target_id
		self.credential_id = credential_id
		self.proxy_id = proxy_id
		self.client_type = client_type
		
	def to_dict(self):
		return {
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'connection_type' : self.connection_type,
			'authentication_type' : self.authentication_type,
			'target_id' : self.target_id,
			'credential_id' : self.credential_id,
			'proxy_id' : self.proxy_id,
			'description' : self.description,
			'client_type' : self.client_type,
		}
	
	@staticmethod
	def from_dict(d:dict):
		connection_type = d['connection_type']
		authentication_type = d['authentication_type']
		client_type = d['client_type']
		target_id = int(d['target_id'])
		credential_id = None
		if 'credential_id' in d:
			credential_id = int(d['credential_id'])
		proxy_id = d.get('proxy_id')
		description = d.get('description')
		


		return ClientConfig(connection_type, authentication_type, target_id, credential_id, proxy_id, '', None, client_type, description)

class ScannerConfig(ClientConfigBase):
	def __init__(self, scanner_type:str, clientname, completer, description = None):
		ClientConfigBase.__init__(self, 'SCANNER', clientname, completer, description)
		self.scanner_type = scanner_type
		self.params = {}
	
	def to_dict(self):
		return {
			'scanner_type' : self.scanner_type,
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'params' : self.params,
			'description' : self.description,
		}
	
	@staticmethod
	def from_dict(d:dict):
		scanner_type = d.get('scanner_type', None)
		clientname = d.get('clientname', None)
		description = d.get('description', None)
		res = ScannerConfig(scanner_type, clientname, None, description)
		res.params = d.get('params', None)
		
		return res

class ServerConfig(ClientConfigBase):
	def __init__(self, scanner_type:str, clientname:str, completer, description:str = None):
		ClientConfigBase.__init__(self, 'SERVER', clientname, completer, description)
		self.scanner_type = scanner_type
		self.params = {}
	
	def to_dict(self):
		return {
			'scanner_type' : self.scanner_type,
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'params' : self.params,
			'description' : self.description,
		}
	
	@staticmethod
	def from_dict(d:dict):
		scanner_type = d.get('scanner_type', None)
		clientname = d.get('clientname', None)
		description = d.get('description', None)		
		res = ServerConfig(scanner_type, clientname, None, description)
		res.params = d.get('params', None)
		return res

class UtilsConfig(ClientConfigBase):
	def __init__(self, scanner_type:str, clientname:str, completer, description:str = None):
		ClientConfigBase.__init__(self, 'UTILS', clientname, completer, description)
		self.scanner_type = scanner_type
		self.params = {}
	
	def to_dict(self):
		return {
			'config_type' : self.config_type,
			'clientname' : self.clientname,
			'scanner_type' : self.scanner_type,
			'description': self.description,
			'params' : self.params,
		}
	
	@staticmethod
	def from_dict(d:dict):
		scanner_type = d.get('scanner_type', None)
		description = d.get('clientname', None)
		clientname = d.get('clientname', '???')
		res = UtilsConfig(scanner_type, clientname, None, description)
		res.params = d.get('params', None)
		return res