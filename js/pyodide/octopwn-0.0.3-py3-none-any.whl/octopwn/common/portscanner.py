import asyncio
import enum
import typing
import uuid
import traceback
import ipaddress
from typing import List, Tuple

class ScanResult(enum.Enum):
	FINISHED = enum.auto()
	PROGRESS = enum.auto()
	RESULT = enum.auto()
	ERROR = enum.auto()

class ResultProgress:
	def __init__(self, totalTargets, finishedTargets, totalStages, currentStage):
		self.totalStages = totalStages
		self.currentStage = currentStage
		self.totalTargets = totalTargets
		self.finishedTargets = finishedTargets
	
	def getPercentage(self):
		if self.totalTargets == 0:
			return 0
		return round((self.finishedTargets/self.totalTargets)*100,2)
	
	def __str__(self):
		return "[%s/%s %s/%s (%s)]" % (self.totalStages, self.currentStage, self.finishedTargets, self.totalTargets, self.getPercentage())

class Result:
	def __init__(self, tid, target, restype, result = None):
		self.tid = tid
		self.target = target
		self.restype = restype
		self.result = result
		self.total_targets = 0

class TargetListGen:
	def __init__(self):
		self.targets:List[Tuple[str,str]] = []
	
	async def generate(self):
		try:
			for tid, target in self.targets:
				if tid is None:
					tid = str(uuid.uuid4())
				target = target.strip()
				try:
					ip = ipaddress.ip_address(target)
					yield tid,str(ip), None
				except:
					try:
						for ip in ipaddress.ip_network(target, strict = False):
							yield  tid,str(ip), None
					except:
						yield tid, target, None
		except Exception as e:
			traceback.print_exc()
			yield None, None, e

class PortScanner:
	def __init__(self, portranges:List[str], worker_count:int = 10, timeout = 5, proxies = None, with_errors:bool = False):
		target_gens = []
		self.portranges = portranges
		self.worker_count = worker_count
		self.proxies = proxies
		self.with_errors = with_errors
		self.target_queue:asyncio.Queue = None
		self.result_queue:asyncio.Queue = None
		self.workers:List[asyncio.Task] = []
		self.stop_evt:asyncio.Event = None
		self.timeout = timeout
		self.tgen_errors = {}
		self.ports = {}
		self.total_targets = 0
		self.error_cnt = 0
		self.finished_cnt = 0
		self.prevpercentage = 0
		self.target_generator_task = None


	
	async def stop(self):
		self.stop_evt.set()
		if self.target_generator_task is not None:
			self.target_generator_task.cancel()
		for worker in self.workers:
			worker.cancel()
		self.result_queue.put_nowait(None)
		

	async def scan_target(self, tid, target, port):
		writer = None
		try:
			_, writer = await asyncio.wait_for(asyncio.open_connection(target, port), self.timeout)
			
			await self.result_queue.put(Result(tid, target, ScanResult.RESULT, port))
		except Exception as e:
			await self.result_queue.put(Result(tid, target, ScanResult.ERROR, e))
		finally:
			if writer is not None:
				writer.close()
			await self.result_queue.put(Result(tid, target, ScanResult.FINISHED))
	
	async def __worker(self):
		try:
			while not self.stop_evt.is_set():
				res = await self.target_queue.get()
				if res is None:
					return
				tid, target, port = res
				try:
					await asyncio.wait_for(self.scan_target(tid, target, port), self.timeout)
				except asyncio.TimeoutError:
					pass

		except Exception as e:
			traceback.print_exc()
			pass

	async def generate_targets(self):
		try:
			for tgen in target_gens:
				self.total_targets += len(tgen.targets)*len(self.ports)
			for tgen in target_gens:
				async for tid, target, err in tgen.generate():
					if err is not None:
						self.tgen_errors[tid] = target
						continue
					for port in self.ports:
						await self.target_queue.put((tid, target, port))
						

		except Exception as e:
			traceback.print_exc()
			return None, e
		finally:
			for _ in range(self.worker_count):
				await self.target_queue.put(None)
			try:
				asyncio.gather(*self.workers)
			except:
				pass
			await self.result_queue.put(None)

	def calculate_ports(self):
		def calc_range(x):
			if x.find('-') != -1:
				start,end = x.split('-')
				for i in range(int(start), int(end)):
					self.ports[int(i)] = None
			else:
				self.ports[int(x)] = None

		for prange in self.portranges:
			if prange.find(',') != -1:
				for port in prange.split(','):
					calc_range(port)
			else:
				calc_range(prange)


	async def scan(self):
		try:
			self.stop_evt = asyncio.Event()
			self.target_queue = asyncio.Queue(self.worker_count)
			self.result_queue = asyncio.Queue()
			self.calculate_ports()
			for _ in range(self.worker_count):
				self.workers.append(asyncio.create_task(self.__worker()))
			
			self.target_generator_task = asyncio.create_task(self.generate_targets())
			
			
			while not self.stop_evt.is_set():
				result = await self.result_queue.get()
				if result is None:
					return
				result = typing.cast(Result, result)
				if result.restype == ScanResult.ERROR:
					self.error_cnt += 1
					if self.with_errors is True:
						yield 'error', result, None, None
				elif result.restype == ScanResult.RESULT:
					yield 'result', result, None
				elif result.restype == ScanResult.FINISHED:
					self.finished_cnt += 1
					t = ResultProgress(self.total_targets, self.finished_cnt, 1, 1)
					if t.getPercentage() - self.prevpercentage > 0.5:
						self.prevpercentage = t.getPercentage()
						yield 'progress', t, None


		except Exception as e:
			traceback.print_exc()
			yield None, None, e