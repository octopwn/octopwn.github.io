

import traceback
from octopwn.common.credential import Credential
from octopwn.remote.protocol.python import secrets_pb2


async def store_lsass_creds(mainobj, results, to_print = True, h_token = None):
	def flatten_logonsession(creds, result, luid, logonsessions):
		for cred in logonsessions.msv_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.wdigest_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.ssp_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.livessp_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.dpapi_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.kerberos_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.credman_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.tspkg_creds:
			creds.append((result, luid, cred))
		for cred in logonsessions.cloudap_creds:
			creds.append((result, luid, cred))

	try:
		creds = []
		for result in results:
			for luid in results[result].logon_sessions:
				flatten_logonsession(creds, result, luid, results[result].logon_sessions[luid])
			
			for logonsession in results[result].orphaned_creds:
				flatten_logonsession(creds, result, None, logonsession)
		
		for fname, luid, cred in creds:
			if cred.credtype in ['wdigest', 'tspkg', 'ssp', 'livessp', 'credman']:
				if cred.password is None:
					continue
				password = cred.password
				if isinstance(cred.password, bytes):
					password = cred.password.hex()
				credential = Credential(
					username = cred.username,
					secret=password,
					stype='PASSWORD',
					domain=cred.domainname,
				)
				_, err = await mainobj.octopwnobj.addcredential_obj(credential)

			elif cred.credtype == 'msv':
				if cred.NThash is not None:
					credential = Credential(
						username = cred.username,
						secret=cred.NThash.hex(),
						stype='NT',
						domain=cred.domainname,
					)
					_, err = await mainobj.octopwnobj.addcredential_obj(credential)
				if cred.LMHash is not None:
					credential = Credential(
						username = cred.username,
						secret=cred.LMHash.hex(),
						stype='LM',
						domain=cred.domainname,
					)
					_, err = await mainobj.octopwnobj.addcredential_obj(credential)
				if cred.SHAHash is not None:
					credential = Credential(
						username = cred.username,
						secret=cred.SHAHash.hex(),
						stype='SHA1',
						domain=cred.domainname,
					)
					_, err = await mainobj.octopwnobj.addcredential_obj(credential)
				if cred.DPAPI is not None:
					credential = Credential(
						username = cred.username,
						secret=cred.DPAPI.hex(),
						stype='DPAPI:MSV',
						domain=cred.domainname,
					)
					_, err = await mainobj.octopwnobj.addcredential_obj(credential)
			
			elif cred.credtype == 'dpapi':
				credential = Credential(
					username = cred.key_guid,
					secret=cred.masterkey,
					stype='DPAPI',
					domain=cred.sha1_masterkey,
				)
				_, err = await mainobj.octopwnobj.addcredential_obj(credential)

	except Exception as e:
		traceback.print_exc()