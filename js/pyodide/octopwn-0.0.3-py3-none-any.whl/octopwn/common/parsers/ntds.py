

import traceback


import traceback
from octopwn.common.credential import Credential
from octopwn.remote.protocol.python import secrets_pb2

async def store_ntds_secrets(mainobj, secret, to_print = True, fileh = None):
	try:
		if secret.nt_hash is not None:
			nt_hash = secret.nt_hash.hex()
			if nt_hash != '31d6cfe0d16ae931b73c59d7e0c089c0':
				cred = Credential(secret.username, nt_hash, 'NT', domain=secret.domain, source='SMB-DCSYNC-%s' % mainobj.client_id, sid=str(secret.object_sid), description='DCSYNC')
				_, err = await mainobj.octopwnobj.addcredential_obj(cred, to_print=False)
				if err is not None and to_print is True:
					await mainobj.print('Failed to add dcsync credential for user %s Reason: %s' % (secret.username, err))
		for ktype, key in secret.kerberos_keys:
			kt = ''
			if ktype.startswith('rc4') is True:
				kt = 'RC4'
			if ktype.startswith('aes') is True:
				kt = 'AES'
			else:
				continue
			cred = Credential(secret.username, key.hex(), kt, domain=secret.domain, source='SMB-DCSYNC-%s' % mainobj.client_id, sid=str(secret.object_sid), description='DCSYNC')
			_, err = await mainobj.octopwnobj.addcredential_obj(cred, to_print=False)
			if err is not None and to_print is True:
				await mainobj.print('Failed to add dcsync credential for user %s Reason: %s' % (secret.username, err))

				
		if fileh is None:
			if to_print is True:
				await mainobj.print(str(secret))
		
		else:
			fileh.write(str(secret))
	except Exception as e:
		traceback.print_exc()