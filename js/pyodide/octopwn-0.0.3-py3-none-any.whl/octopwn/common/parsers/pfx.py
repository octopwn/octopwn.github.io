

import base64
import traceback

from octopwn.common.credential import Credential



async def store_pfx_creds(mainobj, pfxdata, pfx_password, cn = None, altname = None):
	try:
		if cn is not None:
			username, domain = cn.split('@')
		if altname is not None:
			altusername, altdomain = altname.split('@')

		if cn is not None:
			credential = Credential(
				username,
				pfx_password,
				'pfxb64',
				domain,
				keyfiledata = base64.b64encode(pfxdata).decode(), 
			)
			await mainobj.octopwnobj.addcredential_obj(credential, to_print=False)

		if altname is not None:
			credential = Credential(
				altusername,
				pfx_password,
				'pfxb64',
				altdomain,
				keyfiledata = base64.b64encode(pfxdata).decode(), 
			)
			await mainobj.octopwnobj.addcredential_obj(credential, to_print=False)


	except Exception as e:
		traceback.print_exc()