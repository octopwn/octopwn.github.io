import traceback
import asyncio
import sys
import multiprocessing

from octopwn.core import OctoPwn
from octopwn.common.screenhandler import ScreenHandlerPromptToolkitApplication

async def amain(args):
	try:
		screen = ScreenHandlerPromptToolkitApplication()
		if args.sessionfile is not None:
			console = OctoPwn.load(args.sessionfile, screen)
		else:
			if args.no_outfile is True:
				args.workdir = None
			console = OctoPwn(screen, work_dir = args.workdir)
		octopwn_stopped_evt, err = await console.run()
		if err is not None:
			raise err
		await octopwn_stopped_evt.wait()
	except Exception as e:
		traceback.print_exc()

def main():
	import argparse
	
	parser = argparse.ArgumentParser(description='Octopwn')
	parser.add_argument('-n', '--no-outfile', action='store_true', help='Disable output file creation. Pls dont use this.')
	parser.add_argument('-w', '--workdir', default='./', help='Directory to save output files to.')
	parser.add_argument('-s', '--sessionfile', help='Reload saved session')
	
	args = parser.parse_args()
	asyncio.run(amain(args))

if __name__ == '__main__':
	if sys.platform.startswith('win'):
		# Pyinstaller stuff
		# On Windows calling this function is necessary.
		multiprocessing.freeze_support()
	main()